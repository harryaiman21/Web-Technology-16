"use client";

import Link from "next/link";
import { useRouter, usePathname } from "next/navigation";
import { supabase } from "../lib/supabaseClient";

export default function Navbar() {
  const router = useRouter();
  const pathname = usePathname();

  async function handleLogout() {
    if (supabase) {
      await supabase.auth.signOut();
    }

    router.push("/login");
  }

  const navItems = [
    { href: "/dashboard", label: "Dashboard" },
    { href: "/upload", label: "Upload" },
    { href: "/incidents", label: "Incidents" },
    { href: "/reports", label: "Reports" },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-yellow-300 bg-[#ffcc00] shadow-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href="/dashboard" className="flex items-center gap-3">
          <div className="rounded-md bg-[#d40511] px-4 py-2 text-xl font-black tracking-wider text-[#ffcc00] shadow-sm">
            DHL
          </div>

          <div>
            <h1 className="text-lg font-black text-[#111827]">
              Incident Reporting System
            </h1>
            <p className="text-xs font-semibold text-gray-700">
              AI-Enhanced Customer Support Resolution
            </p>
          </div>
        </Link>

        <nav className="flex items-center gap-2">
          {navItems.map((item) => {
            const active = pathname === item.href;

            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-full px-4 py-2 text-sm font-bold transition ${
                  active
                    ? "bg-[#d40511] text-white"
                    : "text-[#111827] hover:bg-white/70"
                }`}
              >
                {item.label}
              </Link>
            );
          })}

          <button
            onClick={handleLogout}
            className="ml-2 rounded-full bg-[#111827] px-4 py-2 text-sm font-bold text-white hover:bg-black"
          >
            Logout
          </button>
        </nav>
      </div>
    </header>
  );
}