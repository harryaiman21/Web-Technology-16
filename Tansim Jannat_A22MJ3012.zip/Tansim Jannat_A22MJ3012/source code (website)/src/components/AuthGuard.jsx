"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, isSupabaseConfigured } from "../lib/supabaseClient";

export default function AuthGuard({ children }) {
  const router = useRouter();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    async function checkUser() {
      if (!isSupabaseConfigured || !supabase) {
        setChecking(false);
        return;
      }

      const { data, error } = await supabase.auth.getSession();

      if (error) {
        console.error(error);
        setChecking(false);
        return;
      }

      if (!data.session) {
        router.push("/login");
        return;
      }

      setChecking(false);
    }

    checkUser();
  }, [router]);

  if (checking) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#ffcc00]">
        <div className="rounded-2xl bg-white px-8 py-6 shadow-lg">
          <p className="font-bold text-[#d40511]">Checking login...</p>
        </div>
      </main>
    );
  }

  return <>{children}</>;
}