"use client";

import { useEffect, useState } from "react";
import AuthGuard from "../../components/AuthGuard";
import Navbar from "../../components/Navbar";
import { supabase, isSupabaseConfigured } from "../../lib/supabaseClient";

export default function DashboardPage() {
  const [incidents, setIncidents] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    fetchIncidents();
  }, []);

  async function fetchIncidents() {
    if (!isSupabaseConfigured || !supabase) {
      setErrorMessage("Supabase is not connected. Check your .env.local file.");
      return;
    }

    const { data, error } = await supabase
      .from("incidents")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      setErrorMessage(error.message);
      return;
    }

    setIncidents(data || []);
  }

  const total = incidents.length;
  const open = incidents.filter((i) => i.status !== "Closed").length;
  const highPriority = incidents.filter(
    (i) => i.priority === "High" || i.priority === "Urgent"
  ).length;
  const resolved = incidents.filter((i) => i.status === "Resolved").length;

  return (
    <AuthGuard>
      <Navbar />

      <main className="min-h-screen bg-gray-100">
        <section className="bg-[#111827] px-6 py-10 text-white">
          <div className="mx-auto max-w-7xl">
            <p className="font-bold text-[#ffcc00]">DHL Customer Support</p>
            <h2 className="mt-2 text-3xl font-black">Incident Dashboard</h2>
            <p className="mt-2 max-w-2xl text-gray-300">
              Monitor incident volume, priority, resolution status, and recent
              customer complaints.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-6 py-8">
          {errorMessage && (
            <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 p-5 font-semibold text-[#d40511]">
              {errorMessage}
            </div>
          )}

          <div className="-mt-16 grid gap-5 md:grid-cols-4">
            <SummaryCard title="Total Incidents" value={total} />
            <SummaryCard title="Open Incidents" value={open} />
            <SummaryCard title="High / Urgent" value={highPriority} />
            <SummaryCard title="Resolved" value={resolved} />
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-3">
            <section className="rounded-3xl bg-white p-6 shadow-sm lg:col-span-2">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-black text-[#111827]">
                    Recent Incidents
                  </h3>
                  <p className="text-sm text-gray-500">
                    Latest customer support cases
                  </p>
                </div>
                <span className="rounded-full bg-[#ffcc00] px-4 py-2 text-sm font-black text-[#111827]">
                  Live
                </span>
              </div>

              <div className="mt-5 overflow-x-auto">
                <table className="w-full border-collapse text-sm">
                  <thead>
                    <tr className="border-b bg-gray-50 text-left">
                      <th className="p-3">Ticket</th>
                      <th className="p-3">Title</th>
                      <th className="p-3">Priority</th>
                      <th className="p-3">Department</th>
                      <th className="p-3">Status</th>
                    </tr>
                  </thead>

                  <tbody>
                    {incidents.slice(0, 6).map((incident) => (
                      <tr
                        key={incident.id}
                        className="border-b hover:bg-yellow-50"
                      >
                        <td className="p-3 font-black text-[#d40511]">
                          {incident.ticket_id}
                        </td>
                        <td className="p-3 font-medium">{incident.title}</td>
                        <td className="p-3">
                          <PriorityBadge priority={incident.priority} />
                        </td>
                        <td className="p-3">{incident.department}</td>
                        <td className="p-3">
                          <StatusBadge status={incident.status} />
                        </td>
                      </tr>
                    ))}

                    {incidents.length === 0 && (
                      <tr>
                        <td
                          colSpan="5"
                          className="p-6 text-center text-gray-500"
                        >
                          No incidents found.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="rounded-3xl bg-white p-6 shadow-sm">
              <h3 className="text-xl font-black text-[#111827]">
                Workflow Status
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                Standard incident resolution flow
              </p>

              <div className="mt-6 space-y-3">
                {[
                  "Draft",
                  "Reviewed",
                  "Assigned",
                  "In Progress",
                  "Resolved",
                  "Closed",
                ].map((status, index) => (
                  <div key={status} className="flex items-center gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#ffcc00] text-sm font-black text-[#111827]">
                      {index + 1}
                    </div>
                    <div className="flex-1 rounded-xl border bg-gray-50 px-4 py-3 font-semibold">
                      {status}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        </section>
      </main>
    </AuthGuard>
  );
}

function SummaryCard({ title, value }) {
  return (
    <div className="rounded-3xl border-t-4 border-[#d40511] bg-white p-6 shadow-lg">
      <p className="text-sm font-bold uppercase tracking-wide text-gray-500">
        {title}
      </p>
      <p className="mt-3 text-4xl font-black text-[#111827]">{value}</p>
    </div>
  );
}

function PriorityBadge({ priority }) {
  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-black ${
        priority === "Urgent"
          ? "bg-[#d40511] text-white"
          : priority === "High"
          ? "bg-orange-100 text-orange-700"
          : priority === "Medium"
          ? "bg-yellow-100 text-yellow-800"
          : "bg-gray-100 text-gray-700"
      }`}
    >
      {priority}
    </span>
  );
}

function StatusBadge({ status }) {
  return (
    <span className="rounded-full bg-gray-900 px-3 py-1 text-xs font-bold text-white">
      {status}
    </span>
  );
}