import "./globals.css";

export const metadata = {
  title: "DHL Incident Reporting System",
  description: "AI-Enhanced Incident Reporting and Resolution System",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}