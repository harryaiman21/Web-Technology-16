"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabase, isSupabaseConfigured } from "../../lib/supabaseClient";

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("support@dhl.com");
  const [password, setPassword] = useState("support123456");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e) {
    e.preventDefault();
    setError("");

    if (!isSupabaseConfigured || !supabase) {
      setError(
        "Supabase is not connected. Please check your .env.local file."
      );
      return;
    }

    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen bg-[#ffcc00]">
      <div className="grid min-h-screen md:grid-cols-2">
        <section className="flex flex-col justify-center px-8 py-12 md:px-20">
          <div className="mb-8 inline-flex w-fit rounded-lg bg-[#d40511] px-6 py-3 text-4xl font-black tracking-wider text-[#ffcc00] shadow-lg">
            DHL
          </div>

          <h1 className="max-w-xl text-4xl font-black leading-tight text-[#111827] md:text-5xl">
            Smart Incident Reporting & Resolution System
          </h1>

          <p className="mt-5 max-w-xl text-lg font-medium text-gray-800">
            Transform messy customer complaints from email, WhatsApp, call
            notes, and warehouse remarks into structured incident reports.
          </p>

          <div className="mt-8 grid max-w-xl gap-3 sm:grid-cols-3">
            <FeatureCard title="Classify" text="Detect issue type" />
            <FeatureCard title="Assign" text="Route department" />
            <FeatureCard title="Track" text="Monitor progress" />
          </div>
        </section>

        <section className="flex items-center justify-center bg-[#111827] px-6 py-12">
          <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl">
            <h2 className="text-2xl font-black text-[#111827]">
              Staff Login
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Sign in to manage DHL customer support incidents.
            </p>

            {!isSupabaseConfigured && (
              <div className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-[#d40511]">
                Supabase is not configured. Check your .env.local file.
              </div>
            )}

            <form onSubmit={handleLogin} className="mt-8 space-y-5">
              <div>
                <label className="text-sm font-bold text-gray-700">
                  Email
                </label>
                <input
                  className="mt-2 w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511] focus:ring-2 focus:ring-red-100"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  type="email"
                  required
                />
              </div>

              <div>
                <label className="text-sm font-bold text-gray-700">
                  Password
                </label>
                <input
                  className="mt-2 w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511] focus:ring-2 focus:ring-red-100"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  type="password"
                  required
                />
              </div>

              {error && (
                <p className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-[#d40511]">
                  {error}
                </p>
              )}

              <button
                disabled={loading}
                className="w-full rounded-xl bg-[#d40511] py-3 font-black text-white shadow-md transition hover:bg-red-700 disabled:opacity-60"
              >
                {loading ? "Logging in..." : "Login"}
              </button>
            </form>

            <div className="mt-6 rounded-2xl bg-[#ffcc00]/30 p-4 text-sm">
              <p className="font-black text-[#111827]">Demo Account</p>
              <p className="mt-1 text-gray-700">support@dhl.com</p>
              <p className="text-gray-700">support123456</p>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}

function FeatureCard({ title, text }) {
  return (
    <div className="rounded-2xl bg-white/70 p-4 shadow-sm">
      <p className="font-black text-[#d40511]">{title}</p>
      <p className="mt-1 text-sm font-medium text-gray-700">{text}</p>
    </div>
  );
}