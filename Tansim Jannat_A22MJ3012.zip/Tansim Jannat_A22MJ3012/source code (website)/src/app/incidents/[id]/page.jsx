"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import AuthGuard from "../../../components/AuthGuard";
import Navbar from "../../../components/Navbar";
import { supabase, isSupabaseConfigured } from "../../../lib/supabaseClient";

export default function IncidentDetailsPage() {
  const params = useParams();
  const incidentId = params.id;

  const [incident, setIncident] = useState(null);
  const [history, setHistory] = useState([]);
  const [newStatus, setNewStatus] = useState("");
  const [remarks, setRemarks] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (incidentId) {
      fetchIncident();
      fetchHistory();
    }
  }, [incidentId]);

  async function fetchIncident() {
    if (!isSupabaseConfigured || !supabase) {
      setErrorMessage("Supabase is not connected. Check your .env.local file.");
      return;
    }

    const { data, error } = await supabase
      .from("incidents")
      .select("*")
      .eq("id", incidentId)
      .single();

    if (error) {
      setErrorMessage(error.message);
      return;
    }

    setIncident(data);
    setNewStatus(data.status);
  }

  async function fetchHistory() {
    if (!isSupabaseConfigured || !supabase) return;

    const { data, error } = await supabase
      .from("incident_history")
      .select("*")
      .eq("incident_id", incidentId)
      .order("created_at", { ascending: false });

    if (!error && data) {
      setHistory(data);
    }
  }

  async function updateStatus() {
    if (!incident || !supabase) return;

    const { error } = await supabase
      .from("incidents")
      .update({
        status: newStatus,
        updated_at: new Date().toISOString(),
      })
      .eq("id", incident.id);

    if (error) {
      alert(error.message);
      return;
    }

    await supabase.from("incident_history").insert({
      incident_id: incident.id,
      status: newStatus,
      updated_by: "Support Agent",
      remarks: remarks || `Status changed to ${newStatus}`,
    });

    setRemarks("");
    fetchIncident();
    fetchHistory();
  }

  if (errorMessage) {
    return (
      <AuthGuard>
        <Navbar />
        <main className="min-h-screen bg-gray-100 p-8">
          <div className="rounded-2xl border border-red-200 bg-red-50 p-5 font-semibold text-[#d40511]">
            {errorMessage}
          </div>
        </main>
      </AuthGuard>
    );
  }

  if (!incident) {
    return (
      <AuthGuard>
        <Navbar />
        <main className="flex min-h-screen items-center justify-center bg-gray-100">
          <p className="font-semibold text-gray-600">Loading incident...</p>
        </main>
      </AuthGuard>
    );
  }

  return (
    <AuthGuard>
      <Navbar />

      <main className="min-h-screen bg-gray-100">
        <section className="bg-[#111827] px-6 py-10 text-white">
          <div className="mx-auto max-w-6xl">
            <p className="font-bold text-[#ffcc00]">{incident.ticket_id}</p>
            <h2 className="mt-2 text-3xl font-black">{incident.title}</h2>
            <p className="mt-3 max-w-3xl text-gray-300">
              {incident.clean_summary}
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-8">
          <div className="-mt-16 rounded-3xl bg-white p-6 shadow-lg">
            <div className="grid gap-4 md:grid-cols-3">
              <InfoBox label="Shipment ID" value={incident.shipment_id || "-"} />
              <InfoBox label="Category" value={incident.category} />
              <InfoBox label="Priority" value={incident.priority} />
              <InfoBox label="Department" value={incident.department} />
              <InfoBox label="Status" value={incident.status} />
              <InfoBox label="Source" value={incident.source || "-"} />
            </div>
          </div>

          <section className="mt-6 grid gap-6 lg:grid-cols-2">
            <div className="rounded-3xl bg-white p-6 shadow-sm">
              <h3 className="text-xl font-black text-[#111827]">
                Extracted Key Problem
              </h3>
              <p className="mt-4 leading-relaxed text-gray-700">
                {incident.customer_issue}
              </p>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-sm">
              <h3 className="text-xl font-black text-[#111827]">
                Update Incident Status
              </h3>

              <select
                className="mt-4 w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511]"
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
              >
                <option>Draft</option>
                <option>Reviewed</option>
                <option>Assigned</option>
                <option>In Progress</option>
                <option>Resolved</option>
                <option>Closed</option>
              </select>

              <textarea
                className="mt-4 h-28 w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511]"
                placeholder="Add investigation notes or update remarks..."
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
              />

              <button
                onClick={updateStatus}
                className="mt-4 rounded-xl bg-[#d40511] px-6 py-3 font-black text-white shadow-md transition hover:bg-red-700"
              >
                Save Status Update
              </button>
            </div>
          </section>

          <section className="mt-6 rounded-3xl bg-white p-6 shadow-sm">
            <h3 className="text-xl font-black text-[#111827]">Raw Input</h3>
            <pre className="mt-4 max-h-96 overflow-auto whitespace-pre-wrap rounded-2xl bg-gray-50 p-5 text-sm leading-relaxed text-gray-700">
              {incident.raw_text}
            </pre>
          </section>

          <section className="mt-6 rounded-3xl bg-white p-6 shadow-sm">
            <h3 className="text-xl font-black text-[#111827]">
              Status History
            </h3>

            <div className="mt-5 space-y-4">
              {history.map((item) => (
                <div
                  key={item.id}
                  className="rounded-2xl border-l-4 border-[#d40511] bg-gray-50 p-5"
                >
                  <p className="font-black text-[#111827]">{item.status}</p>
                  <p className="mt-1 text-sm text-gray-700">{item.remarks}</p>
                  <p className="mt-2 text-xs font-medium text-gray-500">
                    {new Date(item.created_at).toLocaleString()} by{" "}
                    {item.updated_by}
                  </p>
                </div>
              ))}

              {history.length === 0 && (
                <p className="rounded-2xl bg-gray-50 p-5 text-sm text-gray-500">
                  No status history yet.
                </p>
              )}
            </div>
          </section>
        </section>
      </main>
    </AuthGuard>
  );
}

function InfoBox({ label, value }) {
  return (
    <div className="rounded-2xl bg-gray-50 p-5">
      <p className="text-xs font-black uppercase tracking-wide text-gray-500">
        {label}
      </p>
      <p className="mt-2 font-black text-[#111827]">{value}</p>
    </div>
  );
}