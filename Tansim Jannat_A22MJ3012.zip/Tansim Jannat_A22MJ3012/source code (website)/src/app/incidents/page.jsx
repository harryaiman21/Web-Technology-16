"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import AuthGuard from "../../components/AuthGuard";
import Navbar from "../../components/Navbar";
import { supabase, isSupabaseConfigured } from "../../lib/supabaseClient";

export default function IncidentsPage() {
  const [incidents, setIncidents] = useState([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("All");
  const [priority, setPriority] = useState("All");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    fetchIncidents();
  }, []);

  async function fetchIncidents() {
    if (!isSupabaseConfigured || !supabase) {
      setErrorMessage("Supabase is not connected. Check your .env.local file.");
      return;
    }

    const { data, error } = await supabase
      .from("incidents")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      setErrorMessage(error.message);
      return;
    }

    setIncidents(data || []);
  }

  const filteredIncidents = useMemo(() => {
    return incidents.filter((incident) => {
      const searchText = `${incident.ticket_id} ${incident.title} ${
        incident.shipment_id || ""
      } ${incident.category} ${incident.department} ${
        incident.status
      }`.toLowerCase();

      const matchesSearch = searchText.includes(search.toLowerCase());
      const matchesStatus = status === "All" || incident.status === status;
      const matchesPriority =
        priority === "All" || incident.priority === priority;

      return matchesSearch && matchesStatus && matchesPriority;
    });
  }, [incidents, search, status, priority]);

  return (
    <AuthGuard>
      <Navbar />

      <main className="min-h-screen bg-gray-100">
        <section className="bg-[#111827] px-6 py-10 text-white">
          <div className="mx-auto max-w-7xl">
            <p className="font-bold text-[#ffcc00]">Case Management</p>
            <h2 className="mt-2 text-3xl font-black">Incident List</h2>
            <p className="mt-2 max-w-2xl text-gray-300">
              Search, filter, review, and track customer support incidents.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-6 py-8">
          {errorMessage && (
            <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 p-5 font-semibold text-[#d40511]">
              {errorMessage}
            </div>
          )}

          <div className="-mt-16 rounded-3xl bg-white p-6 shadow-lg">
            <div className="grid gap-4 md:grid-cols-3">
              <input
                className="rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511]"
                placeholder="Search ticket, shipment, title..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />

              <select
                className="rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511]"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option>All</option>
                <option>Draft</option>
                <option>Reviewed</option>
                <option>Assigned</option>
                <option>In Progress</option>
                <option>Resolved</option>
                <option>Closed</option>
              </select>

              <select
                className="rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511]"
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
              >
                <option>All</option>
                <option>Low</option>
                <option>Medium</option>
                <option>High</option>
                <option>Urgent</option>
              </select>
            </div>
          </div>

          <section className="mt-6 rounded-3xl bg-white p-6 shadow-sm">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <h3 className="text-xl font-black text-[#111827]">
                  All Incidents
                </h3>
                <p className="text-sm text-gray-500">
                  Showing {filteredIncidents.length} result(s)
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-sm">
                <thead>
                  <tr className="border-b bg-[#ffcc00]/30 text-left">
                    <th className="p-3">Ticket</th>
                    <th className="p-3">Title</th>
                    <th className="p-3">Shipment</th>
                    <th className="p-3">Category</th>
                    <th className="p-3">Priority</th>
                    <th className="p-3">Department</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredIncidents.map((incident) => (
                    <tr
                      key={incident.id}
                      className="border-b hover:bg-yellow-50"
                    >
                      <td className="p-3 font-black text-[#d40511]">
                        {incident.ticket_id}
                      </td>
                      <td className="p-3 font-semibold">{incident.title}</td>
                      <td className="p-3">{incident.shipment_id || "-"}</td>
                      <td className="p-3">{incident.category}</td>
                      <td className="p-3">
                        <PriorityBadge priority={incident.priority} />
                      </td>
                      <td className="p-3">{incident.department}</td>
                      <td className="p-3">
                        <StatusBadge status={incident.status} />
                      </td>
                      <td className="p-3">
  <Link
    href={`/incidents/${incident.id}`}
    className="rounded-full bg-[#111827] px-4 py-2 text-xs font-black text-white hover:bg-[#d40511]"
  >
    View
  </Link>
</td>
                    </tr>
                  ))}

                  {filteredIncidents.length === 0 && (
                    <tr>
                      <td colSpan="8" className="p-8 text-center text-gray-500">
                        No incidents found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </section>
      </main>
    </AuthGuard>
  );
}

function PriorityBadge({ priority }) {
  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-black ${
        priority === "Urgent"
          ? "bg-[#d40511] text-white"
          : priority === "High"
          ? "bg-orange-100 text-orange-700"
          : priority === "Medium"
          ? "bg-yellow-100 text-yellow-800"
          : "bg-gray-100 text-gray-700"
      }`}
    >
      {priority}
    </span>
  );
}

function StatusBadge({ status }) {
  return (
    <span className="rounded-full bg-gray-900 px-3 py-1 text-xs font-bold text-white">
      {status}
    </span>
  );
}