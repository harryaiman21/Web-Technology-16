"use client";

import { useEffect, useState } from "react";
import AuthGuard from "../../components/AuthGuard";
import Navbar from "../../components/Navbar";
import { supabase, isSupabaseConfigured } from "../../lib/supabaseClient";

export default function ReportsPage() {
  const [incidents, setIncidents] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    fetchIncidents();
  }, []);

  async function fetchIncidents() {
    if (!isSupabaseConfigured || !supabase) {
      setErrorMessage("Supabase is not connected. Check your .env.local file.");
      return;
    }

    const { data, error } = await supabase.from("incidents").select("*");

    if (error) {
      setErrorMessage(error.message);
      return;
    }

    setIncidents(data || []);
  }

  const total = incidents.length;
  const urgent = incidents.filter((i) => i.priority === "Urgent").length;
  const high = incidents.filter((i) => i.priority === "High").length;
  const open = incidents.filter((i) => i.status !== "Closed").length;
  const closed = incidents.filter((i) => i.status === "Closed").length;

  const categoryCounts = incidents.reduce((acc, item) => {
    acc[item.category] = (acc[item.category] || 0) + 1;
    return acc;
  }, {});

  const departmentCounts = incidents.reduce((acc, item) => {
    acc[item.department] = (acc[item.department] || 0) + 1;
    return acc;
  }, {});

  return (
    <AuthGuard>
      <Navbar />

      <main className="min-h-screen bg-gray-100">
        <section className="bg-[#111827] px-6 py-10 text-white">
          <div className="mx-auto max-w-7xl">
            <p className="font-bold text-[#ffcc00]">Management Overview</p>
            <h2 className="mt-2 text-3xl font-black">Incident Reports</h2>
            <p className="mt-2 max-w-2xl text-gray-300">
              Consolidated reporting for DHL customer support incident volume,
              priorities, categories, and departments.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-7xl px-6 py-8">
          {errorMessage && (
            <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 p-5 font-semibold text-[#d40511]">
              {errorMessage}
            </div>
          )}

          <div className="-mt-16 grid gap-5 md:grid-cols-5">
            <ReportCard title="Total" value={total} />
            <ReportCard title="Open" value={open} />
            <ReportCard title="Closed" value={closed} />
            <ReportCard title="High" value={high} />
            <ReportCard title="Urgent" value={urgent} />
          </div>

          <div className="mt-8 grid gap-6 lg:grid-cols-2">
            <section className="rounded-3xl bg-white p-6 shadow-sm">
              <h3 className="text-xl font-black text-[#111827]">
                Incidents by Category
              </h3>

              <div className="mt-5 space-y-3">
                {Object.entries(categoryCounts).map(([category, count]) => (
                  <ReportRow key={category} label={category} value={count} />
                ))}

                {Object.keys(categoryCounts).length === 0 && (
                  <p className="text-sm text-gray-500">No data available.</p>
                )}
              </div>
            </section>

            <section className="rounded-3xl bg-white p-6 shadow-sm">
              <h3 className="text-xl font-black text-[#111827]">
                Incidents by Department
              </h3>

              <div className="mt-5 space-y-3">
                {Object.entries(departmentCounts).map(([department, count]) => (
                  <ReportRow key={department} label={department} value={count} />
                ))}

                {Object.keys(departmentCounts).length === 0 && (
                  <p className="text-sm text-gray-500">No data available.</p>
                )}
              </div>
            </section>
          </div>

          <section className="mt-8 rounded-3xl border-l-4 border-[#d40511] bg-white p-6 shadow-sm">
            <h3 className="text-xl font-black text-[#111827]">
              RPA Execution Summary
            </h3>
            <p className="mt-2 text-gray-600">
              This section can later show UiPath execution results such as
              created incidents, duplicate cases skipped, failed uploads, error
              logs, and summary email status.
            </p>

            <div className="mt-5 grid gap-4 md:grid-cols-4">
              <MiniBox label="Created by RPA" value="0" />
              <MiniBox label="Duplicates" value="0" />
              <MiniBox label="Failed" value="0" />
              <MiniBox label="Last Run" value="Pending" />
            </div>
          </section>
        </section>
      </main>
    </AuthGuard>
  );
}

function ReportCard({ title, value }) {
  return (
    <div className="rounded-3xl border-t-4 border-[#d40511] bg-white p-6 shadow-lg">
      <p className="text-sm font-black uppercase tracking-wide text-gray-500">
        {title}
      </p>
      <p className="mt-3 text-4xl font-black text-[#111827]">{value}</p>
    </div>
  );
}

function ReportRow({ label, value }) {
  return (
    <div className="flex items-center justify-between rounded-2xl bg-gray-50 px-5 py-4">
      <span className="font-semibold text-gray-800">{label}</span>
      <span className="rounded-full bg-[#ffcc00] px-4 py-1 font-black text-[#111827]">
        {value}
      </span>
    </div>
  );
}

function MiniBox({ label, value }) {
  return (
    <div className="rounded-2xl bg-[#ffcc00]/25 p-4">
      <p className="text-xs font-black uppercase tracking-wide text-gray-500">
        {label}
      </p>
      <p className="mt-2 font-black text-[#111827]">{value}</p>
    </div>
  );
}