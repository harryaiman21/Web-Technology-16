"use client";

import { useState } from "react";
import AuthGuard from "../../components/AuthGuard";
import Navbar from "../../components/Navbar";
import { supabase, isSupabaseConfigured } from "../../lib/supabaseClient";
import {
  generateTicketId,
  makeSimpleHash,
  suggestIncident,
} from "../../lib/incidentLogic";

export default function UploadPage() {
  const [source, setSource] = useState("Email");
  const [rawText, setRawText] = useState("");
  const [attachmentName, setAttachmentName] = useState("");
  const [message, setMessage] = useState("");

  async function handleFileChange(e) {
    const file = e.target.files?.[0];

    if (!file) return;

    setAttachmentName(file.name);

    if (file.type === "text/plain" || file.name.endsWith(".txt")) {
      const text = await file.text();
      setRawText(text);
      setMessage("TXT file loaded successfully.");
    } else {
      setMessage(
        "File selected. For this MVP, please paste PDF/DOCX content into the raw text box."
      );
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setMessage("");

    if (!isSupabaseConfigured || !supabase) {
      setMessage("Supabase is not connected. Check your .env.local file.");
      return;
    }

    if (!rawText.trim()) {
      setMessage("Please enter or upload raw incident text.");
      return;
    }

    const suggestion = suggestIncident(rawText);
    const duplicateHash = makeSimpleHash(rawText);

    const fourteenDaysAgo = new Date();
    fourteenDaysAgo.setDate(fourteenDaysAgo.getDate() - 14);

    const { data: existing } = await supabase
      .from("incidents")
      .select("id, ticket_id")
      .eq("duplicate_hash", duplicateHash)
      .gte("created_at", fourteenDaysAgo.toISOString())
      .limit(1)
      .maybeSingle();

    if (existing) {
      setMessage(
        `Duplicate detected. This looks similar to ticket ${existing.ticket_id}.`
      );
      return;
    }

    const ticketId = generateTicketId();

    const { data, error } = await supabase
      .from("incidents")
      .insert({
        ticket_id: ticketId,
        title: suggestion.title,
        shipment_id: suggestion.shipmentId,
        source,
        category: suggestion.category,
        priority: suggestion.priority,
        department: suggestion.department,
        status: "Draft",
        customer_issue: suggestion.customerIssue,
        clean_summary: suggestion.cleanSummary,
        raw_text: rawText,
        created_by: "Support Agent",
        duplicate_hash: duplicateHash,
        attachment_name: attachmentName || null,
      })
      .select()
      .single();

    if (error) {
      setMessage(error.message);
      return;
    }

    await supabase.from("incident_history").insert({
      incident_id: data.id,
      status: "Draft",
      updated_by: "Support Agent",
      remarks: "Incident created from uploaded raw input.",
    });

    setRawText("");
    setAttachmentName("");
    setMessage(`Incident created successfully as ${ticketId}.`);
  }

  return (
    <AuthGuard>
      <Navbar />

      <main className="min-h-screen bg-gray-100">
        <section className="bg-[#111827] px-6 py-10 text-white">
          <div className="mx-auto max-w-5xl">
            <p className="font-bold text-[#ffcc00]">Incident Intake</p>
            <h2 className="mt-2 text-3xl font-black">Upload Raw Incident</h2>
            <p className="mt-2 max-w-2xl text-gray-300">
              Convert messy customer support information into a structured DHL
              incident draft.
            </p>
          </div>
        </section>

        <section className="mx-auto max-w-5xl px-6 py-8">
          <form
            onSubmit={handleSubmit}
            className="rounded-3xl bg-white p-8 shadow-lg"
          >
            <div className="grid gap-6">
              <div className="rounded-2xl border-l-4 border-[#d40511] bg-[#ffcc00]/20 p-5">
                <h3 className="font-black text-[#111827]">
                  AI-Assisted Incident Drafting
                </h3>
                <p className="mt-1 text-sm text-gray-700">
                  The system will suggest category, priority, department, and
                  clean summary based on the raw text.
                </p>
              </div>

              <div>
                <label className="text-sm font-black text-gray-700">
                  Source Type
                </label>
                <select
                  className="mt-2 w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511]"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                >
                  <option>Email</option>
                  <option>WhatsApp</option>
                  <option>Teams Chat</option>
                  <option>Phone Call Note</option>
                  <option>Warehouse Note</option>
                  <option>Multiple Sources</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-black text-gray-700">
                  Upload File
                </label>
                <input
                  className="mt-2 w-full rounded-xl border border-dashed border-gray-400 bg-gray-50 px-4 py-4"
                  type="file"
                  accept=".txt,.pdf,.docx"
                  onChange={handleFileChange}
                />

                <p className="mt-2 text-xs font-medium text-gray-500">
                  Supported for MVP: TXT auto-read. PDF/DOCX can be selected,
                  then paste extracted text manually.
                </p>

                {attachmentName && (
                  <p className="mt-2 text-sm font-bold text-[#d40511]">
                    Selected file: {attachmentName}
                  </p>
                )}
              </div>

              <div>
                <label className="text-sm font-black text-gray-700">
                  Raw Incident Text
                </label>
                <textarea
                  className="mt-2 h-72 w-full rounded-xl border border-gray-300 px-4 py-3 outline-none focus:border-[#d40511] focus:ring-2 focus:ring-red-100"
                  value={rawText}
                  onChange={(e) => setRawText(e.target.value)}
                  placeholder="Paste raw customer complaint, email, WhatsApp message, call note, or warehouse remark here..."
                />
              </div>

              {message && (
                <p className="rounded-2xl border border-yellow-300 bg-yellow-50 px-5 py-4 text-sm font-semibold text-gray-800">
                  {message}
                </p>
              )}

              <button className="rounded-xl bg-[#d40511] px-6 py-4 font-black text-white shadow-md transition hover:bg-red-700">
                Generate Incident Draft
              </button>
            </div>
          </form>
        </section>
      </main>
    </AuthGuard>
  );
}