# DHL Knowledge Base Automation (Scenario 1)

Mahmoud Ali - A22MJ3006

SECJ3483 Web Technology - Individual Assignment  
Scenario: AI-Powered Knowledge Base Automation for DHL Logistics Operations

This project is a Next.js + JSON Server web app that simulates:

- messy logistics input transformed into SOP draft articles
- workflow from `Draft -> Reviewed -> Published`
- role-based operations (editor, reviewer, admin)
- RPA-ready UI IDs and automation logs

## Tech Stack

- Next.js (App Router, JavaScript)
- Tailwind CSS
- JSON Server (mock backend REST API)

## 1) Install Dependencies

```bash
npm install
```

## 2) Configure Environment Variable

Create a `.env.local` file in project root:

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:4000
```

If this is not provided, the app automatically falls back to `http://localhost:4000`.

- Note: The ".env.example" file is already in the "Source Code(Website)" submission folder, so you may skip this step.

## 3) Start Mock Backend (JSON Server)

```bash
npm run mock-api
```

This serves `db.json` at:

- `http://localhost:4000/users`
- `http://localhost:4000/articles`
- `http://localhost:4000/rpaRuns`

## 4) Start Next.js Frontend

Open another terminal:

```bash
npm run dev
```

Frontend URL: [http://localhost:3000](http://localhost:3000)

## 5) Demo Accounts

Use users in `db.json`:

- Editor: `mahmoud` / `pass123`
- Reviewer: `aisyah` / `pass123`
- Admin: `farid` / `pass123`

You can also login with email (for example `mahmoud@dhl.local`).

## Project Structure

```text
src/
  app/
    page.js
    viewer/page.js
  components/
    LoginPanel.js
    UploadConsole.js
    VersionHistory.js
  lib/
    api.js
    articleUtils.js
    session.js
    guards.js
```
