"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  createArticle,
  deleteArticle,
  getArticles,
  getRpaRuns,
  replaceArticle,
  updateArticle,
} from "@/lib/api";
import VersionHistory from "@/components/VersionHistory";
import {
  canDuplicateArticle,
  canEditArticle,
  canPublish,
  computeSimilarityByTagsAndWords,
  formatDateTime,
  getNextStatuses,
  simpleFingerprint,
} from "@/lib/articleUtils";
import { getRoleGuard } from "@/lib/guards";
import { clearSession, loadSession } from "@/lib/session";
import { useRouter } from "next/navigation";

const SORT_OPTIONS = [
  { value: "newest", label: "Newest" },
  { value: "oldest", label: "Oldest" },
];

function inDateRange(value, from, to) {
  if (!value) return true;
  const date = new Date(value);
  if (from && date < new Date(from)) return false;
  if (to && date > new Date(`${to}T23:59:59`)) return false;
  return true;
}

export default function ViewerPage() {
  const router = useRouter();
  const [currentUser, setCurrentUser] = useState(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [articles, setArticles] = useState([]);
  const [rpaRuns, setRpaRuns] = useState([]);
  const [editingId, setEditingId] = useState("");
  const [editForm, setEditForm] = useState({
    title: "",
    summary: "",
    stepsText: "",
    tagsText: "",
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [tagFilter, setTagFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [creatorFilter, setCreatorFilter] = useState("All");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const [sortOrder, setSortOrder] = useState("newest");
  const [feedback, setFeedback] = useState("");
  const [expandedContent, setExpandedContent] = useState({});

  useEffect(() => {
    setCurrentUser(loadSession());
    setSessionReady(true);
  }, []);

  useEffect(() => {
    if (!sessionReady) return;

    if (!currentUser) {
      router.push("/");
      return;
    }

    async function loadData() {
      try {
        const [articleData, runData] = await Promise.all([getArticles(), getRpaRuns()]);
        setArticles(articleData);
        setRpaRuns(runData);
      } catch {
        setFeedback("Unable to load data. Confirm mock API is running.");
      }
    }

    loadData();
  }, [currentUser, router, sessionReady]);

  const tags = useMemo(() => {
    return [...new Set(articles.flatMap((article) => article.tags || []))];
  }, [articles]);

  const creators = useMemo(() => {
    return [...new Set(articles.map((article) => article.creatorName).filter(Boolean))];
  }, [articles]);

  const dashboard = useMemo(() => {
    return {
      Draft: articles.filter((article) => article.status === "Draft").length,
      Reviewed: articles.filter((article) => article.status === "Reviewed").length,
      Published: articles.filter((article) => article.status === "Published").length,
    };
  }, [articles]);

  const filteredArticles = useMemo(() => {
    const term = searchTerm.toLowerCase();
    const result = articles.filter((article) => {
      const titleMatch = article.title?.toLowerCase().includes(term);
      const summaryMatch = article.summary?.toLowerCase().includes(term);
      const contentMatch = article.content?.toLowerCase().includes(term);
      const tagMatch = (article.tags || []).join(" ").toLowerCase().includes(term);
      const matchesSearch = !term || titleMatch || summaryMatch || contentMatch || tagMatch;
      const matchesTag = tagFilter === "All" || (article.tags || []).includes(tagFilter);
      const matchesStatus = statusFilter === "All" || article.status === statusFilter;
      const matchesCreator =
        creatorFilter === "All" || article.creatorName === creatorFilter;
      const matchesDate = inDateRange(article.createdAt, fromDate, toDate);

      return (
        matchesSearch &&
        matchesTag &&
        matchesStatus &&
        matchesCreator &&
        matchesDate
      );
    });

    const sorted = [...result].sort((a, b) => {
      const aDate = new Date(a.createdAt).getTime();
      const bDate = new Date(b.createdAt).getTime();
      return sortOrder === "newest" ? bDate - aDate : aDate - bDate;
    });

    return sorted;
  }, [
    articles,
    creatorFilter,
    fromDate,
    searchTerm,
    sortOrder,
    statusFilter,
    tagFilter,
    toDate,
  ]);

  async function handleDelete(articleId) {
    if (!currentUser || currentUser.role !== "admin") {
      setFeedback("Only admin can delete articles.");
      return;
    }

    try {
      await deleteArticle(articleId);
      setArticles((current) => current.filter((item) => item.id !== articleId));
      setFeedback("Article deleted successfully.");
    } catch {
      setFeedback("Delete failed.");
    }
  }

  async function handleStatusChange(article, nextStatus) {
    if (article.status === nextStatus) return;
    if (!currentUser || !["reviewer", "admin"].includes(currentUser.role)) {
      setFeedback("Only reviewer/admin can move workflow status.");
      return;
    }
    if (!getNextStatuses(article.status).includes(nextStatus)) {
      setFeedback("Invalid workflow: Draft -> Reviewed -> Published only.");
      return;
    }

    if (nextStatus === "Published" && !canPublish(currentUser)) {
      setFeedback("Only reviewer/admin can publish.");
      return;
    }

    const nextHistory = [
      ...(article.history || []),
      {
        previousStatus: article.status,
        newStatus: nextStatus,
        changedBy: currentUser.name,
        changedAt: new Date().toISOString(),
        comment: "Status updated in Viewer page.",
      },
    ];

    try {
      const updates = {
        status: nextStatus,
        history: nextHistory,
        updatedAt: new Date().toISOString(),
      };
      if (nextStatus === "Reviewed") {
        updates.reviewedBy = currentUser.name;
        updates.reviewedAt = new Date().toISOString();
      }
      if (nextStatus === "Published") {
        updates.publishedBy = currentUser.name;
        updates.publishedAt = new Date().toISOString();
      }

      const updated = await updateArticle(article.id, {
        ...updates,
      });

      setArticles((current) =>
        current.map((item) => (item.id === article.id ? updated : item)),
      );
      setFeedback(`Status for "${article.title}" changed to ${nextStatus}.`);
    } catch {
      setFeedback("Status update failed.");
    }
  }

  function openEdit(article) {
    setEditingId(article.id);
    setEditForm({
      title: article.title || "",
      summary: article.summary || "",
      stepsText: (article.steps || []).join("\n"),
      tagsText: (article.tags || []).join(", "),
    });
  }

  async function saveEdit(article) {
    if (!canEditArticle(currentUser, article)) {
      setFeedback("You cannot edit this article in current role/status.");
      return;
    }

    const steps = editForm.stepsText
      .split("\n")
      .map((step) => step.trim())
      .filter(Boolean);
    const tags = editForm.tagsText
      .split(",")
      .map((tag) => tag.trim())
      .filter(Boolean);
    const contentChanged =
      editForm.title !== (article.title || "") ||
      editForm.summary !== (article.summary || "") ||
      steps.join("\n") !== (article.steps || []).join("\n") ||
      tags.join(",") !== (article.tags || []).join(",");
    if (!contentChanged) {
      setFeedback("No content changes detected.");
      setEditingId("");
      return;
    }

    const now = new Date().toISOString();
    const nextVersion = (article.version || 1) + 1;
    const nextHistory = [
      ...(article.history || []),
      {
        previousStatus: article.status,
        newStatus: article.status,
        changedBy: currentUser.name,
        changedAt: now,
        comment: "Content edited.",
      },
    ];

    const fingerprint = simpleFingerprint(editForm.title, article.content);
    const duplicateFound = articles.some(
      (item) =>
        item.id !== article.id &&
        item.duplicateHash === fingerprint &&
        Date.now() - new Date(item.createdAt).getTime() <= 14 * 24 * 60 * 60 * 1000,
    );

    const sourceArticle = {
      title: editForm.title,
      tags,
      content: article.content,
    };
    const similarPublished = articles.find((item) => {
      if (item.id === article.id || item.status !== "Published") return false;
      return computeSimilarityByTagsAndWords(sourceArticle, item) >= 2;
    });

    try {
      const updated = await replaceArticle(article.id, {
        ...article,
        title: editForm.title,
        summary: editForm.summary,
        steps,
        tags,
        updatedAt: now,
        version: nextVersion,
        duplicateHash: fingerprint,
        duplicateFlag: duplicateFound,
        conflictFlag: Boolean(similarPublished),
        outdatedFlag: Boolean(similarPublished && article.status === "Draft"),
        history: nextHistory,
      });
      setArticles((current) =>
        current.map((item) => (item.id === article.id ? updated : item)),
      );
      setEditingId("");
      setFeedback(`Article updated. Version is now ${nextVersion}.`);
    } catch {
      setFeedback("Failed to update article.");
    }
  }

  async function duplicateArticle(article) {
    if (!canDuplicateArticle(currentUser)) {
      setFeedback("Only editor/admin can duplicate articles.");
      return;
    }
    const now = new Date().toISOString();
    const copy = {
      ...article,
      id: `a${Date.now()}`,
      title: `${article.title} (Copy)`,
      status: "Draft",
      reviewedBy: "",
      publishedBy: "",
      reviewedAt: "",
      publishedAt: "",
      creatorId: currentUser.id,
      creatorName: currentUser.name,
      createdAt: now,
      updatedAt: now,
      version: 1,
      history: [
        {
          previousStatus: "New",
          newStatus: "Draft",
          changedBy: currentUser.name,
          changedAt: now,
          comment: "Copied from existing article.",
        },
      ],
    };
    try {
      const created = await createArticle(copy);
      setArticles((current) => [created, ...current]);
      setFeedback("Article duplicated into a new draft.");
    } catch {
      setFeedback("Failed to duplicate article.");
    }
  }

  function handleLogout() {
    clearSession();
    router.push("/");
  }

  function handleResetFilters() {
    setSearchTerm("");
    setTagFilter("All");
    setStatusFilter("All");
    setCreatorFilter("All");
    setFromDate("");
    setToDate("");
    setSortOrder("newest");
  }

  function toggleExpanded(articleId) {
    setExpandedContent((current) => ({
      ...current,
      [articleId]: !current[articleId],
    }));
  }

  function statusBadgeClass(status) {
    if (status === "Draft") return "bg-amber-100 text-amber-900";
    if (status === "Reviewed") return "bg-blue-100 text-blue-900";
    if (status === "Published") return "bg-green-100 text-green-900";
    return "bg-slate-100 text-slate-900";
  }

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-8">
      {sessionReady ? <div className="mx-auto max-w-5xl space-y-6">
        <header className="rounded-lg bg-slate-900 p-6 text-white shadow">
          <h1 className="text-2xl font-semibold">Viewer Page</h1>
          <p className="mt-1 text-sm text-slate-200">
            Search, filter, and track SOP version progress.
          </p>
          <p id="viewer-user-info" className="mt-1 text-xs text-slate-300">
            Logged in: {currentUser?.name} ({currentUser?.role})
          </p>
          <Link id="viewer-back-home-link" href="/" className="mt-4 inline-block underline">
            Back to Login & Upload
          </Link>
          <button
            id="viewer-logout-button"
            className="ml-4 rounded bg-red-600 px-3 py-1 text-sm text-white"
            onClick={handleLogout}
            type="button"
          >
            Logout
          </button>
        </header>

        <section id="viewer-dashboard-cards" className="grid gap-3 md:grid-cols-3">
          <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-sm text-slate-500">Draft</p>
            <p className="text-2xl font-semibold">{dashboard.Draft}</p>
          </div>
          <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-sm text-slate-500">Reviewed</p>
            <p className="text-2xl font-semibold">{dashboard.Reviewed}</p>
          </div>
          <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
            <p className="text-sm text-slate-500">Published</p>
            <p className="text-2xl font-semibold">{dashboard.Published}</p>
          </div>
        </section>

        <section className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <div className="grid gap-3 md:grid-cols-4">
            <input
              id="viewer-search-input"
              className="rounded-md border border-slate-300 px-3 py-2"
              placeholder="Search title, summary, content, tags"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
            />

            <select
              id="viewer-tag-filter"
              className="rounded-md border border-slate-300 px-3 py-2"
              value={tagFilter}
              onChange={(event) => setTagFilter(event.target.value)}
            >
              <option value="All">All Tags</option>
              {tags.map((tag) => (
                <option key={tag} value={tag}>
                  {tag}
                </option>
              ))}
            </select>

            <select
              id="viewer-status-filter"
              className="rounded-md border border-slate-300 px-3 py-2"
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
            >
              <option value="All">All Statuses</option>
              {["Draft", "Reviewed", "Published"].map((status) => (
                <option key={status} value={status}>
                  {status}
                </option>
              ))}
            </select>

            <select
              id="viewer-creator-filter"
              className="rounded-md border border-slate-300 px-3 py-2"
              value={creatorFilter}
              onChange={(event) => setCreatorFilter(event.target.value)}
            >
              <option value="All">All Creators</option>
              {creators.map((creatorName) => (
                <option key={creatorName} value={creatorName}>
                  {creatorName}
                </option>
              ))}
            </select>

            <input
              id="viewer-from-date-input"
              type="date"
              className="rounded-md border border-slate-300 px-3 py-2"
              value={fromDate}
              onChange={(event) => setFromDate(event.target.value)}
            />

            <input
              id="viewer-to-date-input"
              type="date"
              className="rounded-md border border-slate-300 px-3 py-2"
              value={toDate}
              onChange={(event) => setToDate(event.target.value)}
            />

            <select
              id="viewer-sort-select"
              className="rounded-md border border-slate-300 px-3 py-2"
              value={sortOrder}
              onChange={(event) => setSortOrder(event.target.value)}
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>

            <button
              id="viewer-reset-filters-button"
              type="button"
              className="rounded-md bg-slate-700 px-3 py-2 text-white"
              onClick={handleResetFilters}
            >
              Reset Filters
            </button>
          </div>
        </section>

        {feedback ? (
          <p id="viewer-feedback-text" className="text-sm text-slate-700">
            {feedback}
          </p>
        ) : null}

        <section id="viewer-articles-list" className="space-y-4">
          {filteredArticles.length === 0 ? (
            <div id="viewer-empty-state" className="rounded-lg bg-white p-6 text-sm text-slate-600">
              No articles match your current search and filters. Try reset filters or create a new draft.
            </div>
          ) : null}

          {filteredArticles.map((article) => (
            <article key={article.id} className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
              {(() => {
                const guard = getRoleGuard(currentUser, article);
                return (
                  <>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h2 className="text-lg font-semibold text-slate-900">{article.title}</h2>
                  <p className="mt-1 text-sm text-black">
                    Creator: {article.creatorName} | Created: {formatDateTime(article.createdAt)}
                  </p>
                  <p className="mt-1 text-sm text-black">
                    Source: {article.sourceType} ({article.ingestionSource})
                  </p>
                  <p
                    className={`mt-1 inline-block rounded px-2 py-1 text-xs font-semibold ${statusBadgeClass(article.status)}`}
                  >
                    Status: {article.status}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  {guard.canEdit ? (
                    <button
                      id={`article-edit-button-${article.id}`}
                      className="rounded-md bg-blue-600 px-3 py-2 text-sm text-white"
                      onClick={() => openEdit(article)}
                      type="button"
                    >
                      Edit
                    </button>
                  ) : null}
                  {guard.canDuplicate ? (
                    <button
                      id={`article-copy-button-${article.id}`}
                      className="rounded-md bg-amber-500 px-3 py-2 text-sm text-slate-900"
                      onClick={() => duplicateArticle(article)}
                      type="button"
                    >
                      Duplicate
                    </button>
                  ) : null}
                  {guard.canDelete ? (
                    <button
                      id={`article-delete-button-${article.id}`}
                      className="rounded-md bg-red-600 px-3 py-2 text-sm text-white hover:bg-red-700"
                      onClick={() => handleDelete(article.id)}
                      type="button"
                    >
                      Delete
                    </button>
                  ) : null}
                </div>
              </div>

              <p className="mt-3 text-sm text-slate-700">{article.summary}</p>
              <p className="mt-2 text-sm text-black">
                {expandedContent[article.id]
                  ? article.content
                  : `${(article.content || "").slice(0, 180)}${
                      (article.content || "").length > 180 ? "..." : ""
                    }`}
              </p>
              {(article.content || "").length > 180 ? (
                <button
                  id={`article-content-toggle-${article.id}`}
                  type="button"
                  className="mt-1 text-xs text-blue-700 underline"
                  onClick={() => toggleExpanded(article.id)}
                >
                  {expandedContent[article.id] ? "Show less" : "Show more"}
                </button>
              ) : null}
              <ol className="mt-2 list-decimal pl-5 text-sm text-slate-700">
                {(article.steps || []).map((step, idx) => (
                  <li key={`${article.id}-step-${idx}`}>{step}</li>
                ))}
              </ol>

              <div className="mt-3 grid gap-2 rounded-md bg-slate-50 p-3 text-sm text-black md:grid-cols-2">
                <p>Tags: {(article.tags || []).join(", ") || "-"}</p>
                <p>Version: {article.version || 1}</p>
                <p>Created: {formatDateTime(article.createdAt)}</p>
                <p>Updated: {formatDateTime(article.updatedAt)}</p>
                <p>Reviewed by: {article.reviewedBy || "-"}</p>
                <p>Published by: {article.publishedBy || "-"}</p>
                <p>Source reference: {article.sourceReference || "-"}</p>
                <p>Related links: {(article.relatedLinks || []).join(", ") || "-"}</p>
              </div>

              {(article.attachments || []).length > 0 ? (
                <ul className="mt-2 rounded-md bg-slate-50 p-3 text-sm text-black">
                  {(article.attachments || []).map((attachment, index) => (
                    <li key={`${article.id}-attachment-${index}`}>
                      {attachment.name} ({Math.round((attachment.size || 0) / 1024)} KB,{" "}
                      {attachment.type || "unknown"})
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-2 text-sm text-black">No attachments.</p>
              )}

              {article.duplicateFlag ? (
                <p className="mt-1 inline-block rounded bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-800">
                  Duplicate warning: possible match in last 14 days
                </p>
              ) : null}
              {article.conflictFlag ? (
                <p className="mt-1 inline-block rounded bg-orange-100 px-2 py-1 text-xs font-semibold text-orange-800">
                  Conflict warning: similar published SOP exists
                </p>
              ) : null}
              {article.outdatedFlag ? (
                <p className="mt-1 inline-block rounded bg-red-100 px-2 py-1 text-xs font-semibold text-red-800">
                  Outdated warning: verify if this should be a revision
                </p>
              ) : null}

              {guard.canChangeStatus && getNextStatuses(article.status).length > 0 ? (
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <label
                    htmlFor={`article-status-select-${article.id}`}
                    className="text-sm font-medium"
                  >
                    Next Status
                  </label>
                  <select
                    id={`article-status-select-${article.id}`}
                    className="rounded-md border border-slate-300 px-3 py-1"
                    value=""
                    onChange={(event) => handleStatusChange(article, event.target.value)}
                  >
                    <option value="">Current: {article.status}</option>
                    {getNextStatuses(article.status).map((status) => (
                      <option key={status} value={status}>
                        Move to {status}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}
              {guard.canChangeStatus && getNextStatuses(article.status).length === 0 ? (
                <p className="mt-2 text-xs text-black">
                  This article is in final status. No further workflow transition is available.
                </p>
              ) : null}

              {editingId === article.id ? (
                <div className="mt-4 rounded-md border border-slate-200 bg-slate-50 p-4">
                  <h3 className="font-semibold text-slate-800">Edit Article</h3>
                  <div className="mt-2 grid gap-2">
                    <input
                      id={`article-edit-title-input-${article.id}`}
                      className="rounded border border-slate-300 px-3 py-2"
                      value={editForm.title}
                      onChange={(event) =>
                        setEditForm((current) => ({
                          ...current,
                          title: event.target.value,
                        }))
                      }
                    />
                    <textarea
                      id={`article-edit-summary-input-${article.id}`}
                      className="h-20 rounded border border-slate-300 px-3 py-2"
                      value={editForm.summary}
                      onChange={(event) =>
                        setEditForm((current) => ({
                          ...current,
                          summary: event.target.value,
                        }))
                      }
                    />
                    <textarea
                      id={`article-edit-steps-input-${article.id}`}
                      className="h-24 rounded border border-slate-300 px-3 py-2"
                      value={editForm.stepsText}
                      onChange={(event) =>
                        setEditForm((current) => ({
                          ...current,
                          stepsText: event.target.value,
                        }))
                      }
                    />
                    <input
                      id={`article-edit-tags-input-${article.id}`}
                      className="rounded border border-slate-300 px-3 py-2"
                      value={editForm.tagsText}
                      onChange={(event) =>
                        setEditForm((current) => ({
                          ...current,
                          tagsText: event.target.value,
                        }))
                      }
                    />
                    <div className="flex gap-2">
                      <button
                        id={`article-edit-save-button-${article.id}`}
                        className="rounded bg-green-600 px-3 py-2 text-sm text-white"
                        type="button"
                        onClick={() => saveEdit(article)}
                      >
                        Save
                      </button>
                      <button
                        id={`article-edit-cancel-button-${article.id}`}
                        className="rounded bg-slate-500 px-3 py-2 text-sm text-white"
                        type="button"
                        onClick={() => setEditingId("")}
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              ) : null}

              {(article.history || []).length > 0 ? (
                <VersionHistory history={article.history || []} />
              ) : (
                <p className="mt-2 text-sm text-black">No version history yet.</p>
              )}
                  </>
                );
              })()}
            </article>
          ))}
        </section>

        <section id="rpa-logs-panel" className="rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-lg font-semibold text-black">Automation Logs (RPA Runs)</h2>
          <p id="rpa-ready-note" className="text-xs text-black">
            RPA-ready stable selectors are available on login/upload/viewer controls.
          </p>
          <ul className="mt-3 space-y-2 text-sm text-slate-700">
            {rpaRuns.map((run) => (
              <li key={run.id} className="rounded bg-slate-50 p-3">
                <strong>{formatDateTime(run.runAt)}</strong> - {run.botName} - {run.status}
                <br />
                Trigger: {run.triggerSource} | Articles Created: {run.articlesCreated}
                <br />
                Notes: {run.notes}
              </li>
            ))}
          </ul>
        </section>
      </div> : null}
    </main>
  );
}
