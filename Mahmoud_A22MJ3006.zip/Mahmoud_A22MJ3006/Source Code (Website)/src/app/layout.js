import "./globals.css";

export const metadata = {
  title: "DHL Knowledge Base",
  description: "AI powered SOP management for DHL logistics operations",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
