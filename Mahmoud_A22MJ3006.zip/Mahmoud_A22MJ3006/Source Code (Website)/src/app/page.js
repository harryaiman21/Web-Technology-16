"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import LoginPanel from "@/components/LoginPanel";
import UploadConsole from "@/components/UploadConsole";
import { getArticles } from "@/lib/api";
import { canCreateArticle } from "@/lib/articleUtils";
import { clearSession, loadSession, saveSession } from "@/lib/session";

export default function HomePage() {
  const [currentUser, setCurrentUser] = useState(null);
  const [sessionReady, setSessionReady] = useState(false);
  const [articles, setArticles] = useState([]);
  const [message, setMessage] = useState("");

  useEffect(() => {
    setCurrentUser(loadSession());
    setSessionReady(true);
  }, []);

  useEffect(() => {
    async function run() {
      try {
        const articleData = await getArticles();
        setArticles(articleData);
      } catch {
        setMessage("Could not load articles. Is mock API running?");
      }
    }
    run();
  }, []);

  function handleLogin(user) {
    setCurrentUser(user);
    saveSession(user);
  }

  function handleLogout() {
    clearSession();
    setCurrentUser(null);
  }

  function handleArticleCreated(createdArticle) {
    setArticles((current) => [createdArticle, ...current]);
  }

  return (
    <main className="min-h-screen bg-slate-100 px-4 py-8">
      <div className="mx-auto max-w-4xl space-y-6">
        <header className="rounded-lg bg-slate-900 p-6 text-white shadow">
          <h1 className="text-2xl font-semibold">DHL AI Knowledge Base</h1>
          <p className="mt-1 text-sm text-slate-200">
            Manage logistics SOPs with draft-to-publish workflow.
          </p>
        </header>

        {sessionReady && !currentUser ? <LoginPanel onLogin={handleLogin} /> : null}

        {sessionReady && currentUser ? (
          <>
            <section
              id="login-session-panel"
              className="rounded-lg border border-red-100 bg-yellow-50 p-4 text-sm"
            >
              Logged in as <strong>{currentUser.name}</strong> ({currentUser.role}).
              <button
                id="logout-button"
                onClick={handleLogout}
                className="ml-4 rounded bg-red-600 px-3 py-1 text-white hover:bg-red-700"
                type="button"
              >
                Logout
              </button>
            </section>
            {canCreateArticle(currentUser) ? (
              <UploadConsole
                currentUser={currentUser}
                articles={articles}
                onArticleCreated={handleArticleCreated}
              />
            ) : (
              <section
                id="upload-access-note"
                className="rounded-lg border border-slate-200 bg-white p-4 text-sm text-slate-700"
              >
                Reviewer role can review/publish articles in Viewer page. Draft creation is for editor/admin.
              </section>
            )}
            <Link
              id="viewer-navigation-link"
              className="inline-block rounded-md bg-slate-900 px-4 py-2 text-white hover:bg-slate-700"
              href="/viewer"
            >
              Open Viewer Page
            </Link>
          </>
        ) : sessionReady ? (
          <p id="login-required-text" className="text-sm text-slate-600">
            Login to access the Upload Console.
          </p>
        ) : null}
        {message ? (
          <p id="home-status-text" className="text-sm text-red-700">
            {message}
          </p>
        ) : null}
      </div>
    </main>
  );
}
