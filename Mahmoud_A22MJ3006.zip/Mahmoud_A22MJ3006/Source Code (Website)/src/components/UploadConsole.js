"use client";

import { useState } from "react";
import { createArticle } from "@/lib/api";
import * as mammoth from "mammoth";
import {
  computeSimilarityByTagsAndWords,
  canCreateArticle,
  generateDraftFromSource,
  getSuggestedTitle,
  isWithinLastDays,
  simpleFingerprint,
} from "@/lib/articleUtils";

let pdfjsModulePromise;

async function loadPdfJs() {
  if (!pdfjsModulePromise) {
    pdfjsModulePromise = import("pdfjs-dist").then((module) => {
      module.GlobalWorkerOptions.workerSrc = "/pdfjs/pdf.worker.min.js";
      return module;
    });
  }
  return pdfjsModulePromise;
}

function makeId() {
  return `a${Date.now()}`;
}

const SOURCE_TYPES = ["text", "pdf", "docx", "email", "chat", "image"];
const MAX_FILE_SIZE = 3 * 1024 * 1024;
const ALLOWED_EXTENSIONS = [".pdf", ".doc", ".docx"];

function getExtension(filename) {
  const idx = filename.lastIndexOf(".");
  if (idx === -1) return "";
  return filename.slice(idx).toLowerCase();
}

function normalizeFileList(fileList) {
  return Array.from(fileList || []).map((file) => ({
    name: file.name,
    size: file.size,
    type: file.type || "unknown",
  }));
}

function readFileAsArrayBuffer(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Failed to read file."));
    reader.onabort = () => reject(new Error("File read aborted."));
    reader.onload = () => resolve(reader.result);
    reader.readAsArrayBuffer(file);
  });
}

async function extractTextFromPdfFile(file) {
  const { getDocument } = await loadPdfJs();
  const buffer = await readFileAsArrayBuffer(file);
  const data = new Uint8Array(buffer);
  const doc = await getDocument({ data }).promise;
  const parts = [];

  for (let pageNum = 1; pageNum <= doc.numPages; pageNum += 1) {
    const page = await doc.getPage(pageNum);
    const content = await page.getTextContent();
    const pageText = (content.items || [])
      .map((item) => item?.str)
      .filter(Boolean)
      .join(" ");
    parts.push(pageText);
  }

  return parts.join("\n\n").trim();
}

async function extractTextFromDocxFile(file) {
  const buffer = await readFileAsArrayBuffer(file);
  const result = await mammoth.extractRawText({ arrayBuffer: buffer });
  return (result?.value || "").trim();
}

export default function UploadConsole({
  currentUser,
  articles,
  onArticleCreated,
}) {
  const [sourceType, setSourceType] = useState("text");
  const [rawSourceText, setRawSourceText] = useState("");
  const [ingestionSource, setIngestionSource] = useState("Manual");
  const [sourceReference, setSourceReference] = useState("");
  const [attachments, setAttachments] = useState([]);
  const [draft, setDraft] = useState({
    title: "",
    summary: "",
    steps: ["", "", ""],
    tags: [],
    relatedLinks: [],
  });
  const [duplicateWarning, setDuplicateWarning] = useState("");
  const [conflictWarning, setConflictWarning] = useState("");
  const [outdatedWarning, setOutdatedWarning] = useState("");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [fileInputKey, setFileInputKey] = useState(0);

  async function handleAttachmentChange(event) {
    const fileList = event.target.files;
    const selectedFiles = Array.from(fileList || []);
    const selected = normalizeFileList(fileList);
    const invalid = selected.find((item) => {
      const extension = getExtension(item.name);
      return (
        !ALLOWED_EXTENSIONS.includes(extension) || item.size > MAX_FILE_SIZE
      );
    });

    if (invalid) {
      setMessage(
        "Invalid attachment detected. Only PDF/DOC/DOCX up to 3MB are allowed.",
      );
      setAttachments([]);
      return;
    }

    setAttachments(selected);
    setMessage("");

    // Auto-extract raw text from the selected file(s) when possible.
    try {
      const extractables = selectedFiles.filter((file) => {
        const extension = getExtension(file.name);
        return extension === ".pdf" || extension === ".docx";
      });

      const hasDoc = selectedFiles.some(
        (file) => getExtension(file.name) === ".doc",
      );
      if (hasDoc) {
        setMessage(
          "Note: .doc files are accepted as attachments, but only .pdf and .docx can be auto-extracted into Raw Source Text.",
        );
      }

      if (extractables.length === 0) return;

      setMessage("Extracting text from attachment(s)...");
      const extractedChunks = [];

      for (const file of extractables) {
        const extension = getExtension(file.name);
        const text =
          extension === ".pdf"
            ? await extractTextFromPdfFile(file)
            : await extractTextFromDocxFile(file);

        if (text) {
          extractedChunks.push(`--- ${file.name} ---\n${text}`);
        }
      }

      const combined = extractedChunks.join("\n\n").trim();
      if (combined) {
        setRawSourceText((current) =>
          current ? `${current}\n\n${combined}` : combined,
        );
        setMessage("Text extracted into Raw Source Text.");
      } else {
        setMessage("No extractable text found in the selected attachment(s).");
      }
    } catch (error) {
      setMessage(
        `Failed to extract text from attachment(s). ${error instanceof Error ? error.message : ""}`.trim(),
      );
    }
  }

  function handleGenerateDraft() {
    const generated = generateDraftFromSource(rawSourceText, sourceType);
    setDraft(generated);

    const hash = simpleFingerprint(generated.title, rawSourceText);
    const possibleDuplicate = articles.find(
      (article) =>
        article.duplicateHash === hash &&
        isWithinLastDays(article.createdAt, 14),
    );

    if (possibleDuplicate) {
      setDuplicateWarning(
        `Possible duplicate within 14 days: "${possibleDuplicate.title}". You can still save.`,
      );
    } else {
      setDuplicateWarning("");
    }

    const sourceArticle = {
      title: generated.title,
      content: rawSourceText,
      tags: generated.tags,
    };
    const similarPublished = articles.find((article) => {
      if (article.status !== "Published") return false;
      return computeSimilarityByTagsAndWords(sourceArticle, article) >= 2;
    });
    setConflictWarning(
      similarPublished
        ? `Conflict warning: Similar published article exists ("${similarPublished.title}").`
        : "",
    );

    setOutdatedWarning(
      similarPublished ? "Outdated warning: Check if this is a revision." : "",
    );
  }

  function updateStep(index, value) {
    setDraft((current) => {
      const nextSteps = [...current.steps];
      nextSteps[index] = value;
      return { ...current, steps: nextSteps };
    });
  }

  async function handleCreate(event) {
    event.preventDefault();
    setMessage("");

    if (!canCreateArticle(currentUser)) {
      setMessage("Only editor/admin can create articles.");
      return;
    }
    if (!rawSourceText.trim() || rawSourceText.trim().length < 20) {
      setMessage("Raw source text must be at least 20 characters.");
      return;
    }

    let workingDraft = draft;
    if (!workingDraft.title || !workingDraft.summary) {
      // Auto-generate if user skipped the Generate Draft step.
      workingDraft = generateDraftFromSource(rawSourceText, sourceType);
      workingDraft.title = getSuggestedTitle(rawSourceText, sourceType);
      setDraft(workingDraft);
    }

    setSaving(true);

    try {
      const now = new Date().toISOString();
      const articleId = makeId();
      const duplicateHash = simpleFingerprint(
        workingDraft.title,
        rawSourceText,
      );

      const payload = {
        id: articleId,
        title: workingDraft.title,
        summary: workingDraft.summary,
        steps: workingDraft.steps.filter(Boolean),
        content: rawSourceText,
        tags: workingDraft.tags,
        status: "Draft",
        sourceType,
        ingestionSource,
        sourceReference,
        creatorId: currentUser.id,
        creatorName: currentUser.name,
        reviewedBy: "",
        publishedBy: "",
        createdAt: now,
        updatedAt: now,
        reviewedAt: "",
        publishedAt: "",
        version: 1,
        duplicateHash,
        relatedLinks: workingDraft.relatedLinks || [],
        attachments: attachments.map((item) => ({
          ...item,
          uploadedAt: now,
        })),
        history: [
          {
            previousStatus: "New",
            newStatus: "Draft",
            changedBy: currentUser.name,
            changedAt: now,
            comment: "Draft created from source input.",
          },
        ],
        conflictFlag: Boolean(conflictWarning),
        outdatedFlag: Boolean(outdatedWarning),
        duplicateFlag: Boolean(duplicateWarning),
      };

      const created = await createArticle(payload);
      onArticleCreated(created);
      setRawSourceText("");
      setSourceReference("");
      setAttachments([]);
      setDraft({
        title: "",
        summary: "",
        steps: ["", "", ""],
        tags: [],
        relatedLinks: [],
      });
      setFileInputKey((value) => value + 1);
      setDuplicateWarning("");
      setConflictWarning("");
      setOutdatedWarning("");
      setMessage("Article created in Draft status.");
    } catch {
      setMessage("Failed to create article. Confirm json-server is running.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <section className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold text-slate-900">Upload Console</h2>
      <p className="mt-1 text-sm text-slate-600">
        Convert messy logistics notes into a structured SOP draft.
      </p>

      <form className="mt-4 grid gap-4" onSubmit={handleCreate}>
        <div>
          <label
            htmlFor="upload-source-type-select"
            className="mb-1 block text-sm font-medium"
          >
            Source Type
          </label>
          <select
            id="upload-source-type-select"
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            value={sourceType}
            onChange={(event) => setSourceType(event.target.value)}
          >
            {SOURCE_TYPES.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label
            htmlFor="upload-ingestion-source-select"
            className="mb-1 block text-sm font-medium"
          >
            Article Creation Source
          </label>
          <select
            id="upload-ingestion-source-select"
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            value={ingestionSource}
            onChange={(event) => setIngestionSource(event.target.value)}
          >
            <option value="Manual">Manual</option>
            <option value="RPA">RPA</option>
          </select>
        </div>

        <div>
          <label
            htmlFor="upload-raw-source-textarea"
            className="mb-1 block text-sm font-medium"
          >
            Raw Source Text
          </label>
          <textarea
            id="upload-raw-source-textarea"
            className="h-32 w-full rounded-md border border-slate-300 px-3 py-2"
            value={rawSourceText}
            onChange={(event) => setRawSourceText(event.target.value)}
            placeholder="Paste messy input from chat/email/files..."
            required
          />
          <p className="mt-1 text-xs text-black">
            Paste extracted/raw text from text, pdf, docx, email, chat, or image
            source.
          </p>
        </div>

        <div>
          <label
            htmlFor="upload-source-reference-input"
            className="mb-1 block text-sm font-medium"
          >
            Source Reference (optional)
          </label>
          <input
            id="upload-source-reference-input"
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            value={sourceReference}
            onChange={(event) => setSourceReference(event.target.value)}
            placeholder="Example: Google Drive/inbox-export/file-21.pdf"
          />
        </div>

        <div>
          <label
            htmlFor="upload-attachments-input"
            className="mb-1 block text-sm font-medium"
          >
            PDF / DOCX Attachments (multiple)
          </label>
          <input
            key={fileInputKey}
            id="upload-attachments-input"
            type="file"
            multiple
            accept=".pdf,.doc,.docx"
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            onChange={handleAttachmentChange}
          />
          <p className="mt-1 text-xs text-slate-500">
            Allowed: PDF, DOC, DOCX. Max size 3MB each.
          </p>
        </div>

        {attachments.length > 0 ? (
          <div
            id="upload-selected-attachments"
            className="rounded-md bg-slate-50 p-3 text-sm"
          >
            <p className="font-semibold">
              Selected Attachments (metadata only)
            </p>
            <ul className="mt-1 list-disc pl-5">
              {attachments.map((file, index) => (
                <li key={`${file.name}-${index}`}>
                  {file.name} - {Math.round(file.size / 1024)} KB
                </li>
              ))}
            </ul>
          </div>
        ) : null}

        <button
          id="upload-generate-draft-button"
          type="button"
          className="rounded-md bg-amber-500 px-4 py-2 text-slate-900 hover:bg-amber-400"
          onClick={handleGenerateDraft}
        >
          Generate Draft
        </button>

        <div className="rounded-md bg-slate-50 p-4">
          <h3 className="font-semibold text-slate-800">
            Generated Draft (Editable)
          </h3>
          <div className="mt-3 space-y-3">
            <input
              id="upload-draft-title-input"
              className="w-full rounded-md border border-slate-300 px-3 py-2"
              value={draft.title}
              onChange={(event) =>
                setDraft((current) => ({
                  ...current,
                  title: event.target.value,
                }))
              }
              placeholder="Generated title"
              required
            />
            <textarea
              id="upload-draft-summary-textarea"
              className="h-24 w-full rounded-md border border-slate-300 px-3 py-2"
              value={draft.summary}
              onChange={(event) =>
                setDraft((current) => ({
                  ...current,
                  summary: event.target.value,
                }))
              }
              placeholder="Generated summary"
              required
            />
            {draft.steps.map((step, index) => (
              <input
                key={`step-${index}`}
                id={`upload-draft-step-input-${index + 1}`}
                className="w-full rounded-md border border-slate-300 px-3 py-2"
                value={step}
                onChange={(event) => updateStep(index, event.target.value)}
                placeholder={`Step ${index + 1}`}
              />
            ))}
            <input
              id="upload-draft-tags-input"
              className="w-full rounded-md border border-slate-300 px-3 py-2"
              value={draft.tags.join(", ")}
              onChange={(event) =>
                setDraft((current) => ({
                  ...current,
                  tags: event.target.value
                    .split(",")
                    .map((tag) => tag.trim())
                    .filter(Boolean),
                }))
              }
              placeholder="Tags"
            />
            <input
              id="upload-draft-related-links-input"
              className="w-full rounded-md border border-slate-300 px-3 py-2"
              value={(draft.relatedLinks || []).join(", ")}
              onChange={(event) =>
                setDraft((current) => ({
                  ...current,
                  relatedLinks: event.target.value
                    .split(",")
                    .map((link) => link.trim())
                    .filter(Boolean),
                }))
              }
              placeholder="Related links (comma separated)"
            />
          </div>
        </div>

        <button
          id="upload-create-button"
          type="submit"
          className="rounded-md bg-emerald-600 px-4 py-2 text-white hover:bg-emerald-700 disabled:opacity-60"
          disabled={saving}
        >
          {saving ? "Saving..." : "Create Article"}
        </button>
      </form>

      {duplicateWarning ? (
        <p
          id="upload-duplicate-warning"
          className="mt-3 text-sm text-amber-700"
        >
          {duplicateWarning}
        </p>
      ) : null}
      {conflictWarning ? (
        <p
          id="upload-conflict-warning"
          className="mt-1 text-sm text-orange-700"
        >
          {conflictWarning}
        </p>
      ) : null}
      {outdatedWarning ? (
        <p id="upload-outdated-warning" className="mt-1 text-sm text-red-700">
          {outdatedWarning}
        </p>
      ) : null}

      {message ? (
        <p id="upload-status-text" className="mt-3 text-sm text-slate-700">
          {message}
        </p>
      ) : null}
    </section>
  );
}
