import { formatDateTime } from "@/lib/articleUtils";

export default function VersionHistory({ history = [] }) {
  const requiredFlow = ["Draft", "Reviewed", "Published"];
  const seen = new Set(history.map((item) => item.newStatus));

  if (history.length === 0) {
    return (
      <div id="article-version-history" className="mt-3 rounded-md bg-slate-50 p-3">
        <p className="text-sm font-semibold text-black">Version History</p>
        <p className="mt-1 text-sm text-black">No version history yet.</p>
      </div>
    );
  }

  return (
    <div id="article-version-history" className="mt-3 rounded-md bg-slate-50 p-3">
      <p className="text-sm font-semibold text-slate-700">Version History</p>
      <ul className="mt-2 space-y-1 text-sm text-slate-600">
        {history.map((item, index) => (
          <li key={`${item.previousStatus}-${item.newStatus}-${index}`} id={`history-row-${index}`}>
            {item.previousStatus} {"->"} {item.newStatus} by {item.changedBy || "unknown"} at{" "}
            {formatDateTime(item.changedAt)}{" "}
            {item.comment ? `(${item.comment})` : ""}
          </li>
        ))}
      </ul>
      <p className="mt-2 text-xs text-slate-500">
        Flow check:{" "}
        {requiredFlow.map((status) => (seen.has(status) ? `✓ ${status}` : `○ ${status}`)).join(
          " | ",
        )}
      </p>
    </div>
  );
}
