"use client";

import { useState } from "react";
import { authenticateUser } from "@/lib/api";

export default function LoginPanel({ onLogin }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(event) {
    event.preventDefault();
    setError("");
    setLoading(true);

    try {
      const user = await authenticateUser(identifier.trim(), password);

      if (!user) {
        setError("Invalid username/email or password.");
        return;
      }

      const safeUser = {
        id: user.id,
        name: user.name,
        email: user.email,
        username: user.username,
        role: user.role,
      };
      onLogin(safeUser);
      setIdentifier("");
      setPassword("");
    } catch {
      setError("Could not connect to mock API. Start json-server on port 4000.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="rounded-lg border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold text-slate-900">Login</h2>
      <p className="mt-1 text-sm text-slate-600">
        Mock login using username/email and password from `db.json`.
      </p>

      <form className="mt-4 space-y-4" onSubmit={handleSubmit}>
        <div>
          <label htmlFor="login-identifier-input" className="mb-1 block text-sm font-medium">
            Username or Email
          </label>
          <input
            id="login-identifier-input"
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            value={identifier}
            onChange={(event) => setIdentifier(event.target.value)}
            placeholder="e.g. mahmoud or mahmoud@dhl.local"
            required
          />
        </div>

        <div>
          <label htmlFor="login-password-input" className="mb-1 block text-sm font-medium">
            Password
          </label>
          <input
            id="login-password-input"
            className="w-full rounded-md border border-slate-300 px-3 py-2"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter password"
            required
          />
        </div>

        <button
          id="login-submit-button"
          className="rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-60"
          disabled={loading}
          type="submit"
        >
          {loading ? "Authenticating..." : "Login"}
        </button>
      </form>

      {error ? (
        <p id="login-error-text" className="mt-3 text-sm text-red-600">
          {error}
        </p>
      ) : null}
    </section>
  );
}
