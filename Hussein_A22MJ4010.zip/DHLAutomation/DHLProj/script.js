let currentArticle = "";

function generateArticle() {

    const input = document.getElementById("rawInput").value;
    const outputBox = document.getElementById("outputBox");
    const loader = document.getElementById("loader");

    if (input.trim() === "") {
        outputBox.innerHTML = "<p>Please enter some input first.</p>";
        return;
    }

    loader.style.display = "flex";

    let cleaned = input
        .replace(/\n/g, " ")
        .replace(/[✔\-]/g, "")
        .replace(/\s+/g, " ")
        .trim();

    let lower = cleaned.toLowerCase();

    let title = "Operational Procedure";
    let summary = "";
    let steps = [];

    if (
        lower.includes("routing") ||
        lower.includes("country code")
    ) {

        title = "Shipment Routing Issue Resolution";

        summary =
            "This SOP outlines the steps required to resolve shipment routing and country code related issues.";

        steps = [
            "Check the shipment routing code configuration.",
            "Verify the correct country code is used.",
            "Refresh shipment data in the system.",
            "Log out and log back into the application.",
            "Reprocess the shipment transaction.",
            "Escalate the issue to IT support if unresolved."
        ];
    }

    else if (
        lower.includes("error") ||
        lower.includes("failed") ||
        lower.includes("invalid")
    ) {

        if (lower.includes("pod")) {
            title = "POD Upload Issue Resolution";
        }

        else if (lower.includes("auth")) {
            title = "Authorization Error Resolution";
        }

        else if (lower.includes("address")) {
            title = "Customer Address Validation Issue";
        }

        else {
            title = "System Error Handling Procedure";
        }

        summary =
            "This SOP outlines the steps required to identify and resolve system-related errors.";

        if (lower.includes("compress")) {
            steps.push("Compress the file before uploading.");
        }

        if (lower.includes("jpeg")) {
            steps.push("Convert the image format to JPEG.");
        }

        if (lower.includes("refresh")) {
            steps.push("Refresh the system after upload.");
        }

        if (lower.includes("postcode")) {
            steps.push("Add missing postcode information.");
        }

        if (lower.includes("revalidate")) {
            steps.push("Revalidate the address details.");
        }

        if (lower.includes("logout")) {
            steps.push("Log out and log back into the system.");
        }

        if (lower.includes("check")) {
            steps.push("Verify user permissions and system settings.");
        }

        if (lower.includes("role")) {
            steps.push("Ensure correct user role access is assigned.");
        }

        if (steps.length === 0) {

            steps = [
                "Review the error message carefully.",
                "Verify system configuration and input data.",
                "Retry the failed process.",
                "Escalate to support if the issue persists."
            ];
        }
    }

    else if (
        lower.includes("setup") ||
        lower.includes("create") ||
        lower.includes("staff")
    ) {

        title = "New Staff System Setup Procedure";

        summary =
            "This SOP outlines the steps required to properly set up a new staff account and system access.";

        steps = [
            "Create user account in Active Directory.",
            "Provide company email access.",
            "Assign required system roles (SAP, CW1).",
            "Grant access to SOP and shared folders.",
            "Verify all access permissions are correctly configured."
        ];

        if (lower.includes("delay")) {
            steps.push(
                "Follow up on pending approvals if setup is delayed."
            );
        }
    }

    else if (
        lower.includes("booking") ||
        lower.includes("checklist") ||
        lower.includes("incoterm")
    ) {

        title = "Booking Validation Checklist";

        summary =
            "This SOP ensures all required shipment booking information is verified before submission.";

        if (lower.includes("po")) {
            steps.push(
                "Confirm customer purchase order (PO) is provided."
            );
        }

        if (lower.includes("incoterm")) {
            steps.push("Verify the correct Incoterm is selected.");
        }

        if (lower.includes("pickup")) {
            steps.push("Ensure pickup date is confirmed.");
        }

        if (lower.includes("weight")) {
            steps.push(
                "Validate shipment weight and dimensions."
            );
        }

        steps.push(
            "Reject the booking if any required information is missing."
        );
    }

    else if (
        lower.includes("label") &&
        lower.includes("print")
    ) {

        title = "Label Printing Issue Resolution";

        summary =
            "This SOP outlines the steps to resolve label printing issues caused by printer or system-related problems.";

        steps = [
            "Check if the issue is caused by printer cache.",
            "Restart the printer service.",
            "Clear the print queue.",
            "Reprint the shipping label.",
            "Replace toner if print quality is unclear."
        ];
    }

    else {

        title = "Shipment Issue Handling Procedure";

        summary =
            "This SOP outlines the steps to resolve shipment-related operational issues.";

        steps = [
            "Review the reported issue details.",
            "Verify shipment and system information.",
            "Perform corrective operational actions.",
            "Escalate the issue if unresolved."
        ];
    }

    if (steps.length === 0) {

        steps = cleaned
            .split(/[.,]/)
            .map(step => step.trim())
            .filter(step => step.length > 5)
            .slice(0, 6);
    }

    let formatted = `
        <h3>${title}</h3>
        <p><strong>Summary:</strong> ${summary}</p>
        <h4>Procedure Steps:</h4>
        <ol>
    `;

    steps.forEach(step => {
        formatted += `<li>${step}</li>`;
    });

    formatted += `</ol>`;

    outputBox.innerHTML = formatted;

    document.getElementById("saveContainer").style.display = "block";

    currentArticle = formatted;

    loader.style.display = "none";
}

function saveCurrentArticle() {

    if (!currentArticle) {
        alert("No SOP to save.");
        return;
    }

    fetch("http://localhost:3000/articles", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            content: currentArticle
        })
    })
    .then(() => {
        alert("SOP saved successfully!");
    })
    .catch(err => {
        console.error(err);
        alert("Failed to save SOP.");
    });
}

async function handleFileUpload(event) {

    const file = event.target.files[0];

    if (!file) return;

    const rawInput = document.getElementById("rawInput");

    if (file.name.endsWith(".txt")) {

        const reader = new FileReader();

        reader.onload = function(e) {
            rawInput.value = e.target.result;
        };

        reader.readAsText(file);
    }

    else if (
        file.name.endsWith(".png") ||
        file.name.endsWith(".jpg") ||
        file.name.endsWith(".jpeg")
    ) {

        rawInput.value = "Reading image text...";

        const result = await Tesseract.recognize(
            file,
            "eng"
        );

        rawInput.value = result.data.text;
    }

    else {
        alert("Unsupported file type.");
    }

    event.target.value = "";
}

function clearAll() {

    document.getElementById("rawInput").value = "";

    document.getElementById("outputBox").innerHTML =
        "<p class='placeholder'>Generated SOP will appear here...</p>";

    document.getElementById("saveContainer").style.display = "none";
}

function goToSOP() {
    window.location.href = "sop.html";
}

function login() {

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    const errorMsg = document.getElementById("errorMsg");
    const loader = document.getElementById("loader");

    if (email === "" || password === "") {

        errorMsg.textContent =
            "Please enter both email and password.";

        return;
    }

    if (!email.includes("@")) {

        errorMsg.textContent =
            "Please enter a valid email address.";

        return;
    }

    errorMsg.textContent = "";

    loader.style.display = "flex";

    setTimeout(() => {
        window.location.href = "dashboard.html";
    }, 1200);
}