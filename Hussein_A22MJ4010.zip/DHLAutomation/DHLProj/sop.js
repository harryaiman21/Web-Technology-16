let deleteMode = false;

function loadArticles() {

    fetch("http://localhost:3000/articles")
    .then(res => res.json())
    .then(articles => {

        const container = document.getElementById("articleList");
        container.innerHTML = "";

        let keyword = document.getElementById("searchInput")
            ? document.getElementById("searchInput").value.toLowerCase()
            : "";

        articles.slice().reverse().forEach((article, index) => {

            let titleMatch = article.content.match(/<h3>(.*?)<\/h3>/);

            let title = titleMatch
                ? titleMatch[1]
                : "Untitled SOP";

            // SEARCH FILTER
            if (!title.toLowerCase().includes(keyword)) {
                return;
            }

            let latestTag = index === 0
                ? `<span class="latest-tag">Latest</span>`
                : "";

            container.innerHTML += `
                <div class="history-item">

                    ${deleteMode
                        ? `<input type="checkbox"
                            class="deleteCheck"
                            value="${article.id}">`
                        : ""
                    }

                    <div onclick="viewArticle('${article.id}')"
                        style="width:100%; cursor:pointer;">

                        <strong>${title}</strong>
                        ${latestTag}

                        <div style="
                            margin-top:5px;
                            font-size:14px;
                            color:#555;
                        ">
                            Click to view SOP
                        </div>

                    </div>

                </div>
            `;
        });
    });
}

function viewArticle(id) {
    window.location.href = `view.html?id=${id}`;
}

function enableDeleteMode() {
    deleteMode = true;
    document.getElementById("deleteControls").style.display = "block";
    loadArticles();
}

function cancelDelete() {
    deleteMode = false;
    document.getElementById("deleteControls").style.display = "none";
    loadArticles();
}

function confirmDelete() {

    let checks = document.querySelectorAll(".deleteCheck:checked");

    if (checks.length === 0) {
        alert("Please select at least one SOP.");
        return;
    }

    if (!confirm("Are you sure? Deleted SOPs cannot be restored.")) {
        return;
    }

    let deletePromises = [];

    checks.forEach(check => {

        let id = check.value;

        deletePromises.push(
            fetch(`http://localhost:3000/articles/${id}`, {
                method: "DELETE"
            })
        );
    });

    Promise.all(deletePromises)
        .then(() => {
            cancelDelete();
        });
}

function goBack() {
    window.location.href = "dashboard.html";
}

loadArticles();