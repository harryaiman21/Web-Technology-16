import { NextRequest, NextResponse } from 'next/server'

import { getAuth0Client, isAuth0Configured } from '@/lib/auth0'
import { sanitizeReturnTo } from '@/utilities/returnTo'

const protectedRoutes = ['/dashboard']

const isProtectedRoute = (pathname: string) =>
  protectedRoutes.some((route) => pathname === route || pathname.startsWith(`${route}/`))

export async function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl

  if (!isAuth0Configured()) {
    if (pathname.startsWith('/auth') || pathname === '/' || pathname === '/login' || !isProtectedRoute(pathname)) {
      return NextResponse.next()
    }

    return NextResponse.redirect(new URL('/auth/setup-required', request.url))
  }

  const auth0 = getAuth0Client()
  const authResponse = await auth0.middleware(request)

  if (pathname.startsWith('/auth')) {
    return authResponse
  }

  if (!isProtectedRoute(pathname)) {
    return authResponse
  }

  const session = await auth0.getSession(request)

  if (!session) {
    const returnTo = sanitizeReturnTo(`${pathname}${search}`)
    return NextResponse.redirect(new URL(`/?returnTo=${encodeURIComponent(returnTo)}`, request.url))
  }

  return authResponse
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|favicon.svg|logisense-mark.svg|sitemap.xml|robots.txt).*)'],
}
