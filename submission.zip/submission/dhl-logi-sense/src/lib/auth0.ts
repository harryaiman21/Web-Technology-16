import { Auth0Client } from '@auth0/nextjs-auth0/server'

let auth0Client: Auth0Client | null = null

const normalizeBaseURL = (url?: string | null) => {
  if (!url) return undefined

  const trimmed = url.trim()

  if (!trimmed) return undefined

  const withProtocol = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`

  return withProtocol.replace(/\/+$/, '')
}

const requiredAuth0EnvVars = [
  'AUTH0_DOMAIN',
  'AUTH0_CLIENT_ID',
  'AUTH0_CLIENT_SECRET',
  'AUTH0_SECRET',
] as const

export const isAuth0Configured = () =>
  requiredAuth0EnvVars.every((key) => Boolean(process.env[key]))

export const missingAuth0EnvVars = () =>
  requiredAuth0EnvVars.filter((key) => !process.env[key])

export const getAuth0Client = () => {
  if (!isAuth0Configured()) {
    throw new Error(`Auth0 is not configured. Missing: ${missingAuth0EnvVars().join(', ')}`)
  }

  auth0Client ??= new Auth0Client({
    appBaseUrl:
      normalizeBaseURL(process.env.APP_BASE_URL) ||
      normalizeBaseURL(process.env.NEXT_PUBLIC_SERVER_URL) ||
      normalizeBaseURL(process.env.VERCEL_PROJECT_PRODUCTION_URL) ||
      normalizeBaseURL(process.env.VERCEL_URL),
    signInReturnToPath: '/dashboard',
  })

  return auth0Client
}
