import type { User as Auth0User } from '@auth0/nextjs-auth0/types'
import configPromise from '@payload-config'
import { getPayload } from 'payload'

import { getAuth0Client, isAuth0Configured } from '@/lib/auth0'

export type AppRole = 'T1' | 'T2'

export type CurrentAppUser = {
  auth0Sub: string
  email: string
  id: number | string
  name?: string | null
  picture?: string | null
  role: AppRole
}

const getDisplayName = (user: Auth0User) => user.name || user.nickname || user.email || 'Auth0 user'

export async function syncAuth0UserToPayload(user: Auth0User): Promise<CurrentAppUser> {
  if (!user.sub) {
    throw new Error('Auth0 session is missing a stable subject identifier.')
  }

  if (!user.email) {
    throw new Error('Auth0 session is missing an email address.')
  }

  const payload = await getPayload({ config: configPromise })
  const existing = await payload.find({
    collection: 'app-users',
    limit: 1,
    overrideAccess: true,
    where: {
      auth0Sub: {
        equals: user.sub,
      },
    },
  })

  const profileData = {
    email: user.email,
    name: getDisplayName(user),
    picture: user.picture || null,
    lastLoginAt: new Date().toISOString(),
  }

  const appUser =
    existing.docs[0] ??
    (await payload.create({
      collection: 'app-users',
      data: {
        auth0Sub: user.sub,
        role: 'T1',
        ...profileData,
      },
      overrideAccess: true,
    }))

  const updatedAppUser = existing.docs[0]
    ? await payload.update({
        collection: 'app-users',
        data: profileData,
        id: appUser.id,
        overrideAccess: true,
      })
    : appUser

  return {
    auth0Sub: updatedAppUser.auth0Sub,
    email: updatedAppUser.email,
    id: updatedAppUser.id,
    name: updatedAppUser.name,
    picture: updatedAppUser.picture,
    role: updatedAppUser.role as AppRole,
  }
}

export async function getCurrentAppUser(): Promise<CurrentAppUser | null> {
  if (!isAuth0Configured()) return null

  const session = await getAuth0Client().getSession()

  if (!session?.user) return null

  return syncAuth0UserToPayload(session.user)
}

export async function requireCurrentAppUser(requiredRole?: AppRole): Promise<CurrentAppUser> {
  const appUser = await getCurrentAppUser()

  if (!appUser) {
    throw new Error('Unauthorized.')
  }

  if (requiredRole === 'T2' && appUser.role !== 'T2') {
    throw new Error('T2 role required.')
  }

  return appUser
}
