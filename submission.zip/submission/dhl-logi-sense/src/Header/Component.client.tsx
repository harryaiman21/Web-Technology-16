'use client'
import { useHeaderTheme } from '@/providers/HeaderTheme'
import type { User } from '@auth0/nextjs-auth0/types'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import React, { useEffect, useState } from 'react'

import { Logo } from '@/components/Logo/Logo'
import { HeaderNav } from './Nav'

export const HeaderClient: React.FC<{ user: User | null }> = ({ user }) => {
  /* Storing the value in a useState to avoid hydration errors */
  const [theme, setTheme] = useState<string | null>(null)
  const { headerTheme, setHeaderTheme } = useHeaderTheme()
  const pathname = usePathname()

  useEffect(() => {
    setHeaderTheme(null)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname])

  useEffect(() => {
    if (headerTheme && headerTheme !== theme) setTheme(headerTheme)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [headerTheme])

  return (
    <header
      className="sticky top-0 z-20 border-b border-border/70 bg-background/95 backdrop-blur"
      {...(theme ? { 'data-theme': theme } : {})}
    >
      <div className="container flex items-center justify-between gap-2 py-2.5 sm:gap-4 sm:py-3">
        <Link className="flex min-w-0 items-center gap-2 sm:gap-3" href="/dashboard">
          <Logo className="h-8 w-8 shrink-0 sm:h-[34px] sm:w-[34px]" loading="eager" priority="high" />
          <span className="hidden min-w-0 truncate text-sm font-semibold tracking-tight sm:inline sm:text-base">
            DHL LogiSense
          </span>
        </Link>
        <HeaderNav user={user} />
      </div>
    </header>
  )
}
