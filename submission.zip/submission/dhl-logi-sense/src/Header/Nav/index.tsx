'use client'

import React from 'react'

import type { User } from '@auth0/nextjs-auth0/types'

import Link from 'next/link'
import { BarChart3, LayoutDashboard, LogOut, UserRound } from 'lucide-react'

export const HeaderNav: React.FC<{ user: User | null }> = ({ user }) => {
  const displayName = user?.name || user?.email || 'Account'

  if (!user) {
    return null
  }

  return (
    <nav className="flex items-center gap-1 sm:gap-2">
      <Link
        className="inline-flex h-9 items-center gap-2 rounded-md px-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        href="/dashboard"
      >
        <LayoutDashboard className="h-4 w-4" />
        <span className="hidden sm:inline">Dashboard</span>
      </Link>
      <Link
        className="inline-flex h-9 items-center gap-2 rounded-md px-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
        href="/dashboard/analytics"
      >
        <BarChart3 className="h-4 w-4" />
        <span className="hidden sm:inline">Analytics</span>
      </Link>
      <div className="flex items-center gap-1">
        <span
          className="hidden max-w-40 items-center gap-2 truncate rounded-md px-2 text-sm text-muted-foreground md:inline-flex"
          title={displayName}
        >
          <UserRound className="h-4 w-4 shrink-0" />
          <span className="truncate">{displayName}</span>
        </span>
        <a
          className="inline-flex h-9 items-center gap-2 rounded-md px-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
          href="/auth/logout"
        >
          <LogOut className="h-4 w-4" />
          <span className="hidden sm:inline">Log out</span>
        </a>
      </div>
    </nav>
  )
}
