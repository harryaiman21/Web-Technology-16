import { HeaderClient } from './Component.client'
import { getAuth0Client, isAuth0Configured } from '@/lib/auth0'
import React from 'react'

export async function Header() {
  const session = isAuth0Configured() ? await getAuth0Client().getSession() : null

  return <HeaderClient user={session?.user ?? null} />
}
