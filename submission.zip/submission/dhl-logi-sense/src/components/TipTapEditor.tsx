'use client'

import React, { useState } from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import {
  Edit2,
  Save,
  X,
  Bold,
  Italic,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  FileText,
  Columns,
  Loader2,
} from 'lucide-react'
import { updateDocumentContent } from '@/app/(frontend)/dashboard/actions'
import { AnimatePresence, motion } from 'framer-motion'
import { cn } from '@/utilities/ui'

interface TipTapEditorProps {
  canEdit?: boolean
  initialContent: string
  documentId: string | number
  collectionType: 'sops' | 'articles'
  rawText: string
}

export default function TipTapEditor({
  canEdit = true,
  initialContent,
  documentId,
  collectionType,
  rawText,
}: TipTapEditorProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [showRawText, setShowRawText] = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)

  const editor = useEditor({
    extensions: [StarterKit],
    content: initialContent,
    editable: isEditing,
    editorProps: {
      attributes: {
        class:
          'prose prose-sm sm:prose-base dark:prose-invert max-w-none break-words focus:outline-none min-h-[300px] h-full p-4',
      },
    },
  })

  React.useEffect(() => {
    if (editor) {
      editor.setEditable(isEditing)
    }
  }, [isEditing, editor])

  const handleSave = async () => {
    if (!editor) return
    setIsSaving(true)
    setSaveError(null)

    const newHtml = editor.getHTML()
    try {
      const result = await updateDocumentContent(documentId, collectionType, newHtml)

      if (result.success) {
        setIsEditing(false)
      } else {
        setSaveError('Save failed. Your edits are still on screen; try again before leaving.')
      }
    } catch (error) {
      setSaveError('Save failed. Your edits are still on screen; try again before leaving.')
    } finally {
      setIsSaving(false)
    }
  }

  const handleCancel = () => {
    if (editor) {
      editor.commands.setContent(initialContent)
    }
    setSaveError(null)
    setIsEditing(false)
  }

  if (!editor) {
    return (
      <div className="rounded-md border border-border bg-muted/30 p-4 text-sm text-muted-foreground">
        Preparing document editor...
      </div>
    )
  }

  const compareLayoutVars = {
    '--summary-width': showRawText ? 'calc(55% - 0.75rem)' : '100%',
    '--raw-width': showRawText ? 'calc(45% - 0.75rem)' : '0px',
  } as React.CSSProperties

  return (
    <div className="w-full space-y-4">
      {/* Top Action Bar */}
      <div className="sticky top-[57px] z-10 mb-4 flex flex-col gap-2 border-b border-border/50 bg-background py-2 sm:top-[59px] sm:flex-row sm:items-center sm:justify-between">
        {/* All Controls Grouped on the Left */}
        <div className="grid grid-cols-1 gap-2 min-[360px]:grid-cols-2 sm:flex sm:flex-wrap sm:items-center">
          <Button
            variant={showRawText ? 'default' : 'secondary'}
            onClick={() => setShowRawText(!showRawText)}
            className="h-9 min-w-0 transition-all duration-200 active:scale-[0.98] sm:min-w-44"
          >
            <Columns className="w-4 h-4" />
            {showRawText ? 'Close audit view' : 'Compare raw text'}
          </Button>
          {canEdit && <div className="hidden h-6 w-px bg-border sm:block" />}
          {canEdit && !isEditing ? (
            <Button
              onClick={() => setIsEditing(true)}
              className="h-9 min-w-0 transition-all duration-200 active:scale-[0.98] sm:min-w-36"
            >
              <Edit2 className="w-4 h-4" /> Edit document
            </Button>
          ) : canEdit ? (
            <>
              <Button
                variant="outline"
                onClick={handleCancel}
                disabled={isSaving}
                title="Discard unsaved changes and return to the generated version"
                className="h-9 min-w-0 transition-all duration-200 active:scale-[0.98] sm:min-w-32"
              >
                <X className="w-4 h-4" /> Cancel edits
              </Button>
              <Button
                onClick={handleSave}
                disabled={isSaving}
                className="h-9 min-w-0 transition-all duration-200 active:scale-[0.98] sm:min-w-36"
              >
                {isSaving ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {isSaving ? 'Saving changes' : 'Save changes'}
              </Button>
            </>
          ) : null}
        </div>
        <div className="text-xs font-medium text-muted-foreground sm:text-right">
          {isSaving
            ? 'Saving to knowledge base...'
            : isEditing
              ? 'Editing draft'
              : canEdit
                ? 'Read-only review'
                : 'Review mode'}
        </div>
      </div>

      <AnimatePresence>
        {saveError && (
          <motion.div
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            transition={{ duration: 0.18 }}
            className="rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive"
          >
            {saveError}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Split View Container - stable columns prevent cursor drift and text bounce */}
      <div
        className="flex w-full flex-col items-stretch gap-0 lg:flex-row lg:data-[compare=true]:gap-6"
        data-compare={showRawText}
        style={compareLayoutVars}
      >
        {/* Left Side: TipTap Editor */}
        <div className="min-w-0 w-full flex-none transition-[flex-basis,max-width] duration-300 ease-out lg:basis-[var(--summary-width)] lg:max-w-[var(--summary-width)]">
          <Card
            className={`flex min-h-[420px] flex-col overflow-hidden border-2 transition-colors duration-300 sm:min-h-[520px] ${isEditing ? 'border-primary' : 'border-border'}`}
          >
            {isEditing && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.18 }}
                className="flex flex-wrap gap-2 p-2 bg-secondary border-b border-border shrink-0"
              >
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => editor.chain().focus().toggleBold().run()}
                  className={cn(
                    'h-9 w-9 p-0 transition-all duration-200 active:scale-[0.96]',
                    editor.isActive('bold') && 'bg-muted',
                  )}
                  aria-label="Toggle bold"
                  title="Bold"
                >
                  <Bold className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => editor.chain().focus().toggleItalic().run()}
                  className={cn(
                    'h-9 w-9 p-0 transition-all duration-200 active:scale-[0.96]',
                    editor.isActive('italic') && 'bg-muted',
                  )}
                  aria-label="Toggle italic"
                  title="Italic"
                >
                  <Italic className="w-4 h-4" />
                </Button>
                <div className="w-px h-6 bg-border mx-1 my-auto" />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
                  className={cn(
                    'h-9 w-9 p-0 transition-all duration-200 active:scale-[0.96]',
                    editor.isActive('heading', { level: 1 }) && 'bg-muted',
                  )}
                  aria-label="Toggle heading 1"
                  title="Heading 1"
                >
                  <Heading1 className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
                  className={cn(
                    'h-9 w-9 p-0 transition-all duration-200 active:scale-[0.96]',
                    editor.isActive('heading', { level: 2 }) && 'bg-muted',
                  )}
                  aria-label="Toggle heading 2"
                  title="Heading 2"
                >
                  <Heading2 className="w-4 h-4" />
                </Button>
                <div className="w-px h-6 bg-border mx-1 my-auto" />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => editor.chain().focus().toggleBulletList().run()}
                  className={cn(
                    'h-9 w-9 p-0 transition-all duration-200 active:scale-[0.96]',
                    editor.isActive('bulletList') && 'bg-muted',
                  )}
                  aria-label="Toggle bullet list"
                  title="Bullet list"
                >
                  <List className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => editor.chain().focus().toggleOrderedList().run()}
                  className={cn(
                    'h-9 w-9 p-0 transition-all duration-200 active:scale-[0.96]',
                    editor.isActive('orderedList') && 'bg-muted',
                  )}
                  aria-label="Toggle numbered list"
                  title="Numbered list"
                >
                  <ListOrdered className="w-4 h-4" />
                </Button>
              </motion.div>
            )}

            <CardContent className="p-0 flex-1">
              <EditorContent editor={editor} className="h-full" />
            </CardContent>
          </Card>
        </div>

        {/* Right Side: Raw Text Panel */}
        {/* Clip reveal keeps text stable instead of bouncing during the compare transition */}
        <div
          aria-hidden={!showRawText}
          className={`min-w-0 w-full flex-none overflow-hidden transition-[clip-path,opacity,max-height,margin-top,flex-basis,max-width] duration-300 ease-out lg:basis-[var(--raw-width)] lg:max-w-[var(--raw-width)] ${
            showRawText
              ? 'mt-6 max-h-[2000px] opacity-100 [clip-path:inset(0_0_0_0)] lg:mt-0 lg:max-h-none'
              : 'mt-0 max-h-0 opacity-0 [clip-path:inset(0_100%_0_0)] lg:max-h-none'
          }`}
        >
          <Card className="flex min-h-[420px] flex-col border-2 border-muted shadow-lg sm:min-h-[520px] lg:h-full">
            <div className="flex shrink-0 items-center justify-between gap-3 border-b border-border bg-muted p-3">
              <h3 className="flex min-w-0 items-center text-sm font-semibold text-muted-foreground">
                <FileText className="w-4 h-4 mr-2" /> Original OCR Data
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowRawText(false)}
                className="h-9 w-9 p-0 shrink-0 transition-all duration-200 active:scale-[0.96]"
                aria-label="Close raw text audit view"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* The absolute inset-0 trick forces this box to match the exact height of the editor card! */}
            <CardContent className="p-0 flex-1 relative min-h-[300px] lg:min-h-0 bg-secondary/20">
              <div className="custom-scrollbar absolute inset-0 overflow-y-auto whitespace-pre-wrap break-words p-4 font-mono text-xs leading-relaxed text-foreground/80 md:text-sm">
                {rawText || 'Raw source text is unavailable for this generated document.'}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
