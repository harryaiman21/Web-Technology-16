import React from 'react'

const BeforeLogin: React.FC = () => {
  return (
    <div>
      <p>
        <b>DHL LogiSense Admin</b>
        {' Manage generated SOPs, articles, source inputs, and review workflows.'}
      </p>
    </div>
  )
}

export default BeforeLogin
