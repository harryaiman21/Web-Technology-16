import type { CollectionConfig } from 'payload'

import { authenticated } from '../access/authenticated'

export const appUserRoles = [
  {
    label: 'T1 - Review access',
    value: 'T1',
  },
  {
    label: 'T2 - Editor access',
    value: 'T2',
  },
]

export const AppUsers: CollectionConfig = {
  slug: 'app-users',
  labels: {
    singular: 'App User',
    plural: 'App Users',
  },
  admin: {
    useAsTitle: 'email',
    defaultColumns: ['email', 'name', 'role', 'lastLoginAt'],
    description: 'Auth0 users who can access the LogiSense dashboard and their app roles.',
    group: 'Access Control',
  },
  access: {
    admin: authenticated,
    create: authenticated,
    delete: authenticated,
    read: authenticated,
    update: authenticated,
  },
  fields: [
    {
      name: 'auth0Sub',
      type: 'text',
      required: true,
      unique: true,
      index: true,
      admin: {
        readOnly: true,
        description: 'Stable Auth0 user identifier. Do not edit manually.',
      },
    },
    {
      name: 'email',
      type: 'email',
      required: true,
      index: true,
      admin: {
        readOnly: true,
      },
    },
    {
      name: 'name',
      type: 'text',
      admin: {
        readOnly: true,
      },
    },
    {
      name: 'picture',
      type: 'text',
      admin: {
        readOnly: true,
      },
    },
    {
      name: 'role',
      type: 'select',
      required: true,
      defaultValue: 'T1',
      options: appUserRoles,
      admin: {
        description:
          'T1 can review generated knowledge. T2 can edit and delete generated SOPs/articles.',
      },
    },
    {
      name: 'lastLoginAt',
      type: 'date',
      admin: {
        date: {
          pickerAppearance: 'dayAndTime',
        },
        readOnly: true,
      },
    },
  ],
  timestamps: true,
}
