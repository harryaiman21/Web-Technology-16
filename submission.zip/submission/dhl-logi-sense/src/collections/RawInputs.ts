import type { CollectionConfig } from 'payload'

export const RawInputs: CollectionConfig = {
  slug: 'raw-inputs',
  admin: {
    useAsTitle: 'sourceType',
    description: 'Raw OCR data and initial LLM summaries fetched via UiPath.',
  },
  access: {
    read: () => true,
    create: () => true,
  },
  fields: [
    { name: 'sourceId', type: 'text', index: true }, // store unique onedriveid
    { name: 'rawText', type: 'textarea', required: true },
    { name: 'summary', type: 'textarea' },
    {
      name: 'sourceType',
      type: 'select',
      options: [
        { label: 'MS Teams', value: 'teams' },
        { label: 'Email Thread', value: 'email' },
        { label: 'Screenshot', value: 'screenshot' },
        { label: 'Handwritten Note', value: 'handwritten' },
        { label: 'Training Material', value: 'training' },
        { label: 'Plain Text', value: 'txt' },
        { label: 'Word Document', value: 'docx' },
        { label: 'PDF', value: 'pdf' },
        { label: 'Outlook Message', value: 'msg' },
        { label: 'JPEG Image', value: 'jpe' },
        { label: 'JPEG Image', value: 'jpeg' },
        { label: 'JPEG Image', value: 'jpg' },
        { label: 'PNG Image', value: 'png' },
        { label: 'TIFF Image', value: 'tif' },
        { label: 'TIFF Image', value: 'tiff' },
      ],
      required: true,
    },
    {
      name: 'category',
      type: 'relationship',
      relationTo: 'categories',
      admin: { position: 'sidebar' },
    },
  ],
}
