import { MigrateUpArgs, MigrateDownArgs, sql } from '@payloadcms/db-postgres'

export async function up({ db }: MigrateUpArgs): Promise<void> {
  await db.execute(sql`
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'txt';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'docx';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'pdf';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'msg';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'jpe';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'jpeg';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'jpg';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'png';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'tif';
    ALTER TYPE "public"."enum_raw_inputs_source_type" ADD VALUE IF NOT EXISTS 'tiff';
  `)
}

export async function down({}: MigrateDownArgs): Promise<void> {
  // PostgreSQL cannot safely remove enum values in-place without rebuilding the type.
}
