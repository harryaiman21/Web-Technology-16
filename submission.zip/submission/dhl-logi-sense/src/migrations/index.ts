import * as migration_20260422_105420 from './20260422_105420';
import * as migration_20260502_120000_expand_raw_input_source_type from './20260502_120000_expand_raw_input_source_type';
import * as migration_20260514_152036_add_app_users_roles from './20260514_152036_add_app_users_roles';

export const migrations = [
  {
    up: migration_20260422_105420.up,
    down: migration_20260422_105420.down,
    name: '20260422_105420',
  },
  {
    up: migration_20260502_120000_expand_raw_input_source_type.up,
    down: migration_20260502_120000_expand_raw_input_source_type.down,
    name: '20260502_120000_expand_raw_input_source_type',
  },
  {
    up: migration_20260514_152036_add_app_users_roles.up,
    down: migration_20260514_152036_add_app_users_roles.down,
    name: '20260514_152036_add_app_users_roles'
  },
];
