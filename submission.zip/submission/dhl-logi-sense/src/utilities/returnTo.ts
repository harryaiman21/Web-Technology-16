export const sanitizeReturnTo = (value?: string | null) => {
  if (!value || !value.startsWith('/') || value.startsWith('//')) {
    return '/dashboard'
  }

  return value
}
