export type Theme = 'dark' | 'light'

export const themeLocalStorageKey = 'logisense-theme'

export const defaultTheme = 'light'
