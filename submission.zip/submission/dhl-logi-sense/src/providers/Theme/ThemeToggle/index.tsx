'use client'

import { Moon, Sun } from 'lucide-react'
import React from 'react'

import { useTheme } from '..'

export const ThemeToggle: React.FC = () => {
  const { setTheme, theme } = useTheme()
  const [bottomOffset, setBottomOffset] = React.useState(16)
  const isDark = theme === 'dark'

  React.useEffect(() => {
    let frame = 0

    const updateOffset = () => {
      cancelAnimationFrame(frame)
      frame = requestAnimationFrame(() => {
        const footer = document.querySelector('footer')

        if (!footer) {
          setBottomOffset(16)
          return
        }

        const footerTop = footer.getBoundingClientRect().top
        const overlap = Math.max(0, window.innerHeight - footerTop)

        setBottomOffset(overlap + 16)
      })
    }

    updateOffset()
    window.addEventListener('scroll', updateOffset, { passive: true })
    window.addEventListener('resize', updateOffset)

    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener('scroll', updateOffset)
      window.removeEventListener('resize', updateOffset)
    }
  }, [])

  return (
    <div
      className="fixed right-3 z-50 sm:right-5"
      style={{ bottom: bottomOffset }}
    >
      <button
        aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        className="inline-flex h-11 w-11 items-center justify-center gap-2 rounded-full border border-border bg-card px-0 text-sm font-medium text-card-foreground shadow-lg shadow-foreground/10 transition-[background-color,border-color,box-shadow] duration-200 hover:bg-accent focus-visible:outline-1 focus-visible:ring-4 focus-visible:ring-ring/20 sm:w-auto sm:px-3"
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        type="button"
      >
        <span className="grid h-7 w-7 place-items-center rounded-full bg-primary text-primary-foreground">
          {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </span>
        <span className="hidden sm:inline">{isDark ? 'Light mode' : 'Dark mode'}</span>
      </button>
    </div>
  )
}
