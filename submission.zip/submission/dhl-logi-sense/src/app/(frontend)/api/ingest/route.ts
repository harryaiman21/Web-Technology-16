import { NextResponse } from 'next/server'
import { getPayload } from 'payload'
import configPromise from '@payload-config'
import { after } from 'next/server'
import { processLogiSenseInput } from '@/services/aiTransformation'

type RawInputSourceType = 'teams' | 'email' | 'screenshot' | 'handwritten' | 'training'

const normalizeSourceType = (sourceType: unknown) => {
  const value = String(sourceType || '')
    .trim()
    .toLowerCase()

  if (['teams', 'email', 'screenshot', 'handwritten', 'training'].includes(value)) {
    return value as RawInputSourceType
  }

  if (['jpe', 'jpeg', 'jpg', 'png', 'tif', 'tiff'].includes(value)) {
    return 'screenshot'
  }

  return 'training'
}

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { rawText, summary, sourceType, sourceId } = body
    const normalizedSourceType = normalizeSourceType(sourceType)

    const payload = await getPayload({ config: configPromise })

    // Check for existing sourceId instead of rawText
    const duplicateCheck = await payload.find({
      collection: 'raw-inputs',
      limit: 1,
      pagination: false,
      where: { sourceId: { equals: sourceId } },
    })

    if (duplicateCheck.docs.length > 0) {
      console.log(`[LogiSense API] Blocked duplicate file: ${sourceId}`)
      return NextResponse.json({ success: true, message: 'Already processed' }, { status: 200 })
    }
    // ==========================================

    // 2. FAST INSERT: Closes the DB transaction instantly
    const newRawInput = await payload.create({
      collection: 'raw-inputs',
      data: { sourceId, rawText, summary, sourceType: normalizedSourceType },
    })

    // 3. BACKGROUND AI: Vercel keeps this alive after the response is sent
    after(async () => {
      console.log(`[LogiSense Async] Starting AI for ${newRawInput.id}`)
      try {
        const aiResult = await processLogiSenseInput(rawText, summary)

        let categoryId
        const existingCategory = await payload.find({
          collection: 'categories',
          limit: 1,
          pagination: false,
          where: { title: { equals: aiResult.category } },
        })

        if (existingCategory.docs.length > 0) {
          categoryId = existingCategory.docs[0].id
        } else {
          const newCategory = await payload.create({
            collection: 'categories',
            data: {
              title: aiResult.category,
              slug: aiResult.category.toLowerCase().replace(/\s+/g, '-'),
            },
          })
          categoryId = newCategory.id
        }

        await payload.update({
          collection: 'raw-inputs',
          id: newRawInput.id,
          data: { category: categoryId },
        })

        const targetCollection = aiResult.documentType === 'sop' ? 'sops' : 'articles'
        await payload.create({
          collection: targetCollection,
          data: {
            title: aiResult.title,
            content: aiResult.content,
            basedOn: newRawInput.id,
            category: categoryId,
          },
        })
        console.log(`[LogiSense Async] Generated ${targetCollection} successfully.`)
      } catch (error) {
        console.error('[LogiSense Async] AI Pipeline Error:', error)
      }
    })

    // 4. INSTANT RESPONSE
    return NextResponse.json({ success: true, docId: newRawInput.id }, { status: 201 })
  } catch (error) {
    console.error('LogiSense Ingestion Error:', error)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}
