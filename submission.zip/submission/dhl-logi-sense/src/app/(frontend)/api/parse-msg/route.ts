import MsgReaderPackage from '@kenjiuno/msgreader'
import { NextResponse } from 'next/server'

export const runtime = 'nodejs'

const MsgReader = (
  MsgReaderPackage as unknown as {
    default?: typeof MsgReaderPackage
  }
).default ?? MsgReaderPackage

const getUploadedFile = (formData: FormData) => {
  for (const value of formData.values()) {
    if (value instanceof File) {
      return value
    }
  }

  return null
}

const textFromHtml = (html: string) =>
  html
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n\s+/g, '\n')
    .trim()

export async function POST(req: Request) {
  try {
    const formData = await req.formData()
    const file = getUploadedFile(formData)

    if (!file) {
      return NextResponse.json({ error: 'No MSG file uploaded' }, { status: 400 })
    }

    const bytes = new Uint8Array(await file.arrayBuffer())
    const reader = new MsgReader(bytes)
    const message = reader.getFileData()

    if (message.error) {
      return NextResponse.json({ error: message.error }, { status: 422 })
    }

    const recipients =
      message.recipients
        ?.map((recipient) => recipient.email || recipient.name)
        .filter(Boolean)
        .join(', ') || ''

    const attachments =
      message.attachments
        ?.map((attachment) => attachment.fileName || attachment.name)
        .filter(Boolean)
        .join(', ') || ''

    const body = message.body?.trim() || (message.bodyHtml ? textFromHtml(message.bodyHtml) : '')
    const summary = message.subject?.trim() || file.name.replace(/\.msg$/i, '')

    const sections = [
      `Subject: ${summary}`,
      message.senderName || message.senderEmail
        ? `From: ${[message.senderName, message.senderEmail].filter(Boolean).join(' <')}${
            message.senderName && message.senderEmail ? '>' : ''
          }`
        : '',
      recipients ? `To: ${recipients}` : '',
      message.clientSubmitTime ? `Date: ${message.clientSubmitTime}` : '',
      attachments ? `Attachments: ${attachments}` : '',
      body,
    ].filter(Boolean)

    return NextResponse.json({
      rawText: sections.join('\n'),
      summary,
    })
  } catch (error) {
    console.error('MSG parse error:', error)
    return NextResponse.json({ error: 'Unable to parse MSG file' }, { status: 500 })
  }
}
