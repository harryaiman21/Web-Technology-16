export { POST } from '../parse-msg/route'

export const runtime = 'nodejs'
