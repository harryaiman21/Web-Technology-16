import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Loader2 } from 'lucide-react'

export default function DashboardLoading() {
  return (
    <div className="min-h-screen p-6 md:p-10 max-w-7xl mx-auto space-y-6">
      <div className="flex items-center gap-3 rounded-md border border-border bg-muted/30 p-4">
        <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        <div>
          <p className="text-sm font-medium">Loading LogiSense dashboard</p>
          <p className="text-sm text-muted-foreground">
            Fetching generated SOPs, articles, and ingestion status.
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, index) => (
          <Card key={index} className="animate-pulse">
            <CardHeader className="pb-2">
              <div className="h-4 w-28 rounded bg-muted" />
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="h-7 w-16 rounded bg-muted" />
              <div className="h-3 w-32 rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-5 w-52 rounded bg-muted" />
          <div className="h-4 w-80 max-w-full rounded bg-muted" />
        </CardHeader>
        <CardContent className="space-y-3">
          {Array.from({ length: 5 }).map((_, index) => (
            <div key={index} className="h-10 rounded bg-muted" />
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
