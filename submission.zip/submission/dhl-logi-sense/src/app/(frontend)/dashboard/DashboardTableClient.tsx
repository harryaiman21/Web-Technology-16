'use client'

import React, { useEffect, useMemo, useRef, useState, useTransition } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import Link from 'next/link'
import { deleteDocuments } from './actions'
import {
  BookOpen,
  CalendarDays,
  ArrowRight,
  ClipboardList,
  FolderTree,
  Loader2,
  Network,
  Search,
  ShieldAlert,
  Trash2,
  X,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react'
import { cn } from '@/utilities/ui'
import type { AppRole } from '@/lib/appUsers'

type DocumentData = {
  id: string | number
  title: string
  createdAt: string
  category: string
  type: 'sops' | 'articles'
  sourceType: string
  patternIds: string[]
}

type ExceptionInsight = {
  id: string
  label: string
  description: string
  severity: string
  count: number
  topCategory: string
  nextAction: string
  lastSeen: string | null
  docKeys: string[]
}

type SimilarCase = {
  id: string | number
  type: 'sops' | 'articles'
  title: string
  category: string
  createdAt: string
  score: number
  reasons: string[]
}

const SWC_RAIL_COPY_COUNT = 6
const PAGE_SIZE = 10

export function DashboardTableClient({
  documents,
  role,
  categories,
  exceptionInsights,
  similarCases,
}: {
  documents: DocumentData[]
  role: AppRole
  categories: string[]
  exceptionInsights: ExceptionInsight[]
  similarCases: Record<string, SimilarCase[]>
}) {
  const [filter, setFilter] = useState<'all' | 'sops' | 'articles'>('all')
  const [query, setQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [isDeleting, setIsDeleting] = useState(false)
  const [openingDocumentKey, setOpeningDocumentKey] = useState<string | null>(null)
  const [isDraggingSwc, setIsDraggingSwc] = useState(false)
  const [isSwcRailPaused, setIsSwcRailPaused] = useState(false)
  const [selectedCaseKey, setSelectedCaseKey] = useState<string | null>(
    documents[0] ? `${documents[0].type}:${documents[0].id}` : null,
  )
  const [isFilterPending, startFilterTransition] = useTransition()

  const [currentPage, setCurrentPage] = useState(1)
  const swcRailRef = useRef<HTMLDivElement | null>(null)
  const swcRailTrackRef = useRef<HTMLDivElement | null>(null)
  const swcDragStartX = useRef(0)
  const swcDragStartScrollLeft = useRef(0)
  const swcDragDistance = useRef(0)
  const canManageDocuments = role === 'T2'
  const documentCounts = useMemo(
    () => ({
      all: documents.length,
      sops: documents.filter((doc) => doc.type === 'sops').length,
      articles: documents.filter((doc) => doc.type === 'articles').length,
    }),
    [documents],
  )
  const categoryCounts = useMemo(() => {
    const counts = new Map<string, number>()

    documents.forEach((doc) => {
      counts.set(doc.category, (counts.get(doc.category) || 0) + 1)
    })

    return [...new Set(categories.length ? categories : documents.map((doc) => doc.category))]
      .filter(Boolean)
      .map((category) => ({ name: category, count: counts.get(category) || 0 }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name))
  }, [categories, documents])

  const selectedCase =
    documents.find((doc) => `${doc.type}:${doc.id}` === selectedCaseKey) || documents[0] || null
  const selectedCaseMatches = selectedCase
    ? similarCases[`${selectedCase.type}:${selectedCase.id}`] || []
    : []
  const caseOptions = documents.slice(0, 6)

  useEffect(() => {
    if (!selectedCaseKey && documents[0]) {
      setSelectedCaseKey(`${documents[0].type}:${documents[0].id}`)
      return
    }

    if (selectedCaseKey && !documents.some((doc) => `${doc.type}:${doc.id}` === selectedCaseKey)) {
      setSelectedCaseKey(documents[0] ? `${documents[0].type}:${documents[0].id}` : null)
    }
  }, [documents, selectedCaseKey])

  const resetResultState = () => {
    setCurrentPage(1)
    setSelectedIds(new Set())
  }
  const displayedCategoryRail =
    categoryCounts.length > 1
      ? Array.from({ length: SWC_RAIL_COPY_COUNT }, (_, copyIndex) =>
          categoryCounts.map((category) => ({ ...category, copyIndex })),
        ).flat()
      : categoryCounts.map((category) => ({ ...category, copyIndex: 0 }))

  useEffect(() => {
    const rail = swcRailRef.current
    const track = swcRailTrackRef.current
    if (!rail || !track || categoryCounts.length < 2) return

    const interval = window.setInterval(() => {
      const singleSequenceWidth = track.scrollWidth / SWC_RAIL_COPY_COUNT

      if (!isDraggingSwc && !isSwcRailPaused && singleSequenceWidth > 2) {
        if (rail.scrollLeft >= singleSequenceWidth) {
          rail.scrollLeft -= singleSequenceWidth
        } else {
          rail.scrollLeft += 1
        }
      }
    }, 48)

    return () => window.clearInterval(interval)
  }, [categoryCounts.length, isDraggingSwc, isSwcRailPaused])

  // Reset pagination and selection when filter changes
  const handleFilterChange = (newFilter: 'all' | 'sops' | 'articles') => {
    startFilterTransition(() => {
      setFilter(newFilter)
      resetResultState()
    })
  }

  const handleQueryChange = (value: string) => {
    startFilterTransition(() => {
      setQuery(value)
      resetResultState()
    })
  }

  const handleCategoryChange = (category: string | null) => {
    startFilterTransition(() => {
      setSelectedCategory((current) => (current === category ? null : category))
      resetResultState()
    })
  }

  const handleCategoryClick = (category: string, event: React.MouseEvent<HTMLButtonElement>) => {
    if (swcDragDistance.current > 10) {
      event.preventDefault()
      event.stopPropagation()
      return
    }

    handleCategoryChange(category)
  }

  const handleSwcPointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.pointerType === 'mouse' && event.button !== 0) return

    const rail = swcRailRef.current
    if (!rail) return

    swcDragStartX.current = event.clientX
    swcDragStartScrollLeft.current = rail.scrollLeft
    swcDragDistance.current = 0
    setIsDraggingSwc(true)
  }

  const handleSwcPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!isDraggingSwc || event.pointerType !== 'mouse') return

    const rail = swcRailRef.current
    if (!rail) return

    const deltaX = event.clientX - swcDragStartX.current
    swcDragDistance.current = Math.max(swcDragDistance.current, Math.abs(deltaX))
    rail.scrollLeft = swcDragStartScrollLeft.current - deltaX

    if (swcDragDistance.current > 10) {
      event.preventDefault()
    }
  }

  const handleSwcPointerEnd = () => {
    setIsDraggingSwc(false)
    window.setTimeout(() => {
      swcDragDistance.current = 0
    }, 0)
  }

  // Filter documents based on selection, then slice to the current page
  const normalizedQuery = query.trim().toLowerCase()
  const filteredDocs = documents.filter((doc) => {
    const matchesType = filter === 'all' || doc.type === filter
    const matchesCategory = !selectedCategory || doc.category === selectedCategory
    const matchesQuery =
      normalizedQuery.length === 0 ||
      doc.title.toLowerCase().includes(normalizedQuery) ||
      doc.category.toLowerCase().includes(normalizedQuery)

    return matchesType && matchesCategory && matchesQuery
  })
  const totalPages = Math.max(1, Math.ceil(filteredDocs.length / PAGE_SIZE))
  const safeCurrentPage = Math.min(currentPage, totalPages)
  const pageStartIndex = filteredDocs.length === 0 ? 0 : (safeCurrentPage - 1) * PAGE_SIZE
  const pageEndIndex = Math.min(pageStartIndex + PAGE_SIZE, filteredDocs.length)
  const visibleDocs = filteredDocs.slice(pageStartIndex, pageEndIndex)
  const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1).filter(
    (pageNumber) =>
      pageNumber === 1 || pageNumber === totalPages || Math.abs(pageNumber - safeCurrentPage) <= 1,
  )
  const visibleKeys = visibleDocs.map((doc) => `${doc.type}:${doc.id}`)
  const selectedVisibleCount = visibleKeys.filter((key) => selectedIds.has(key)).length
  const allVisibleSelected = selectedVisibleCount === visibleDocs.length && visibleDocs.length > 0

  useEffect(() => {
    if (currentPage > totalPages) {
      setCurrentPage(totalPages)
    }
  }, [currentPage, totalPages])

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      // Only select the ones currently visible to prevent accidental mass deletion
      setSelectedIds(new Set(visibleKeys))
    } else {
      setSelectedIds(new Set())
    }
  }

  const handleSelectOne = (doc: DocumentData, checked: boolean) => {
    const newSet = new Set(selectedIds)
    const documentKey = `${doc.type}:${doc.id}`
    if (checked) {
      newSet.add(documentKey)
    } else {
      newSet.delete(documentKey)
    }
    setSelectedIds(newSet)
  }

  const handleDelete = async () => {
    if (selectedIds.size === 0 || !canManageDocuments) return
    setIsDeleting(true)

    const itemsToDelete = documents
      .filter((doc) => selectedIds.has(`${doc.type}:${doc.id}`))
      .map((doc) => ({ id: doc.id, type: doc.type }))

    try {
      await deleteDocuments(itemsToDelete)
      setSelectedIds(new Set())
      setCurrentPage(1)
    } finally {
      setIsDeleting(false)
    }
  }

  return (
    <Card className="min-w-0 overflow-hidden">
      <CardHeader className="flex flex-col items-start justify-between gap-4 p-4 sm:p-6 lg:flex-row lg:items-center">
        <div className="min-w-0 space-y-1">
          <CardTitle className="text-lg sm:text-xl">Generated Knowledge Base</CardTitle>
          <CardDescription>
            Search by document title or SWC, then review generated SOPs and articles before teams
            rely on them.
          </CardDescription>
        </div>
        <div className="flex w-full flex-col gap-2 sm:flex-row lg:w-auto">
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="h-9 w-full justify-start gap-2 px-3 text-sm transition-all duration-200 active:scale-[0.98] sm:w-auto"
              >
                <ShieldAlert className="h-4 w-4 text-destructive" />
                <span className="min-w-0 truncate">Exception Patterns</span>
                <Badge
                  className="ml-auto"
                  variant={exceptionInsights.length > 0 ? 'destructive' : 'secondary'}
                >
                  {exceptionInsights.length}
                </Badge>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[88vh] max-w-4xl overflow-hidden p-0">
              <DialogHeader className="border-b border-border p-5 pr-12 text-left">
                <DialogTitle className="flex items-center gap-2">
                  <ShieldAlert className="h-5 w-5 text-destructive" />
                  Exception Pattern Detection
                </DialogTitle>
                <DialogDescription>
                  Recurring operational exceptions detected across generated SOPs and articles.
                </DialogDescription>
              </DialogHeader>
              <div className="max-h-[68vh] overflow-y-auto p-4 sm:p-5">
                {exceptionInsights.length === 0 ? (
                  <div className="rounded-md border border-dashed border-border bg-muted/30 p-4 text-sm text-muted-foreground">
                    No recurring exception pattern detected yet. New ingested cases will appear here
                    once a logistics signal repeats.
                  </div>
                ) : (
                  <div className="grid gap-3 lg:grid-cols-2">
                    {exceptionInsights.map((pattern) => (
                      <div
                        className="rounded-md border border-border bg-card p-3 shadow-sm"
                        key={pattern.id}
                      >
                        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                          <div className="min-w-0 space-y-1">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-medium">{pattern.label}</span>
                              <Badge
                                variant={pattern.severity === 'High' ? 'destructive' : 'secondary'}
                                className="h-6"
                              >
                                {pattern.severity}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{pattern.description}</p>
                          </div>
                          <div className="flex shrink-0 items-center gap-2 rounded-md bg-secondary px-2.5 py-1.5 text-sm font-semibold text-secondary-foreground">
                            {pattern.count}
                            <span className="text-xs font-normal">cases</span>
                          </div>
                        </div>
                        <div className="mt-3 grid gap-2 text-xs text-muted-foreground sm:grid-cols-2">
                          <div>
                            SWC focus:{' '}
                            <span className="font-medium text-foreground">
                              {pattern.topCategory}
                            </span>
                          </div>
                          <div>
                            Last seen:{' '}
                            <span className="font-medium text-foreground">
                              {pattern.lastSeen
                                ? new Date(pattern.lastSeen).toLocaleDateString()
                                : 'No date'}
                            </span>
                          </div>
                        </div>
                        <div className="mt-3 flex items-start gap-2 rounded-md bg-muted/50 px-3 py-2 text-xs text-muted-foreground">
                          <ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-foreground" />
                          <span>{pattern.nextAction}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>

          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="h-9 w-full justify-start gap-2 px-3 text-sm transition-all duration-200 active:scale-[0.98] sm:w-auto"
              >
                <Network className="h-4 w-4 text-primary" />
                <span className="min-w-0 truncate">Similar Cases</span>
                <Badge className="ml-auto" variant="secondary">
                  {documents.length}
                </Badge>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-h-[88vh] max-w-5xl overflow-hidden p-0">
              <DialogHeader className="border-b border-border p-5 pr-12 text-left">
                <DialogTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5 text-primary" />
                  Similar Case Finder
                </DialogTitle>
                <DialogDescription>
                  Select a recent case and reuse proven guidance from matching SWCs and exception
                  patterns.
                </DialogDescription>
              </DialogHeader>
              <div className="max-h-[68vh] overflow-y-auto p-4 sm:p-5">
                {documents.length === 0 ? (
                  <div className="rounded-md border border-dashed border-border bg-muted/30 p-4 text-sm text-muted-foreground">
                    Similar cases will appear after SOPs or articles are generated.
                  </div>
                ) : (
                  <div className="grid gap-4 lg:grid-cols-[0.8fr_1.2fr]">
                    <div className="space-y-2">
                      <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                        Recent cases
                      </div>
                      {caseOptions.map((doc) => {
                        const documentKey = `${doc.type}:${doc.id}`
                        const isSelected = selectedCaseKey === documentKey

                        return (
                          <button
                            aria-pressed={isSelected}
                            className={cn(
                              'flex w-full items-start gap-2 rounded-md border px-3 py-2 text-left transition-colors hover:border-primary/50 hover:bg-accent',
                              isSelected
                                ? 'border-primary bg-primary/10'
                                : 'border-border bg-background',
                            )}
                            key={documentKey}
                            onClick={() => setSelectedCaseKey(documentKey)}
                            type="button"
                          >
                            {doc.type === 'sops' ? (
                              <ClipboardList className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                            ) : (
                              <BookOpen className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                            )}
                            <span className="min-w-0">
                              <span className="line-clamp-2 text-sm font-medium leading-5">
                                {doc.title}
                              </span>
                              <span className="mt-1 block truncate text-xs text-muted-foreground">
                                {doc.category}
                              </span>
                            </span>
                          </button>
                        )
                      })}
                    </div>

                    <div className="min-w-0 rounded-md border border-border bg-muted/20 p-3">
                      {selectedCase && (
                        <div className="mb-3 border-b border-border pb-3">
                          <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                            Comparing against
                          </div>
                          <div className="mt-1 line-clamp-2 text-sm font-semibold">
                            {selectedCase.title}
                          </div>
                        </div>
                      )}

                      {selectedCaseMatches.length === 0 ? (
                        <div className="text-sm text-muted-foreground">
                          No strong match yet. Try another recent case or ingest more source
                          material for this SWC.
                        </div>
                      ) : (
                        <div className="grid gap-2 sm:grid-cols-2">
                          {selectedCaseMatches.map((match) => {
                            const isSop = match.type === 'sops'

                            return (
                              <Link
                                className="block rounded-md border border-border bg-background p-3 transition-colors hover:border-primary/60 hover:bg-accent"
                                href={`/dashboard/${isSop ? 'sop' : 'article'}/${match.id}`}
                                key={`${match.type}:${match.id}`}
                              >
                                <div className="flex items-start justify-between gap-3">
                                  <div className="min-w-0">
                                    <div className="flex flex-wrap items-center gap-2">
                                      <Badge
                                        variant={isSop ? 'default' : 'secondary'}
                                        className="h-6 gap-1 text-[10px] uppercase"
                                      >
                                        {isSop ? (
                                          <ClipboardList className="h-3 w-3" />
                                        ) : (
                                          <BookOpen className="h-3 w-3" />
                                        )}
                                        {isSop ? 'SOP' : 'Article'}
                                      </Badge>
                                      <span className="text-xs text-muted-foreground">
                                        Match score {match.score}
                                      </span>
                                    </div>
                                    <div className="mt-2 line-clamp-2 text-sm font-medium">
                                      {match.title}
                                    </div>
                                    <div className="mt-2 flex flex-wrap gap-1.5">
                                      {match.reasons.map((reason) => (
                                        <span
                                          className="rounded-full bg-secondary px-2 py-0.5 text-[10px] text-secondary-foreground"
                                          key={reason}
                                        >
                                          {reason}
                                        </span>
                                      ))}
                                    </div>
                                  </div>
                                  <ArrowRight className="mt-1 h-4 w-4 shrink-0 text-muted-foreground" />
                                </div>
                              </Link>
                            )
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="min-w-0 space-y-4 p-4 pt-0 sm:p-6 sm:pt-0">
        <div className="grid gap-3 rounded-md border border-border bg-card p-3 lg:grid-cols-[1fr_auto_auto] lg:items-center">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="h-10 pl-9 pr-9"
              onChange={(event) => handleQueryChange(event.target.value)}
              placeholder="Search document title or SWC"
              type="search"
              value={query}
            />
            {query && (
              <button
                aria-label="Clear search"
                className="absolute right-2 top-1/2 grid h-6 w-6 -translate-y-1/2 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-accent-foreground"
                onClick={() => handleQueryChange('')}
                type="button"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <div className="grid w-full grid-cols-3 rounded-md bg-secondary p-1 lg:w-auto">
            <Button
              size="sm"
              variant={filter === 'all' ? 'default' : 'ghost'}
              onClick={() => handleFilterChange('all')}
              aria-pressed={filter === 'all'}
              className="h-9 min-w-0 px-1 text-xs transition-all duration-200 active:scale-[0.98] sm:min-w-24 sm:px-2 sm:text-sm"
            >
              All ({documentCounts.all})
            </Button>
            <Button
              size="sm"
              variant={filter === 'sops' ? 'default' : 'ghost'}
              onClick={() => handleFilterChange('sops')}
              aria-pressed={filter === 'sops'}
              className="h-9 min-w-0 px-1 text-xs transition-all duration-200 active:scale-[0.98] sm:min-w-24 sm:px-2 sm:text-sm"
            >
              SOPs ({documentCounts.sops})
            </Button>
            <Button
              size="sm"
              variant={filter === 'articles' ? 'default' : 'ghost'}
              onClick={() => handleFilterChange('articles')}
              aria-pressed={filter === 'articles'}
              className="h-9 min-w-0 px-1 text-xs transition-all duration-200 active:scale-[0.98] sm:min-w-24 sm:px-2 sm:text-sm"
            >
              Articles ({documentCounts.articles})
            </Button>
          </div>

          {canManageDocuments && (
            <Button
              variant="destructive"
              size="sm"
              disabled={selectedIds.size === 0 || isDeleting}
              onClick={handleDelete}
              className="h-10 justify-center transition-all duration-200 active:scale-[0.98] lg:min-w-44"
              title={
                selectedIds.size > 0
                  ? `Deletes ${selectedIds.size} selected visible document${selectedIds.size === 1 ? '' : 's'}`
                  : 'Select visible documents to enable deletion'
              }
            >
              {isDeleting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Trash2 className="h-4 w-4" />
              )}
              {isDeleting ? 'Deleting selected' : `Delete selected (${selectedIds.size})`}
            </Button>
          )}
        </div>

        {categoryCounts.length > 0 && (
          <div className="min-w-0 overflow-hidden rounded-md border border-border bg-muted/20 p-3">
            <div className="mb-3 flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-2 text-sm font-medium">
                <FolderTree className="h-4 w-4 text-muted-foreground" />
                Available SWCs
              </div>
              {selectedCategory && (
                <button
                  type="button"
                  className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
                  onClick={() => handleCategoryChange(null)}
                >
                  Clear SWC filter
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            <div
              className={cn(
                'swc-rail relative cursor-grab select-none overflow-x-auto overflow-y-hidden active:cursor-grabbing [&_*]:select-none',
                isDraggingSwc && 'is-dragging cursor-grabbing',
              )}
              onPointerCancel={handleSwcPointerEnd}
              onPointerDown={handleSwcPointerDown}
              onPointerLeave={handleSwcPointerEnd}
              onPointerMove={handleSwcPointerMove}
              onPointerUp={handleSwcPointerEnd}
              onTouchStart={() => setIsSwcRailPaused(true)}
              onTouchEnd={() => setIsSwcRailPaused(false)}
              ref={swcRailRef}
            >
              <div className="flex w-max max-w-none gap-2" ref={swcRailTrackRef}>
                {displayedCategoryRail.map((category) => {
                  const isSelected = selectedCategory === category.name
                  const isDuplicate = category.copyIndex > 0

                  return (
                    <button
                      aria-hidden={isDuplicate}
                      aria-pressed={isSelected}
                      className={cn(
                        'group inline-flex h-8 shrink-0 items-center gap-2 rounded-full border px-3 text-xs font-medium shadow-sm transition-[background-color,border-color,box-shadow,color] duration-200 hover:border-primary/60 hover:bg-accent hover:shadow-[0_0_18px_color-mix(in_oklch,var(--primary)_32%,transparent)]',
                        isSelected
                          ? 'border-primary bg-primary text-primary-foreground shadow-[0_0_18px_color-mix(in_oklch,var(--primary)_36%,transparent)]'
                          : 'border-border bg-card text-card-foreground',
                      )}
                      key={`${category.name}-${category.copyIndex}`}
                      onClick={(event) => handleCategoryClick(category.name, event)}
                      tabIndex={isDuplicate ? -1 : 0}
                      type="button"
                    >
                      <span className="max-w-44 truncate sm:max-w-64">{category.name}</span>
                      <span
                        className={cn(
                          'rounded-full px-1.5 py-0.5 text-[10px]',
                          isSelected
                            ? 'bg-primary-foreground/20 text-primary-foreground'
                            : 'bg-secondary text-secondary-foreground',
                        )}
                      >
                        {category.count}
                      </span>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>
        )}

        <div className="flex flex-col gap-1 rounded-md border border-border bg-muted/30 px-3 py-2 text-sm text-muted-foreground transition-colors duration-200 sm:flex-row sm:items-center sm:justify-between">
          <span>
            {filteredDocs.length > 0
              ? `Showing ${pageStartIndex + 1}-${pageEndIndex} of ${filteredDocs.length}`
              : 'Showing 0 of 0'}{' '}
            {filter === 'all' ? 'documents' : filter}.
          </span>
          <span className="inline-flex min-h-5 items-center gap-2">
            {isFilterPending ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Updating list...
              </>
            ) : canManageDocuments && selectedIds.size > 0 ? (
              `${selectedIds.size} selected. Deletion applies only to checked rows.`
            ) : normalizedQuery || selectedCategory ? (
              'Filters update the visible review list immediately.'
            ) : !canManageDocuments ? (
              'Open a document to review the generated guidance and source evidence.'
            ) : (
              'Select rows only when you intend to remove generated content.'
            )}
          </span>
        </div>
        <div className="hidden overflow-x-auto rounded-md border border-border md:block">
          <Table>
            <TableHeader>
              <TableRow>
                {canManageDocuments && (
                  <TableHead className="w-[50px]">
                    <Checkbox
                      checked={allVisibleSelected}
                      onCheckedChange={handleSelectAll}
                      aria-label="Select all visible documents"
                    />
                  </TableHead>
                )}
                <TableHead className="w-[50px]">No.</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Document Title</TableHead>
                <TableHead>Date Created</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {visibleDocs.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={canManageDocuments ? 6 : 5}
                    className="text-center py-6 text-muted-foreground"
                  >
                    No documents found.
                  </TableCell>
                </TableRow>
              ) : (
                visibleDocs.map((doc, index) => {
                  const documentKey = `${doc.type}:${doc.id}`
                  const isSop = doc.type === 'sops'
                  const isOpening = openingDocumentKey === documentKey

                  return (
                    <TableRow
                      key={documentKey}
                      data-state={selectedIds.has(documentKey) ? 'selected' : undefined}
                      className={cn(
                        'transition-[background-color,opacity] duration-200',
                        isDeleting &&
                          selectedIds.has(documentKey) &&
                          'pointer-events-none opacity-60',
                      )}
                    >
                      {canManageDocuments && (
                        <TableCell>
                          <Checkbox
                            checked={selectedIds.has(documentKey)}
                            onCheckedChange={(checked) => handleSelectOne(doc, checked as boolean)}
                            aria-label={`Select ${isSop ? 'SOP' : 'article'} ${doc.title}`}
                          />
                        </TableCell>
                      )}
                      <TableCell>{pageStartIndex + index + 1}</TableCell>
                      <TableCell>
                        <Badge
                          variant={isSop ? 'default' : 'secondary'}
                          className="h-6 w-24 justify-center gap-1 uppercase text-[10px]"
                        >
                          {isSop ? (
                            <ClipboardList className="h-3 w-3" aria-hidden="true" />
                          ) : (
                            <BookOpen className="h-3 w-3" aria-hidden="true" />
                          )}
                          {isSop ? 'SOP' : 'Article'}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-[28rem] font-medium">
                        <span className="line-clamp-2">{doc.title}</span>
                        <span className="mt-1 inline-flex max-w-full items-center gap-1 text-xs font-normal text-muted-foreground">
                          <FolderTree className="h-3 w-3" />
                          <span className="truncate">{doc.category}</span>
                        </span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-muted-foreground">
                        {new Date(doc.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <Link
                          href={`/dashboard/${doc.type === 'sops' ? 'sop' : 'article'}/${doc.id}`}
                          onClick={() => setOpeningDocumentKey(documentKey)}
                        >
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-9 min-w-24 transition-all duration-200 active:scale-[0.98]"
                            disabled={isOpening}
                          >
                            {isOpening && <Loader2 className="h-4 w-4 animate-spin" />}
                            {isOpening ? 'Opening' : 'Open'}
                          </Button>
                        </Link>
                      </TableCell>
                    </TableRow>
                  )
                })
              )}
            </TableBody>
          </Table>
        </div>

        <div className="space-y-3 md:hidden">
          {visibleDocs.length === 0 ? (
            <div className="rounded-md border border-border bg-muted/30 p-5 text-center text-sm text-muted-foreground">
              No documents found.
            </div>
          ) : (
            visibleDocs.map((doc, index) => {
              const documentKey = `${doc.type}:${doc.id}`
              const isSop = doc.type === 'sops'
              const isOpening = openingDocumentKey === documentKey

              return (
                <div
                  className={cn(
                    'rounded-md border border-border bg-card p-3 shadow-sm transition-[background-color,opacity]',
                    selectedIds.has(documentKey) && 'bg-muted/50',
                    isDeleting && selectedIds.has(documentKey) && 'pointer-events-none opacity-60',
                  )}
                  key={documentKey}
                >
                  <div className="flex items-start gap-3">
                    {canManageDocuments && (
                      <Checkbox
                        checked={selectedIds.has(documentKey)}
                        onCheckedChange={(checked) => handleSelectOne(doc, checked as boolean)}
                        aria-label={`Select ${isSop ? 'SOP' : 'article'} ${doc.title}`}
                        className="mt-1"
                      />
                    )}
                    <div className="min-w-0 flex-1 space-y-3">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge
                          variant={isSop ? 'default' : 'secondary'}
                          className="h-6 justify-center gap-1 uppercase text-[10px]"
                        >
                          {isSop ? (
                            <ClipboardList className="h-3 w-3" aria-hidden="true" />
                          ) : (
                            <BookOpen className="h-3 w-3" aria-hidden="true" />
                          )}
                          {isSop ? 'SOP' : 'Article'}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          No. {pageStartIndex + index + 1}
                        </span>
                        <Badge variant="outline" className="h-6 max-w-full gap-1 text-[10px]">
                          <FolderTree className="h-3 w-3" />
                          <span className="truncate">{doc.category}</span>
                        </Badge>
                      </div>
                      <h3 className="line-clamp-3 text-sm font-semibold leading-5">{doc.title}</h3>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <CalendarDays className="h-3.5 w-3.5" />
                        {new Date(doc.createdAt).toLocaleDateString()}
                      </div>
                      <Link
                        className="block"
                        href={`/dashboard/${doc.type === 'sops' ? 'sop' : 'article'}/${doc.id}`}
                        onClick={() => setOpeningDocumentKey(documentKey)}
                      >
                        <Button
                          variant="outline"
                          size="sm"
                          className="h-9 w-full transition-all duration-200 active:scale-[0.98]"
                          disabled={isOpening}
                        >
                          {isOpening && <Loader2 className="h-4 w-4 animate-spin" />}
                          {isOpening ? 'Opening' : 'Open'}
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {filteredDocs.length > PAGE_SIZE && (
          <div className="flex flex-col gap-3 rounded-md border border-border bg-card px-3 py-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="text-sm text-muted-foreground">
              Page {safeCurrentPage} of {totalPages}
            </div>
            <div className="flex flex-wrap items-center justify-center gap-1">
              <Button
                aria-label="Previous page"
                className="h-9 px-2"
                disabled={safeCurrentPage === 1}
                onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
                size="sm"
                variant="outline"
              >
                <ChevronLeft className="h-4 w-4" />
                Prev
              </Button>
              {pageNumbers.map((pageNumber, index) => {
                const previousPageNumber = pageNumbers[index - 1]
                const needsEllipsis =
                  previousPageNumber !== undefined && pageNumber - previousPageNumber > 1

                return (
                  <React.Fragment key={pageNumber}>
                    {needsEllipsis && (
                      <span className="grid h-9 w-9 place-items-center text-sm text-muted-foreground">
                        ...
                      </span>
                    )}
                    <Button
                      aria-current={pageNumber === safeCurrentPage ? 'page' : undefined}
                      className="h-9 w-9 px-0"
                      onClick={() => setCurrentPage(pageNumber)}
                      size="sm"
                      variant={pageNumber === safeCurrentPage ? 'default' : 'outline'}
                    >
                      {pageNumber}
                    </Button>
                  </React.Fragment>
                )
              })}
              <Button
                aria-label="Next page"
                className="h-9 px-2"
                disabled={safeCurrentPage === totalPages}
                onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))}
                size="sm"
                variant="outline"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
