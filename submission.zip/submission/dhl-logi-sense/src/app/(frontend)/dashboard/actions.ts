'use server'

import { getPayload } from 'payload'
import configPromise from '@payload-config'
import { revalidatePath } from 'next/cache'
import { requireCurrentAppUser } from '@/lib/appUsers'

export async function deleteDocuments(items: { id: number | string; type: 'sops' | 'articles' }[]) {
  await requireCurrentAppUser('T2')

  const payload = await getPayload({ config: configPromise })

  for (const item of items) {
    try {
      await payload.delete({
        collection: item.type,
        id: item.id,
      })
    } catch (error) {
      console.error(`Failed to delete ${item.type} with ID ${item.id}:`, error)
    }
  }

  // Force the dashboard to refresh and show the updated list
  revalidatePath('/dashboard')
}

export async function updateDocumentContent(
  id: string | number,
  collectionType: 'sops' | 'articles',
  newContent: string,
) {
  await requireCurrentAppUser('T2')

  const payload = await getPayload({ config: configPromise })

  try {
    await payload.update({
      collection: collectionType,
      id: id,
      data: {
        content: newContent,
      },
    })

    // Force Next.js to refresh the page cache to show the new content immediately
    revalidatePath(`/dashboard/${collectionType === 'sops' ? 'sop' : 'article'}/${id}`)
    return { success: true }
  } catch (error) {
    console.error(`Failed to update ${collectionType} ${id}:`, error)
    return { success: false, error: 'Failed to save document' }
  }
}
