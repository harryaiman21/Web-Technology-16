import React from 'react'
import { getPayload } from 'payload'
import configPromise from '@payload-config'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, ArrowLeft, BookOpen, Clock, Server } from 'lucide-react'
import TipTapEditor from '@/components/TipTapEditor'
import { requireCurrentAppUser } from '@/lib/appUsers'

export const dynamic = 'force-dynamic'

export default async function articleDocumentPage({ params }: { params: Promise<{ id: string }> }) {
  const appUser = await requireCurrentAppUser()
  const { id } = await params
  let payload

  try {
    payload = await getPayload({ config: configPromise })
  } catch (error) {
    return (
      <div className="mx-auto min-h-screen max-w-6xl space-y-6 px-4 py-5 sm:px-6 md:p-10">
        <Link href="/dashboard" className="inline-flex">
          <Button variant="ghost" className="pl-0 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
          </Button>
        </Link>
        <div className="rounded-md border border-destructive/40 bg-destructive/10 p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div className="space-y-1">
              <h1 className="text-2xl font-semibold tracking-tight">Article unavailable</h1>
              <p className="text-sm text-muted-foreground">
                LogiSense could not connect to the knowledge base, so this article cannot be loaded
                yet.
              </p>
              <p className="text-sm font-medium">Check database connectivity, then reload.</p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // 1. Fetch the article document and heavily populate relationships (like category and basedOn)
  let article
  try {
    article = await payload.findByID({
      collection: 'articles',
      id: id,
      depth: 2, // Ensures we get the full category data, not just the ID
    })
  } catch (error) {
    notFound() // Triggers Next.js 404 page if ID is invalid
  }

  // Type assertion helpers since Payload relationships can be string IDs or full objects
  const categoryTitle =
    typeof article.category === 'object' && article.category !== null
      ? article.category.title
      : 'Uncategorized'
  const sourceId =
    typeof article.basedOn === 'object' && article.basedOn !== null
      ? article.basedOn.id
      : article.basedOn
  const rawText =
    typeof article.basedOn === 'object' && article.basedOn !== null
      ? article.basedOn.rawText
      : 'Raw text not available.'
  const canEdit = appUser.role === 'T2'

  return (
    <div className="mx-auto min-h-screen w-full max-w-6xl space-y-6 px-4 py-5 sm:px-6 md:space-y-8 md:p-10">
      {/* Top Navigation */}
      <Link href="/dashboard" className="inline-flex">
        <Button variant="ghost" className="pl-0 text-muted-foreground hover:text-foreground">
          <ArrowLeft className="w-4 h-4 mr-2" /> Back to Dashboard
        </Button>
      </Link>

      {/* Header & Meta Data */}
      <div className="w-full space-y-4">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="default" className="gap-1 uppercase">
            <BookOpen className="h-3 w-3" aria-hidden="true" />
            Article
          </Badge>
          <Badge variant="outline">{categoryTitle}</Badge>
          <Badge variant="secondary">{appUser.role} access</Badge>
        </div>

        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">
            {canEdit
              ? 'Review the generated guidance, compare it with the source text, then edit only the content that needs correction.'
              : 'Review the generated guidance and compare it with the source text before teams rely on it.'}
          </p>
          <h1 className="break-words text-2xl font-bold leading-tight tracking-tight sm:text-3xl md:text-4xl">
            {article.title}
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground sm:gap-4">
          <div className="flex min-w-0 items-center gap-1">
            <Clock className="w-4 h-4" />
            Generated {new Date(article.createdAt).toLocaleDateString()}
          </div>
          <div className="flex min-w-0 items-center gap-1">
            <Server className="w-4 h-4" />
            <span className="break-all">Source RawInput ID: {sourceId}</span>
          </div>
        </div>
      </div>

      <hr className="border-border" />

      {/* The Interactive Editor */}
      <TipTapEditor
        canEdit={canEdit}
        initialContent={article.content as string}
        documentId={article.id}
        collectionType="articles"
        rawText={rawText}
      />
    </div>
  )
}
