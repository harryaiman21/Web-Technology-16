'use client'

import React, { useMemo } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import {
  Activity,
  BarChart3,
  BookOpen,
  CalendarDays,
  ClipboardList,
  Database,
  FileText,
  FolderTree,
  Layers3,
  PieChart as PieChartIcon,
  TrendingUp,
} from 'lucide-react'

import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export type AnalyticsRawInput = {
  id: string | number
  createdAt: string
  sourceType: string
  summary?: string
}

export type AnalyticsDocument = {
  id: string | number
  title: string
  createdAt: string
  type: 'sop' | 'article'
  category: string
}

type AnalyticsDashboardProps = {
  rawInputs: AnalyticsRawInput[]
  documents: AnalyticsDocument[]
  categoryTotal: number
}

const chartColors = [
  'var(--chart-1)',
  'var(--chart-2)',
  'var(--chart-3)',
  'var(--chart-4)',
  'var(--chart-5)',
]

const sourceLabels: Record<string, string> = {
  teams: 'MS Teams',
  email: 'Email',
  screenshot: 'Screenshot',
  handwritten: 'Handwritten',
  training: 'Training',
  txt: 'Text',
  docx: 'Word',
  pdf: 'PDF',
  msg: 'Outlook',
  jpe: 'JPEG',
  jpeg: 'JPEG',
  jpg: 'JPEG',
  png: 'PNG',
  tif: 'TIFF',
  tiff: 'TIFF',
}

const formatSourceType = (sourceType: string) => sourceLabels[sourceType] || sourceType || 'Unknown'

const dateKey = (value: string) =>
  new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric' }).format(new Date(value))

const countBy = <T,>(items: T[], getKey: (item: T) => string) => {
  const counts = new Map<string, number>()

  for (const item of items) {
    const key = getKey(item)
    counts.set(key, (counts.get(key) || 0) + 1)
  }

  return [...counts.entries()]
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value || a.name.localeCompare(b.name))
}

const buildDailySeries = (rawInputs: AnalyticsRawInput[], documents: AnalyticsDocument[]) => {
  const buckets = new Map<
    string,
    { key: string; date: string; inputs: number; sops: number; articles: number }
  >()
  const ensureBucket = (createdAt: string) => {
    const key = new Date(createdAt).toISOString().slice(0, 10)
    const bucket = buckets.get(key) || { key, date: dateKey(createdAt), inputs: 0, sops: 0, articles: 0 }
    buckets.set(key, bucket)
    return bucket
  }

  rawInputs.forEach((input) => {
    ensureBucket(input.createdAt).inputs += 1
  })

  documents.forEach((doc) => {
    const bucket = ensureBucket(doc.createdAt)
    if (doc.type === 'sop') bucket.sops += 1
    else bucket.articles += 1
  })

  return [...buckets.values()]
    .sort((a, b) => a.key.localeCompare(b.key))
    .slice(-14)
}

const EmptyChart = ({ label }: { label: string }) => (
  <div className="grid h-[260px] place-items-center rounded-md border border-dashed border-border bg-muted/30 text-center text-sm text-muted-foreground">
    {label}
  </div>
)

const ChartFrame = ({ children }: { children: React.ReactNode }) => (
  <div className="overflow-x-auto">
    <div className="h-[260px] min-w-[34rem] sm:h-[300px] sm:min-w-0">{children}</div>
  </div>
)

const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null

  return (
    <div className="rounded-md border border-border bg-popover px-3 py-2 text-sm text-popover-foreground shadow-md">
      {label && <p className="mb-1 font-medium">{label}</p>}
      <div className="space-y-1">
        {payload.map((item: any) => (
          <div className="flex items-center gap-2" key={item.dataKey || item.name}>
            <span
              className="h-2.5 w-2.5 rounded-full"
              style={{ background: item.color || item.fill }}
            />
            <span className="text-muted-foreground">{item.name || item.dataKey}</span>
            <span className="font-medium">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

const KpiCard = ({
  title,
  value,
  description,
  icon,
}: {
  title: string
  value: string | number
  description: string
  icon: React.ReactNode
}) => (
  <Card className="min-w-0">
    <CardHeader className="flex flex-row items-center justify-between gap-3 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <div className="text-muted-foreground">{icon}</div>
    </CardHeader>
    <CardContent>
      <div className="truncate text-2xl font-bold">{value}</div>
      <p className="text-xs text-muted-foreground">{description}</p>
    </CardContent>
  </Card>
)

export function AnalyticsDashboard({ rawInputs, documents, categoryTotal }: AnalyticsDashboardProps) {
  const data = useMemo(() => {
    const sops = documents.filter((doc) => doc.type === 'sop')
    const articles = documents.filter((doc) => doc.type === 'article')
    const latestInput = rawInputs[0]?.createdAt
      ? new Date(rawInputs[0].createdAt).toLocaleDateString()
      : 'No inputs yet'

    return {
      sops,
      articles,
      latestInput,
      dailySeries: buildDailySeries(rawInputs, documents),
      sourceBreakdown: countBy(rawInputs, (input) => formatSourceType(input.sourceType)).slice(0, 8),
      categoryBreakdown: countBy(documents, (doc) => doc.category || 'Uncategorized').slice(0, 8),
      documentRatio: [
        { name: 'SOPs', value: sops.length },
        { name: 'Articles', value: articles.length },
      ].filter((item) => item.value > 0),
      recentActivity: [
        ...rawInputs.slice(0, 5).map((input) => ({
          id: `input-${input.id}`,
          type: 'Input',
          label: formatSourceType(input.sourceType),
          title: input.summary || 'New source file received',
          createdAt: input.createdAt,
        })),
        ...documents.slice(0, 5).map((doc) => ({
          id: `doc-${doc.type}-${doc.id}`,
          type: doc.type === 'sop' ? 'SOP' : 'Article',
          label: doc.category,
          title: doc.title,
          createdAt: doc.createdAt,
        })),
      ]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 8),
    }
  }, [rawInputs, documents])

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <KpiCard
          title="Raw Inputs"
          value={rawInputs.length}
          description="Files received from /Issues"
          icon={<Database className="h-4 w-4" />}
        />
        <KpiCard
          title="Generated SOPs"
          value={data.sops.length}
          description="Procedure documents"
          icon={<ClipboardList className="h-4 w-4" />}
        />
        <KpiCard
          title="Articles"
          value={data.articles.length}
          description="Knowledge references"
          icon={<BookOpen className="h-4 w-4" />}
        />
        <KpiCard
          title="Categories"
          value={categoryTotal}
          description="Detected SWCs"
          icon={<FolderTree className="h-4 w-4" />}
        />
        <KpiCard
          title="Latest Input"
          value={data.latestInput}
          description="Most recent source item"
          icon={<CalendarDays className="h-4 w-4" />}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr]">
        <Card className="min-w-0 overflow-hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
              Generated Documents Over Time
            </CardTitle>
            <CardDescription>Daily source input volume compared with generated output.</CardDescription>
          </CardHeader>
          <CardContent>
            {data.dailySeries.length ? (
              <ChartFrame>
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data.dailySeries} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                    <XAxis dataKey="date" tickLine={false} axisLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                    <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Line type="monotone" dataKey="inputs" name="Inputs" stroke="var(--chart-4)" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="sops" name="SOPs" stroke="var(--chart-1)" strokeWidth={2} dot={false} />
                    <Line type="monotone" dataKey="articles" name="Articles" stroke="var(--chart-2)" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </ChartFrame>
            ) : (
              <EmptyChart label="No activity yet." />
            )}
          </CardContent>
        </Card>

        <Card className="min-w-0 overflow-hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <PieChartIcon className="h-5 w-5 text-muted-foreground" />
              SOP vs Article Ratio
            </CardTitle>
            <CardDescription>How generated guidance is split by document type.</CardDescription>
          </CardHeader>
          <CardContent>
            {data.documentRatio.length ? (
              <ChartFrame>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip content={<ChartTooltip />} />
                    <Pie data={data.documentRatio} dataKey="value" nameKey="name" innerRadius={62} outerRadius={95} paddingAngle={4}>
                      {data.documentRatio.map((entry, index) => (
                        <Cell key={entry.name} fill={chartColors[index % chartColors.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </ChartFrame>
            ) : (
              <EmptyChart label="No generated documents yet." />
            )}
            <div className="mt-3 flex flex-wrap gap-2">
              {data.documentRatio.map((item, index) => (
                <Badge className="gap-2" key={item.name} variant="secondary">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: chartColors[index % chartColors.length] }} />
                  {item.name}: {item.value}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="min-w-0 overflow-hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <Layers3 className="h-5 w-5 text-muted-foreground" />
              Input Source Breakdown
            </CardTitle>
            <CardDescription>Which source formats are entering the pipeline most often.</CardDescription>
          </CardHeader>
          <CardContent>
            {data.sourceBreakdown.length ? (
              <ChartFrame>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.sourceBreakdown} layout="vertical" margin={{ left: 8, right: 8, top: 8, bottom: 0 }}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" horizontal={false} />
                    <XAxis type="number" allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                    <YAxis type="category" width={92} dataKey="name" tickLine={false} axisLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="value" name="Inputs" radius={[0, 4, 4, 0]} fill="var(--chart-3)" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartFrame>
            ) : (
              <EmptyChart label="No source inputs yet." />
            )}
          </CardContent>
        </Card>

        <Card className="min-w-0 overflow-hidden">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
              Category Distribution
            </CardTitle>
            <CardDescription>Top SWCs represented across generated SOPs and articles.</CardDescription>
          </CardHeader>
          <CardContent>
            {data.categoryBreakdown.length ? (
              <ChartFrame>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data.categoryBreakdown} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" tickLine={false} axisLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                    <YAxis allowDecimals={false} tickLine={false} axisLine={false} tick={{ fill: 'var(--muted-foreground)', fontSize: 12 }} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="value" name="Documents" radius={[4, 4, 0, 0]} fill="var(--chart-5)" />
                  </BarChart>
                </ResponsiveContainer>
              </ChartFrame>
            ) : (
              <EmptyChart label="No category data yet." />
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="min-w-0">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
            <Activity className="h-5 w-5 text-muted-foreground" />
            Recent Ingestion Activity
          </CardTitle>
          <CardDescription>Latest source files and generated knowledge artifacts.</CardDescription>
        </CardHeader>
        <CardContent>
          {data.recentActivity.length ? (
            <div className="divide-y divide-border rounded-md border border-border">
              {data.recentActivity.map((item) => (
                <div className="flex flex-col gap-2 p-3 sm:flex-row sm:items-center sm:justify-between" key={item.id}>
                  <div className="flex min-w-0 items-start gap-3">
                    <div className="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-md bg-secondary text-secondary-foreground">
                      {item.type === 'SOP' ? (
                        <ClipboardList className="h-4 w-4" />
                      ) : item.type === 'Article' ? (
                        <BookOpen className="h-4 w-4" />
                      ) : (
                        <FileText className="h-4 w-4" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="line-clamp-1 text-sm font-medium">{item.title}</p>
                      <p className="truncate text-xs text-muted-foreground">{item.type} · {item.label}</p>
                    </div>
                  </div>
                  <p className="whitespace-nowrap text-xs text-muted-foreground">
                    {new Date(item.createdAt).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <EmptyChart label="No recent activity yet." />
          )}
        </CardContent>
      </Card>
    </div>
  )
}
