import React from 'react'
import Link from 'next/link'
import { getPayload } from 'payload'
import configPromise from '@payload-config'
import { AlertCircle, ArrowLeft, BarChart3, CheckCircle2, Database, FileText } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { requireCurrentAppUser } from '@/lib/appUsers'
import { AnalyticsDashboard, type AnalyticsDocument, type AnalyticsRawInput } from './AnalyticsDashboard'

export const dynamic = 'force-dynamic'

const toCategoryTitle = (category: unknown) => {
  if (category && typeof category === 'object' && 'title' in category) {
    return String(category.title || 'Uncategorized')
  }

  return 'Uncategorized'
}

export default async function DashboardAnalyticsPage() {
  const appUser = await requireCurrentAppUser()

  try {
    const payload = await getPayload({ config: configPromise })

    const [rawInputs, sops, articles, categories] = await Promise.all([
      payload.find({ collection: 'raw-inputs', depth: 1, limit: 1000, sort: '-createdAt' }),
      payload.find({ collection: 'sops', depth: 1, limit: 1000, sort: '-createdAt' }),
      payload.find({ collection: 'articles', depth: 1, limit: 1000, sort: '-createdAt' }),
      payload.find({ collection: 'categories', limit: 1000 }),
    ])

    const rawInputDocs: AnalyticsRawInput[] = rawInputs.docs.map((doc) => ({
      id: doc.id,
      createdAt: doc.createdAt,
      sourceType: doc.sourceType,
      summary: doc.summary || '',
    }))

    const documentDocs: AnalyticsDocument[] = [
      ...sops.docs.map((doc) => ({
        id: doc.id,
        title: doc.title,
        createdAt: doc.createdAt,
        type: 'sop' as const,
        category: toCategoryTitle(doc.category),
      })),
      ...articles.docs.map((doc) => ({
        id: doc.id,
        title: doc.title,
        createdAt: doc.createdAt,
        type: 'article' as const,
        category: toCategoryTitle(doc.category),
      })),
    ]

    return (
      <main className="mx-auto min-h-screen max-w-7xl space-y-5 px-4 py-5 sm:px-6 md:space-y-8 md:p-10">
        <div className="flex flex-col gap-4 rounded-lg border border-border bg-card p-4 shadow-sm md:flex-row md:items-center md:justify-between md:p-6">
          <div className="min-w-0 max-w-3xl space-y-2">
            <div className="inline-flex items-center gap-2 rounded-full bg-success/15 px-3 py-1 text-xs font-medium text-foreground">
              <CheckCircle2 className="h-3.5 w-3.5 text-success" />
              Analytics workspace online
            </div>
            <div className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
              <Database className="h-3.5 w-3.5" />
              {appUser.role} access
            </div>
            <h1 className="text-2xl font-bold leading-tight tracking-tight md:text-4xl">
              LogiSense Analytics
            </h1>
            <p className="text-sm text-muted-foreground sm:text-base">
              Track source volume, generated knowledge mix, category coverage, and the latest
              ingestion activity from the managed /Issues workflow.
            </p>
          </div>
          <div className="flex w-full flex-col gap-2 sm:w-auto sm:flex-row sm:gap-3">
            <Button asChild variant="outline" className="justify-center">
              <Link href="/dashboard">
                <ArrowLeft className="h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>
          </div>
        </div>

        <AnalyticsDashboard
          rawInputs={rawInputDocs}
          documents={documentDocs}
          categoryTotal={categories.totalDocs}
        />
      </main>
    )
  } catch (error) {
    return (
      <main className="mx-auto min-h-screen max-w-7xl px-4 py-5 sm:px-6 md:p-10">
        <Card className="border-destructive/40 bg-destructive/10">
          <CardContent className="p-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
              <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
              <div className="space-y-1">
                <h1 className="text-2xl font-semibold tracking-tight">Analytics unavailable</h1>
                <p className="text-sm text-muted-foreground">
                  LogiSense could not connect to the knowledge base, so analytics cannot be loaded.
                </p>
                <Button asChild variant="outline" className="mt-3">
                  <Link href="/dashboard">
                    <FileText className="h-4 w-4" />
                    Return to dashboard
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    )
  }
}
