import React from 'react'
import { getPayload } from 'payload'
import configPromise from '@payload-config'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { FileText, Activity, AlertCircle, HardDrive, CheckCircle2, ShieldCheck } from 'lucide-react'
import { DashboardTableClient } from './DashboardTableClient'
import { requireCurrentAppUser } from '@/lib/appUsers'
import type { Article, RawInput, Sop } from '@/payload-types'

// test comment
export const dynamic = 'force-dynamic'

const DASHBOARD_DOCUMENT_LIMIT = 1000

const EXCEPTION_PATTERNS = [
  {
    id: 'invoice-mismatch',
    label: 'Invoice mismatch',
    description: 'Billing, surcharge, tax, and payment discrepancies.',
    severity: 'High',
    keywords: ['invoice', 'mismatch', 'surcharge', 'tax', 'billing', 'payment', 'charge'],
    nextAction: 'Review billing correction SOPs and confirm recalculation steps.',
  },
  {
    id: 'delivery-delay',
    label: 'Delivery or pickup delay',
    description: 'Late pickup, missed delivery, SLA, and shipment hold signals.',
    severity: 'High',
    keywords: ['delay', 'late', 'missed', 'pickup', 'delivery', 'sla', 'hold', 'stuck'],
    nextAction: 'Check escalation path and verify latest customer communication.',
  },
  {
    id: 'customs-clearance',
    label: 'Customs documentation',
    description: 'Missing commercial invoices, clearance, declaration, and HS code issues.',
    severity: 'Medium',
    keywords: ['customs', 'clearance', 'declaration', 'hs code', 'commercial invoice', 'duty'],
    nextAction: 'Validate document checklist before shipment release.',
  },
  {
    id: 'address-consignee',
    label: 'Address or consignee issue',
    description: 'Wrong address, postal code, consignee, and contact detail corrections.',
    severity: 'Medium',
    keywords: ['address', 'consignee', 'postal', 'postcode', 'wrong', 'contact', 'phone'],
    nextAction: 'Confirm corrected consignee details before retrying delivery.',
  },
  {
    id: 'sap-correction',
    label: 'SAP correction workflow',
    description: 'Manual SAP updates, recalculation, save, resend, and process corrections.',
    severity: 'Watch',
    keywords: ['sap', 'recalculate', 'manual', 'remove', 'update', 'save', 'resend'],
    nextAction: 'Open the related SOP and confirm the exact transaction sequence.',
  },
  {
    id: 'customer-escalation',
    label: 'Customer escalation',
    description: 'Complaints, disputes, urgent customer follow-ups, and escalation language.',
    severity: 'High',
    keywords: ['escalation', 'urgent', 'complaint', 'dispute', 'customer', 'remind', 'follow up'],
    nextAction: 'Prioritize the latest case and align response ownership.',
  },
] as const

const STOP_WORDS = new Set([
  'about',
  'after',
  'article',
  'before',
  'case',
  'document',
  'from',
  'issue',
  'procedure',
  'process',
  'sop',
  'step',
  'steps',
  'that',
  'this',
  'with',
])

const toCategoryTitle = (category: unknown) => {
  if (category && typeof category === 'object' && 'title' in category) {
    return String(category.title || 'Uncategorized')
  }

  return 'Uncategorized'
}

const isRawInput = (value: unknown): value is RawInput =>
  Boolean(value && typeof value === 'object' && 'rawText' in value)

const normalizeText = (value: unknown) =>
  String(value || '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim()

const getPatternIds = (signalText: string) =>
  EXCEPTION_PATTERNS.filter((pattern) =>
    pattern.keywords.some((keyword) => signalText.includes(keyword)),
  ).map((pattern) => pattern.id)

const getTitleTokens = (title: string) =>
  normalizeText(title)
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((token) => token.length > 3 && !STOP_WORDS.has(token))

const severityRank = (severity: string) => {
  if (severity === 'High') return 3
  if (severity === 'Medium') return 2
  return 1
}

type DashboardDocument = {
  id: string | number
  title: string
  createdAt: string
  category: string
  type: 'sops' | 'articles'
  sourceType: string
  patternIds: string[]
  signalText: string
}

const buildExceptionInsights = (documents: DashboardDocument[]) =>
  EXCEPTION_PATTERNS.map((pattern) => {
    const matches = documents.filter((doc) => doc.patternIds.includes(pattern.id))
    const categoryCounts = new Map<string, number>()

    matches.forEach((doc) => {
      categoryCounts.set(doc.category, (categoryCounts.get(doc.category) || 0) + 1)
    })

    const topCategory =
      [...categoryCounts.entries()].sort(
        (a, b) => b[1] - a[1] || a[0].localeCompare(b[0]),
      )[0]?.[0] || 'No SWC yet'

    return {
      id: pattern.id,
      label: pattern.label,
      description: pattern.description,
      severity: pattern.severity,
      count: matches.length,
      topCategory,
      nextAction: pattern.nextAction,
      lastSeen: matches[0]?.createdAt || null,
      docKeys: matches.slice(0, 3).map((doc) => `${doc.type}:${doc.id}`),
    }
  })
    .filter((pattern) => pattern.count > 0)
    .sort((a, b) => severityRank(b.severity) - severityRank(a.severity) || b.count - a.count)

const buildSimilarCases = (documents: DashboardDocument[]) => {
  const tokensByKey = new Map<string, Set<string>>(
    documents.map((doc) => [`${doc.type}:${doc.id}`, new Set(getTitleTokens(doc.title))]),
  )

  return Object.fromEntries(
    documents.map((doc) => {
      const documentKey = `${doc.type}:${doc.id}`
      const docTokens = tokensByKey.get(documentKey) || new Set<string>()
      const matches = documents
        .filter((candidate) => `${candidate.type}:${candidate.id}` !== documentKey)
        .map((candidate) => {
          const candidateKey = `${candidate.type}:${candidate.id}`
          const candidateTokens = tokensByKey.get(candidateKey) || new Set<string>()
          const sharedTokens = [...docTokens].filter((token) => candidateTokens.has(token))
          const sharedPatterns = doc.patternIds.filter((patternId) =>
            candidate.patternIds.includes(patternId),
          )

          const reasons = [
            candidate.category === doc.category ? 'Same SWC' : '',
            sharedPatterns.length > 0 ? 'Matching exception pattern' : '',
            sharedTokens.length > 0 ? `Shared terms: ${sharedTokens.slice(0, 2).join(', ')}` : '',
            candidate.sourceType === doc.sourceType ? 'Same source type' : '',
          ].filter(Boolean)

          const score =
            (candidate.category === doc.category ? 4 : 0) +
            sharedPatterns.length * 3 +
            sharedTokens.length +
            (candidate.sourceType === doc.sourceType ? 1 : 0)

          return {
            id: candidate.id,
            type: candidate.type,
            title: candidate.title,
            category: candidate.category,
            createdAt: candidate.createdAt,
            score,
            reasons: reasons.slice(0, 3),
          }
        })
        .filter((candidate) => candidate.score >= 4)
        .sort(
          (a, b) =>
            b.score - a.score || new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
        )
        .slice(0, 3)

      return [documentKey, matches]
    }),
  )
}

export default async function DashboardPage() {
  const appUser = await requireCurrentAppUser()
  let rawInputs
  let sops
  let articles
  let categories

  try {
    const payload = await getPayload({ config: configPromise })

    rawInputs = await payload.find({ collection: 'raw-inputs', limit: 10, sort: '-createdAt' })
    sops = await payload.find({
      collection: 'sops',
      depth: 1,
      limit: DASHBOARD_DOCUMENT_LIMIT,
      sort: '-createdAt',
    })
    articles = await payload.find({
      collection: 'articles',
      depth: 1,
      limit: DASHBOARD_DOCUMENT_LIMIT,
      sort: '-createdAt',
    })
    categories = await payload.find({ collection: 'categories', limit: 1000, sort: 'title' })
  } catch (error) {
    return (
      <div className="mx-auto min-h-screen w-full max-w-7xl px-4 py-5 sm:px-6 md:p-10">
        <div className="rounded-md border border-destructive/40 bg-destructive/10 p-5">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-start">
            <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
            <div className="space-y-1">
              <h1 className="text-2xl font-semibold tracking-tight">
                Knowledge source unavailable
              </h1>
              <p className="text-sm text-muted-foreground">
                LogiSense could not connect to the Payload/Postgres knowledge base, so generated
                SOPs and articles cannot be loaded yet.
              </p>
              <p className="text-sm font-medium">
                Check database connectivity, then reload the dashboard.
              </p>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Normalize and merge SOPs and Articles for the unified table
  const unifiedDocuments: DashboardDocument[] = [
    ...sops.docs.map((doc: Sop) => {
      const basedOn = isRawInput(doc.basedOn) ? doc.basedOn : null
      const signalText = normalizeText(
        [
          doc.title,
          doc.content,
          toCategoryTitle(doc.category),
          basedOn?.summary,
          basedOn?.rawText,
        ].join(' '),
      )

      return {
        id: doc.id,
        title: doc.title,
        createdAt: doc.createdAt,
        category: toCategoryTitle(doc.category),
        type: 'sops' as const,
        sourceType: basedOn?.sourceType || 'training',
        patternIds: getPatternIds(signalText),
        signalText,
      }
    }),
    ...articles.docs.map((doc: Article) => {
      const basedOn = isRawInput(doc.basedOn) ? doc.basedOn : null
      const signalText = normalizeText(
        [
          doc.title,
          doc.content,
          toCategoryTitle(doc.category),
          basedOn?.summary,
          basedOn?.rawText,
        ].join(' '),
      )

      return {
        id: doc.id,
        title: doc.title,
        createdAt: doc.createdAt,
        category: toCategoryTitle(doc.category),
        type: 'articles' as const,
        sourceType: basedOn?.sourceType || 'training',
        patternIds: getPatternIds(signalText),
        signalText,
      }
    }),
  ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) // Sort newest first

  const exceptionInsights = buildExceptionInsights(unifiedDocuments)
  const similarCases = buildSimilarCases(unifiedDocuments)

  return (
    <div className="mx-auto min-h-screen w-full min-w-0 max-w-7xl space-y-5 px-4 py-5 sm:px-6 md:space-y-8 md:p-10">
      {/* Header Section */}
      <div className="flex flex-col gap-4 px-1 py-1 md:flex-row md:items-end md:justify-between">
        <div className="min-w-0 max-w-2xl space-y-2 space-x-1">
          <div className="inline-flex items-center gap-2 rounded-full bg-success/15 px-3 py-1 text-xs font-medium text-foreground">
            <CheckCircle2 className="h-3.5 w-3.5 text-success" />
            Review Workspace Is Online
          </div>
          <div className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            {appUser.role} access
          </div>
          <h1 className="text-2xl font-bold leading-tight tracking-tight md:text-4xl">
            LogiSense Overview
          </h1>
          <p className="text-sm text-muted-foreground sm:text-base">
            Monitor source files submitted through the managed /Issues folder, review generated SOPs
            and articles, and keep DHL operations guidance ready for use.
          </p>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Pending Processing</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{rawInputs.totalDocs}</div>
            <p className="text-xs text-muted-foreground">Raw inputs from /Issues</p>
          </CardContent>
        </Card>
        <Card className="border-success/40">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Documents</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sops.totalDocs + articles.totalDocs}</div>
            <p className="text-xs text-muted-foreground">SOPs & Articles combined</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Knowledge Categories</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{categories.totalDocs}</div>
            <p className="text-xs text-muted-foreground">Detected SWCs or Single Word Category</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">System Status</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Online</div>
            <p className="text-xs text-muted-foreground">UiPath Webhook is Active</p>
          </CardContent>
        </Card>
      </div>

      {/* Interactive Unified Table */}
      <DashboardTableClient
        documents={unifiedDocuments.map(({ signalText, ...doc }) => doc)}
        role={appUser.role}
        categories={categories.docs.map((category) => category.title).filter(Boolean)}
        exceptionInsights={exceptionInsights}
        similarCases={similarCases}
      />
    </div>
  )
}
