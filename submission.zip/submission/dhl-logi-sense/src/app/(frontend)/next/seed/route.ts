export async function POST(): Promise<Response> {
  return new Response('Payload demo seed is disabled for DHL LogiSense.', { status: 410 })
}
