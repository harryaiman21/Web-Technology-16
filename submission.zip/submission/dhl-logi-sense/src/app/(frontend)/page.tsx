import { redirect } from 'next/navigation'
import { ArrowRight, KeyRound, ShieldCheck, UserRound } from 'lucide-react'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { getAuth0Client, isAuth0Configured, missingAuth0EnvVars } from '@/lib/auth0'
import { sanitizeReturnTo } from '@/utilities/returnTo'

export const dynamic = 'force-dynamic'

type HomePageProps = {
  searchParams: Promise<{
    returnTo?: string
  }>
}

export default async function HomePage({ searchParams }: HomePageProps) {
  const { returnTo: unsafeReturnTo } = await searchParams
  const returnTo = sanitizeReturnTo(unsafeReturnTo)
  const isConfigured = isAuth0Configured()
  const session = isConfigured ? await getAuth0Client().getSession() : null

  if (session) {
    redirect(returnTo)
  }

  const loginHref = `/auth/login?returnTo=${encodeURIComponent(returnTo)}`

  return (
    <main className="mx-auto grid w-full max-w-7xl flex-1 content-center items-stretch gap-5 px-4 py-6 sm:px-6 md:px-10 lg:grid-cols-[1.05fr_0.95fr] lg:py-8">
      <section className="flex h-full flex-col justify-center space-y-5">
        <div className="space-y-3">
          <Badge variant="outline" className="gap-2">
            <ShieldCheck className="h-3.5 w-3.5" />
            DHL LogiSense Access
          </Badge>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold leading-tight tracking-tight sm:text-4xl">
              Sign in to view DHL's operational knowledge.
            </h1>
            <p className="max-w-2xl text-base leading-6 text-muted-foreground">
              Use Auth0 identity or create an account right away to access SOPs, articles and source
              evidence.
            </p>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <Card>
            <CardContent className="flex gap-3 p-4">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-secondary text-secondary-foreground">
                <UserRound className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold">T1 Reviewers</p>
                <p className="text-sm text-muted-foreground">
                  Access, and inspect generated SOPs or articles.
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex gap-3 p-4">
              <div className="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-primary text-primary-foreground">
                <KeyRound className="h-5 w-5" />
              </div>
              <div>
                <p className="font-semibold">T2 editors</p>
                <p className="text-sm text-muted-foreground">
                  Access, edit or delete generated SOPs and articles.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <Card className="h-full overflow-hidden">
        <CardContent className="flex h-full flex-col justify-center space-y-4 p-5 sm:p-6">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">Secure Login</p>
            <h2 className="text-2xl font-semibold tracking-tight">Continue with Auth0.</h2>
            <p className="text-sm text-muted-foreground">
              Auth0 handles email, password, and Google sign-in.
            </p>
          </div>

          {isConfigured ? (
            <Button asChild className="h-11 w-full">
              <a href={loginHref}>
                Sign in
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>
          ) : (
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm">
              <p className="font-medium text-foreground">
                Auth0 environment variables are missing.
              </p>
              <p className="mt-1 text-muted-foreground">{missingAuth0EnvVars().join(', ')}</p>
            </div>
          )}

          <div className="rounded-md border border-border bg-muted/40 p-3 text-xs leading-5 text-muted-foreground">
            Payload admin accounts are separate. Your Payload admin sets T1/T2 roles in
            <span className="font-medium text-foreground"> /admin</span> after a user signs in once.
          </div>
        </CardContent>
      </Card>
    </main>
  )
}
