import type { Metadata, Viewport } from 'next'

import { cn } from '@/utilities/ui'
import { GeistMono } from 'geist/font/mono'
import { GeistSans } from 'geist/font/sans'
import React from 'react'

import { AdminBar } from '@/components/AdminBar'
import { Footer } from '@/Footer/Component'
import { Header } from '@/Header/Component'
import { Providers } from '@/providers'
import { ThemeToggle } from '@/providers/Theme/ThemeToggle'
import { mergeOpenGraph } from '@/utilities/mergeOpenGraph'
import { draftMode } from 'next/headers'

import './globals.css'
import { getServerSideURL } from '@/utilities/getURL'

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const { isEnabled } = await draftMode()

  return (
    <html className={cn(GeistSans.variable, GeistMono.variable)} lang="en" suppressHydrationWarning>
      <head>
        <link href="/logisense-mark.svg" rel="icon" type="image/svg+xml" />
      </head>
      <body>
        <Providers>
          <AdminBar
            adminBarProps={{
              preview: isEnabled,
            }}
          />

          <Header />
          {children}
          <Footer />
          <ThemeToggle />
        </Providers>
      </body>
    </html>
  )
}

export const metadata: Metadata = {
  title: 'DHL LogiSense',
  description: 'Operational knowledge dashboard for reviewing generated DHL SOPs and articles.',
  metadataBase: new URL(getServerSideURL()),
  icons: {
    icon: [{ url: '/logisense-mark.svg', type: 'image/svg+xml' }],
  },
  openGraph: mergeOpenGraph(),
  twitter: {
    card: 'summary_large_image',
    creator: '@dhl-logisense',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
}
