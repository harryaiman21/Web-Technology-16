import { redirect } from 'next/navigation'

import { sanitizeReturnTo } from '@/utilities/returnTo'

type LoginPageProps = {
  searchParams: Promise<{
    returnTo?: string
  }>
}

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const { returnTo: unsafeReturnTo } = await searchParams
  const returnTo = sanitizeReturnTo(unsafeReturnTo)
  redirect(`/?returnTo=${encodeURIComponent(returnTo)}`)
}
