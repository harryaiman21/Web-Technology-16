import { AlertCircle, KeyRound } from 'lucide-react'

import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { missingAuth0EnvVars } from '@/lib/auth0'

export default function Auth0SetupRequiredPage() {
  const missing = missingAuth0EnvVars()

  return (
    <div className="mx-auto flex min-h-screen max-w-3xl items-center px-4 py-10 sm:px-6">
      <Card className="w-full">
        <CardHeader className="space-y-3">
          <Badge variant="outline" className="w-fit gap-2">
            <KeyRound className="h-3.5 w-3.5" />
            Auth0 setup required
          </Badge>
          <CardTitle className="text-2xl leading-tight">
            Add Auth0 credentials before using the LogiSense dashboard.
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm text-muted-foreground">
          <div className="flex gap-3 rounded-md border border-destructive/40 bg-destructive/10 p-3 text-foreground">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
            <p>
              The dashboard is protected, but Auth0 cannot start until the required environment
              variables are present.
            </p>
          </div>
          <div>
            <p className="font-medium text-foreground">Missing variables:</p>
            <ul className="mt-2 list-inside list-disc">
              {missing.map((key) => (
                <li key={key}>
                  <code>{key}</code>
                </li>
              ))}
            </ul>
          </div>
          <p>
            Create a Regular Web Application in Auth0, then add the credentials to
            <code> .env.local</code>. Use <code>http://localhost:3000/auth/callback</code> as an
            allowed callback URL and <code>http://localhost:3000</code> as an allowed logout URL.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
