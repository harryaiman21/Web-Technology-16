import Link from 'next/link'
import React from 'react'

import { Logo } from '@/components/Logo/Logo'

export async function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-card text-card-foreground">
      <div className="container flex min-h-[59px] items-center justify-between gap-4 py-3">
        <Link className="flex items-center" href="/">
          <Logo className="h-8 w-8 shrink-0 sm:h-[34px] sm:w-[34px]" />
        </Link>

        <p className="hidden max-w-xl text-sm leading-5 text-muted-foreground sm:block">
          DHL LogiSense keeps generated SOPs and articles reviewable before a T2 user reviews it and
          decide to keep, edit or delete.
        </p>
      </div>
    </footer>
  )
}
