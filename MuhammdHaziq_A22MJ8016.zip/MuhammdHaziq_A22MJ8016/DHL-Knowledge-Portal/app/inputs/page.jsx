"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Sidebar from "../components/Sidebar";
import { supabase } from "../../lib/supabase";
import { useSettings } from "../context/SettingsContext";
import { useRouter } from "next/navigation";

const STATUS_STYLES = {
  pending:    "bg-amber-50 text-amber-700",
  processing: "bg-blue-50 text-blue-700",
  completed:  "bg-green-50 text-green-700",
  error:      "bg-red-50 text-red-700",
};

const TYPE_LABELS = {
  "SOP Draft":              "SOP Draft",
  "Incident Notes":         "Incident Notes",
  "Chat Messages":          "Chat Messages",
  "Training Material":      "Training Material",
  "Operational Exceptions": "Op. Exceptions",
};

const TYPE_COLORS = {
  "SOP Draft":              "bg-blue-50 text-blue-700",
  "Incident Notes":         "bg-red-50 text-red-700",
  "Chat Messages":          "bg-purple-50 text-purple-700",
  "Training Material":      "bg-green-50 text-green-700",
  "Operational Exceptions": "bg-amber-50 text-amber-700",
};

function timeAgo(dateStr) {
  const localDate = new Date(dateStr + "Z");
const diff = (Date.now() - localDate.getTime()) / 1000;
  if (diff < 3600)  return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function DetailModal({ row, onClose }) {
  if (!row) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/30 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="relative bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col mx-4">

        {/* Modal header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                {row.file_name || "Pasted text"}
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Input details</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg p-1.5 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Modal body */}
        <div className="overflow-y-auto px-6 py-5 space-y-5 flex-1">

          {/* Meta grid */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "File name",      value: row.file_name || "Pasted text" },
              { label: "Document type",  value: row.document_type },
              { label: "Input type",     value: row.input_type || "text" },
              { label: "Uploaded",       value: row.created_at ? new Date(row.created_at + "Z").toLocaleString("en-GB", {
  timeZone: "Asia/Kuala_Lumpur",
}) : "—" },
            ].map(({ label, value }) => (
              <div key={label} className="bg-slate-50 rounded-lg px-4 py-3">
                <p className="text-xs text-slate-400 mb-0.5">{label}</p>
                <p className="text-sm font-medium text-slate-800 capitalize">{value}</p>
              </div>
            ))}
          </div>

          {/* Status */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500">Status:</span>
            <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full capitalize ${STATUS_STYLES[row.status] || "bg-slate-100 text-slate-600"}`}>
              {row.status}
            </span>
          </div>

          {/* Raw text */}
          {row.raw_text && (
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Raw content</p>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 max-h-48 overflow-y-auto">
                <pre className="whitespace-pre-wrap text-xs text-slate-600 font-sans leading-relaxed">
                  {row.raw_text}
                </pre>
              </div>
            </div>
          )}

          {/* Generated article */}
          {row.generated_article && (
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Generated KB article</p>
              <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 max-h-64 overflow-y-auto">
                <pre className="whitespace-pre-wrap text-xs text-slate-700 font-sans leading-relaxed">
                  {row.generated_article}
                </pre>
              </div>
            </div>
          )}

        </div>

        {/* Modal footer */}
        <div className="px-6 py-3 border-t border-slate-100 flex justify-end flex-shrink-0">
          <button
            onClick={onClose}
            className="text-sm text-slate-500 bg-slate-100 hover:bg-slate-200 px-4 py-1.5 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}

export default function InputsPage() {
  const [inputs, setInputs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [selectedRow, setSelectedRow] = useState(null);
  const { settings } = useSettings();
  const router = useRouter();

 useEffect(() => {
  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      router.replace("/login");
      return;
    }

    fetchInputs();
  };

  checkAuth();
}, []);

useEffect(() => {
  if (!settings.autoRefresh) return;

  const interval = setInterval(() => {
    fetchInputs();
  }, 5000);

  return () => clearInterval(interval);
}, [settings.autoRefresh]);

  const fetchInputs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("raw_inputs")
      .select("*")
      .order("created_at", { ascending: false });
    if (!error) setInputs(data || []);
    setLoading(false);
  };

  const handleDelete = async (id, e) => {
    e.stopPropagation();
    if (!confirm("Delete this input?")) return;
    await supabase.from("raw_inputs").delete().eq("id", id);
    setInputs((prev) => prev.filter((r) => r.id !== id));
  };

  const filtered = inputs.filter((r) => {
    const matchSearch =
      (r.file_name || "").toLowerCase().includes(search.toLowerCase()) ||
      (r.document_type || "").toLowerCase().includes(search.toLowerCase()) ||
      (r.raw_text || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "all" || r.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const counts = {
    total:      inputs.length,
    pending:    inputs.filter((r) => r.status === "pending").length,
    processing: inputs.filter((r) => r.status === "processing").length,
    completed:  inputs.filter((r) => r.status === "completed").length,
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />

      {selectedRow && (
        <DetailModal row={selectedRow} onClose={() => setSelectedRow(null)} />
      )}

      <main className="flex-1 overflow-y-auto">
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <h1 className="text-base font-semibold text-slate-900">Raw inputs</h1>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5">
              <svg className="w-3.5 h-3.5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search inputs..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-transparent text-sm text-slate-700 placeholder-slate-400 outline-none w-44"
              />
            </div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="text-sm border border-slate-200 rounded-lg px-3 py-1.5 bg-white text-slate-600 outline-none"
            >
              <option value="all">All statuses</option>
              <option value="pending">Pending</option>
              <option value="processing">Processing</option>
              <option value="completed">Completed</option>
              <option value="error">Error</option>
            </select>
            <button onClick={fetchInputs} className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
            <Link href="/upload" className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-1.5 rounded-lg transition-colors">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
              </svg>
              Upload new
            </Link>
          </div>
        </div>

        <div className="px-6 py-6">
          <div className="grid grid-cols-4 gap-3 mb-6">
            {[
              { label: "Total inputs",  value: counts.total },
              { label: "Pending",       value: counts.pending },
              { label: "Processing",    value: counts.processing },
              { label: "Completed",     value: counts.completed },
            ].map(({ label, value }) => (
              <div key={label} className="bg-white rounded-xl border border-slate-200 px-4 py-3">
                <p className="text-xs text-slate-500">{label}</p>
                <p className="text-2xl font-semibold text-slate-900 mt-0.5">{value}</p>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 40px" }} className="px-5 py-2.5 border-b border-slate-100 bg-slate-50">
              {["File / source", "Type", "Uploaded", "Status", ""].map((h) => (
                <span key={h} className="text-xs font-medium text-slate-500">{h}</span>
              ))}
            </div>

            {loading ? (
              <div className="px-5 py-10 text-center text-sm text-slate-400">Loading...</div>
            ) : filtered.length === 0 ? (
              <div className="px-5 py-10 text-center text-sm text-slate-400">
                {search || filterStatus !== "all" ? "No inputs match your filter." : "No inputs yet. Upload your first file."}
              </div>
            ) : (
              filtered.map((row) => (
                <div
                  key={row.id}
                  onClick={() => setSelectedRow(row)}
                  style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 40px" }}
                  className="px-5 py-3 border-b border-slate-100 last:border-0 items-center hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <svg className="w-4 h-4 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                      {row.input_type === "image"
                        ? <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        : <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                      }
                    </svg>
                    <span className="text-sm text-slate-800 font-medium truncate">
                      {row.file_name || "Pasted text"}
                    </span>
                  </div>
                  <span className="text-sm text-slate-500">{TYPE_LABELS[row.document_type] || row.document_type}</span>
                  <span className="text-sm text-slate-500">{row.created_at ? timeAgo(row.created_at) : "—"}</span>
                  <div>
                    <span className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full capitalize ${STATUS_STYLES[row.status] || "bg-slate-100 text-slate-600"}`}>
                      {row.status}
                    </span>
                  </div>
                  <button
                    onClick={(e) => handleDelete(row.id, e)}
                    className="text-slate-300 hover:text-red-500 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              ))
            )}
          </div>

          {filtered.length > 0 && (
            <p className="text-xs text-slate-400 mt-3 text-right">
              Showing {filtered.length} of {inputs.length} inputs
            </p>
          )}
        </div>
      </main>
    </div>
  );
}