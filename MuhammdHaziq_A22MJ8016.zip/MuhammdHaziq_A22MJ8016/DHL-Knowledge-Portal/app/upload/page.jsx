"use client";

import { useState, useRef } from "react";
import Tesseract from "tesseract.js";
import { supabase } from "../../lib/supabase";
import Sidebar from "../components/Sidebar";

export default function UploadPage() {
  const [documentType, setDocumentType] = useState("SOP Draft");
  const [rawText, setRawText] = useState("");
  const [ocrText, setOcrText] = useState("");
  const [ocrProgress, setOcrProgress] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [inputType, setInputType] = useState(null);
  const [status, setStatus] = useState("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const fileInputRef = useRef(null);

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setSelectedFile(file);
    setOcrText("");
    setOcrProgress(null);

    const isTxt = file.type === "text/plain";
    const isImage = file.type.startsWith("image/");

    if (isTxt) {
      setInputType("txt");
      const text = await file.text();
      setOcrText(text);
    } else if (isImage) {
      setInputType("image");
      setOcrProgress(0);
      await Tesseract.recognize(file, "eng", {
        logger: (m) => {
          if (m.status === "recognizing text") {
            setOcrProgress(Math.round(m.progress * 100));
          }
        },
      }).then(({ data: { text } }) => {
        setOcrText(text.trim());
        setOcrProgress(null);
      });
    }
  };

  const handleSubmit = async () => {
    const finalText = rawText.trim() || ocrText.trim();
    if (!finalText) {
      setErrorMsg("Please paste text or upload a file before submitting.");
      return;
    }
    setStatus("submitting");
    setErrorMsg("");

    const { error } = await supabase.from("raw_inputs").insert({
      input_type: inputType || "text",
      document_type: documentType,
      raw_text: finalText,
      file_name: selectedFile?.name || null,
      status: "pending",
    });

    if (error) {
      setErrorMsg("Failed to save. " + error.message);
      setStatus("error");
    } else {
      setStatus("success");
    }
  };

  const handleClear = () => {
    setDocumentType("SOP Draft");
    setRawText("");
    setOcrText("");
    setOcrProgress(null);
    setSelectedFile(null);
    setInputType(null);
    setStatus("idle");
    setErrorMsg("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const submitLabel =
    status === "submitting" ? "Submitting..." :
    status === "success"    ? "✓ Submitted!" :
                              "Submit for Processing";

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">

        {/* Topbar */}
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <h1 className="text-base font-semibold text-slate-900">Upload raw input</h1>
        </div>

        <div className="max-w-5xl mx-auto px-6 py-6">
          <p className="text-sm text-slate-500 mb-6">
            Upload unstructured operational information for automated processing.
          </p>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            {/* Left column */}
            <div className="space-y-5">

              {/* Document type */}
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Document type
                </label>
                <select
                  value={documentType}
                  onChange={(e) => setDocumentType(e.target.value)}
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option>SOP Draft</option>
                  <option>Incident Notes</option>
                  <option>Chat Messages</option>
                  <option>Training Material</option>
                  <option>Operational Exceptions</option>
                </select>
              </div>

              {/* Paste text */}
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Paste raw content
                </label>
                <textarea
                  rows={12}
                  value={rawText}
                  onChange={(e) => setRawText(e.target.value)}
                  placeholder="Paste emails, SOP drafts, shipment exception notes, or operational messages here..."
                  className="w-full border border-slate-300 rounded-lg px-3 py-2.5 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              {/* Upload file */}
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Upload file
                </label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,image/png,image/jpeg"
                  onChange={handleFileChange}
                  className="w-full text-sm text-slate-600 file:mr-3 file:py-1.5 file:px-4 file:rounded-lg file:border file:border-slate-300 file:text-sm file:font-medium file:bg-slate-50 file:text-slate-700 hover:file:bg-slate-100"
                />
                {selectedFile && (
                  <p className="text-xs text-slate-400 mt-2">Selected: {selectedFile.name}</p>
                )}
                <p className="text-xs text-slate-400 mt-1">Supported: TXT, PNG, JPG</p>
              </div>

            </div>

            {/* Right column */}
            <div className="space-y-5">

              {/* OCR preview */}
              <div className="bg-white rounded-xl border border-slate-200 p-5">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  OCR / extracted text preview
                </label>
                <div className="border border-slate-200 rounded-lg bg-slate-50 min-h-[280px] p-4 text-sm text-slate-600">
                  {ocrProgress !== null && (
                    <div className="flex flex-col gap-3 py-10 items-center">
                      <div className="w-full bg-slate-200 rounded-full h-1.5">
                        <div
                          className="bg-blue-500 h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${ocrProgress}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-400">Running OCR... {ocrProgress}%</p>
                    </div>
                  )}
                  {ocrProgress === null && ocrText && (
                    <pre className="whitespace-pre-wrap text-sm">{ocrText}</pre>
                  )}
                  {ocrProgress === null && !ocrText && (
                    <span className="text-slate-400">
                      OCR extracted content will appear here after uploading an image or TXT file...
                    </span>
                  )}
                </div>
              </div>

              {/* Error */}
              {errorMsg && (
                <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700">
                  {errorMsg}
                </div>
              )}

              {/* Success */}
              {status === "success" && (
                <div className="bg-green-50 border border-green-200 rounded-xl px-4 py-3 text-sm text-green-700">
                  ✓ Input saved successfully. Pending UiPath processing.
                </div>
              )}

              {/* Buttons */}
              <div className="flex gap-3">
                <button
                  onClick={handleSubmit}
                  disabled={status === "submitting" || status === "success"}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white text-sm font-medium px-6 py-2.5 rounded-lg transition-colors disabled:cursor-not-allowed"
                >
                  {submitLabel}
                </button>
                <button
                  onClick={handleClear}
                  className="px-6 py-2.5 text-sm font-medium text-slate-600 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  Clear
                </button>
              </div>

            </div>
          </div>
        </div>
      </main>
    </div>
  );
}