"use client";

import Sidebar from "../components/Sidebar";
import { useSettings } from "../context/SettingsContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { supabase } from "../../lib/supabase";

function Toggle({ checked, onChange }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`relative w-10 h-6 rounded-full transition-colors duration-200 flex-shrink-0 ${
        checked ? "bg-blue-600" : "bg-slate-200"
      }`}
    >
      <span
        className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-200 ${
          checked ? "translate-x-5" : "translate-x-1"
        }`}
      />
    </button>
  );
}

function SegmentedControl({ options, value, onChange }) {
  return (
    <div className="flex bg-slate-100 rounded-lg p-0.5 gap-0.5">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={`flex-1 text-xs font-medium px-3 py-1.5 rounded-md transition-all ${
            value === opt.value
              ? "bg-white text-slate-900 shadow-sm"
              : "text-slate-500 hover:text-slate-700"
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <div className="px-5 py-3 border-b border-slate-100 bg-slate-50">
        <h2 className="text-sm font-semibold text-slate-900">{title}</h2>
      </div>
      <div className="divide-y divide-slate-100">{children}</div>
    </div>
  );
}

function Row({ label, description, children }) {
  return (
    <div className="px-5 py-4 flex items-center justify-between gap-6">
      <div>
        <p className="text-sm font-medium text-slate-800">{label}</p>
        {description && <p className="text-xs text-slate-400 mt-0.5">{description}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

export default function SettingsPage() {
  const { settings, update, reset } = useSettings();
  const router = useRouter();

  useEffect(() => {
  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      router.replace("/login");
    }
  };

  checkAuth();
}, []);

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <h1 className="text-base font-semibold text-slate-900">Settings</h1>
          <button
            onClick={reset}
            className="text-xs text-slate-400 hover:text-slate-600 border border-slate-200 px-3 py-1.5 rounded-lg transition-colors"
          >
            Reset to defaults
          </button>
        </div>

        <div className="px-6 py-6 max-w-2xl mx-auto space-y-5">

          <p className="text-sm text-slate-500">
            Customize how the DHL Knowledge Portal looks and behaves.
          </p>

          {/* Appearance */}
          <Section title="Appearance">
            <Row
              label="Dark mode"
              description="Switch the entire portal to a dark color scheme"
            >
              <Toggle
                checked={settings.darkMode}
                onChange={(v) => update("darkMode", v)}
              />
            </Row>

            <Row
              label="Font size"
              description="Affects all text across the portal"
            >
              <SegmentedControl
                value={settings.fontSize}
                onChange={(v) => update("fontSize", v)}
                options={[
                  { label: "Small",  value: "small"  },
                  { label: "Normal", value: "normal" },
                  { label: "Large",  value: "large"  },
                ]}
              />
            </Row>

            <Row
              label="View density"
              description="Controls spacing between elements"
            >
              <SegmentedControl
                value={settings.density}
                onChange={(v) => update("density", v)}
                options={[
                  { label: "Compact",      value: "compact"      },
                  { label: "Comfortable",  value: "comfortable"  },
                ]}
              />
            </Row>
          </Section>

          {/* Preferences */}
          <Section title="Preferences">
            <Row
              label="Default document type"
              description="Pre-selected when opening the Upload page"
            >
              <select
                value={settings.defaultDocType}
                onChange={(e) => update("defaultDocType", e.target.value)}
                className="text-sm border border-slate-200 rounded-lg px-3 py-1.5 bg-white text-slate-700 outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option>SOP Draft</option>
                <option>Incident Notes</option>
                <option>Chat Messages</option>
                <option>Training Material</option>
                <option>Operational Exceptions</option>
              </select>
            </Row>

            <Row
              label="Auto-refresh dashboard"
              description="Automatically refresh stats and activity every 60 seconds"
            >
              <Toggle
                checked={settings.autoRefresh}
                onChange={(v) => update("autoRefresh", v)}
              />
            </Row>
          </Section>

          {/* Preview */}
          <Section title="Preview">
            <div className="px-5 py-4 space-y-2">
              <p className="text-xs text-slate-400 mb-3">
                This is how text looks with your current settings.
              </p>
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 space-y-1.5">
                <p className="font-semibold text-slate-900">Label Not Printing Properly</p>
                <p className="text-slate-600">
                  This article provides steps to resolve issues where shipping labels
                  are not printing correctly.
                </p>
                <p className="text-slate-400 text-xs">SOP Draft · 2h ago</p>
              </div>
            </div>
          </Section>

          {/* About */}
          <Section title="About">
            <Row label="Portal version" description="DHL Knowledge Automation Portal">
              <span className="text-xs bg-green-50 text-green-700 font-medium px-2.5 py-1 rounded-full">
                v1.0.0
              </span>
            </Row>
            <Row label="Stack" description="Next.js · Supabase · UiPath · Tailwind CSS">
              <span className="text-xs text-slate-400">Stable</span>
            </Row>
          </Section>

        </div>
      </main>
    </div>
  );
}