"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { supabase } from "../../lib/supabase";
import { useSettings } from "../context/SettingsContext";
import { useRouter } from "next/navigation";


function timeAgo(dateStr) {
  const localDate = new Date(dateStr + "Z");
const diff = (Date.now() - localDate.getTime()) / 1000;
  if (diff < 3600)  return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
  return new Date(dateStr).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
}

const TYPE_LABELS = {
  "SOP Draft":              "SOP Draft",
  "Incident Notes":         "Incident Notes",
  "Chat Messages":          "Chat Messages",
  "Training Material":      "Training Material",
  "Operational Exceptions": "Op. Exceptions",
};

const TYPE_COLORS = {
  "SOP Draft":              { badge: "bg-blue-50 text-blue-700",     bar: "bg-blue-500"   },
  "Incident Notes":         { badge: "bg-red-50 text-red-700",       bar: "bg-red-400"    },
  "Chat Messages":          { badge: "bg-purple-50 text-purple-700", bar: "bg-purple-400" },
  "Training Material":      { badge: "bg-green-50 text-green-700",   bar: "bg-green-500"  },
  "Operational Exceptions": { badge: "bg-amber-50 text-amber-700",   bar: "bg-amber-400"  },
};

function renderInline(text) {
  const parts = text.split(/\*\*(.+?)\*\*/g);
  return parts.map((part, i) =>
    i % 2 === 1
      ? <strong key={i} className="font-semibold text-slate-900">{part}</strong>
      : part
  );
}

function ArticleRenderer({ content }) {
  if (!content) {
    return (
      <p className="text-slate-400 text-sm">
        No content available.
      </p>
    );
  }

  const formattedContent = content
    .replace(/\*\*/g, "")
    .replace(/---/g, "\n\n")
.replace(/Title(?=\s)/g, "\n\nTitle:")
.replace(/Summary(?=\s)/g, "\n\nSummary:")
.replace(/Issue(?=\s)/g, "\n\nIssue:")
.replace(/Resolution(?=\s)/g, "\n\nResolution:")
   .replace(/(\d+\.)/g, "\n\n$1")
    .replace(/(\.\s)(\d+\.)/g, "$1\n\n$2")
    
    .replace(/[ \t]+\n/g, "\n")
    .trim();

  const lines = formattedContent
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  return (
    <div className="space-y-4 text-[13px] leading-7 text-slate-700">

      {lines.map((line, i) => {

        // Section headings
       // Title
// Title
if (line.startsWith("Title:")) {
  return (
    <div
      key={i}
      className="border-l-2 border-blue-200 pl-4 py-1"
    >
      <h3 className="text-base font-bold text-blue-700 mb-1">
        Title:
      </h3>

      <p className="text-slate-800 leading-7">
        {line.replace("Title:", "").trim()}
      </p>
    </div>
  );
}

// Summary
if (line.startsWith("Summary:")) {
  return (
    <div
      key={i}
      className="border-l-2 border-green-200 pl-4 py-1"
    >
      <h3 className="text-base font-bold text-green-700 mb-1">
        Summary:
      </h3>

      <p className="text-slate-800 leading-7">
        {line.replace("Summary:", "").trim()}
      </p>
    </div>
  );
}

// Issue
if (line.startsWith("Issue:")) {
  return (
    <div
      key={i}
      className="border-l-2 border-red-200 pl-4 py-1"
    >
      <h3 className="text-base font-bold text-red-700 mb-1">
        Issue:
      </h3>

      <p className="text-slate-800 leading-7">
        {line.replace("Issue:", "").trim()}
      </p>
    </div>
  );
}

// Resolution
if (line.startsWith("Resolution:")) {
  return (
    <div
      key={i}
      className="border-l-2 border-blue-200 pl-4 py-1"
    >
      <h3 className="text-base font-bold text-blue-700">
        Resolution:
      </h3>
    </div>
  );
}

        // Numbered steps
        if (/^\d+\./.test(line)) {
          return (
            <div
              key={i}
              className="border-l-2 border-blue-200 pl-4 py-1"
            >
              <p className="font-medium text-slate-800">
                {line}
              </p>
            </div>
          );
        }

        // Bullet points
        if (/^[-•]/.test(line)) {
          return (
            <div key={i} className="flex gap-2 pl-2">
              <span className="text-slate-400 mt-0.5">•</span>
              <p>{line.replace(/^[-•]\s*/, "")}</p>
            </div>
          );
        }

        // Additional notes (text after numbered steps)
// Additional Notes
// Additional Notes
if (
  i > 0 &&
  !/^\d+\./.test(line) &&
  !line.startsWith("Title:") &&
  !line.startsWith("Summary:") &&
  !line.startsWith("Issue:") &&
  !line.startsWith("Resolution:")
) {
  return (
    <div
      key={i}
      className="border-l-2 border-amber-200 pl-4 py-1"
    >
      <h3 className="text-base font-bold text-amber-700 mb-1">
        Additional Notes:
      </h3>

      <p className="text-slate-800 leading-7">
        {line}
      </p>
    </div>
  );
}

// Normal paragraph fallback
return (
  <p key={i}>
    {line}
  </p>
);
      })}

    </div>
  );
}

function highlight(text, query) {
  if (!query || !text) return text;
  const parts = text.split(new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi"));
  return parts.map((p, i) =>
    p.toLowerCase() === query.toLowerCase()
      ? <mark key={i} className="bg-yellow-100 text-yellow-900 rounded px-0.5">{p}</mark>
      : p
  );
}

export default function ArticlesPage() {
  const [articles, setArticles]   = useState([]);
  const [loading, setLoading]     = useState(true);
  const [search, setSearch]       = useState("");
  const [filterType, setFilterType] = useState("all");
  const [expanded, setExpanded]   = useState({});
  const [error, setError]         = useState("");
  const [searchMode, setSearchMode] = useState(false); // true = supabase full-text search
  const { settings } = useSettings();
  const router = useRouter();

 useEffect(() => {
  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      router.replace("/login");
      return;
    }

    fetchArticles();
  };

  checkAuth();
}, []);

useEffect(() => {
  if (!settings.autoRefresh) return;

  const interval = setInterval(() => {
    fetchArticles();
  }, 60000);

  return () => clearInterval(interval);
}, [settings.autoRefresh]);

  const fetchArticles = async () => {
    setLoading(true);
    setError("");
    const { data, error } = await supabase
      .from("raw_inputs")
      .select("id, file_name, document_type, generated_article, created_at, status")
      .eq("status", "completed")
      .order("created_at", { ascending: false });
    if (error) setError("Failed to load articles. " + error.message);
    else setArticles(data || []);
    setLoading(false);
  };

  const handleDeepSearch = async () => {
    if (!search.trim()) return;
    setLoading(true);
    setSearchMode(true);
    const { data, error } = await supabase
      .from("raw_inputs")
      .select("id, file_name, document_type, generated_article, created_at, status")
      .eq("status", "completed")
      .or(`file_name.ilike.%${search}%,document_type.ilike.%${search}%,generated_article.ilike.%${search}%`)
      .order("created_at", { ascending: false });
    if (error) setError(error.message);
    else setArticles(data || []);
    setLoading(false);
  };

  const clearSearch = () => {
    setSearch("");
    setSearchMode(false);
    fetchArticles();
  };

  const toggleExpand = (id) =>
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));

  const filtered = articles.filter((a) => {
    const q = search.toLowerCase();
    const matchSearch = !search ||
      (a.generated_article || "").toLowerCase().includes(q) ||
      (a.file_name || "").toLowerCase().includes(q) ||
      (a.document_type || "").toLowerCase().includes(q);
    const matchType = filterType === "all" || a.document_type === filterType;
    return matchSearch && matchType;
  });

  // Analytics
  const typeCounts = articles.reduce((acc, a) => {
    acc[a.document_type] = (acc[a.document_type] || 0) + 1;
    return acc;
  }, {});
  const maxCount = Math.max(...Object.values(typeCounts), 1);
  const allTypes = [...new Set(articles.map((a) => a.document_type).filter(Boolean))];

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">

        {/* Topbar */}
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <h1 className="text-base font-semibold text-slate-900">Knowledge Base</h1>
          <div className="flex items-center gap-2">

            {/* Search input */}
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5">
              <svg className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search articles..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setSearchMode(false); }}
                onKeyDown={(e) => e.key === "Enter" && handleDeepSearch()}
                className="bg-transparent text-sm text-slate-700 placeholder-slate-400 outline-none w-44"
              />
              {search && (
                <button onClick={clearSearch} className="text-slate-400 hover:text-slate-600">
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>

            {/* Deep search button */}
            {search && (
              <button
                onClick={handleDeepSearch}
                className="text-xs bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200 px-3 py-1.5 rounded-lg font-medium transition-colors"
              >
                Deep search
              </button>
            )}

            {/* Type filter */}
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="text-sm border border-slate-200 rounded-lg px-3 py-1.5 bg-white text-slate-600 outline-none"
            >
              <option value="all">All types</option>
              {allTypes.map((t) => (
                <option key={t} value={t}>{TYPE_LABELS[t] || t}</option>
              ))}
            </select>

            {/* Refresh */}
            <button onClick={fetchArticles} className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
          </div>
        </div>

        <div className="px-6 py-6 max-w-5xl mx-auto">

          {/* Search mode banner */}
          {searchMode && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-2.5 mb-4 flex items-center justify-between">
              <p className="text-sm text-blue-700">
                Showing deep search results for <strong>"{search}"</strong> — {filtered.length} found
              </p>
              <button onClick={clearSearch} className="text-xs text-blue-600 hover:text-blue-800 font-medium">
                Clear search
              </button>
            </div>
          )}

          {/* Analytics */}
          {!loading && articles.length > 0 && !searchMode && (
            <div className="grid grid-cols-3 gap-4 mb-5">
              <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4">
                <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Total articles</p>
                  <p className="text-3xl font-bold text-slate-900">{articles.length}</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4">
                <div className="w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Last generated</p>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">{timeAgo(articles[0]?.created_at)}</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 p-5 flex items-center gap-4">
                <div className="w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                  </svg>
                </div>
                <div>
                  <p className="text-xs text-slate-500">Top category</p>
                  <p className="text-sm font-semibold text-slate-900 mt-0.5">
                    {Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "—"}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Bar chart */}
          {!loading && Object.keys(typeCounts).length > 0 && !searchMode && (
            <div className="bg-white rounded-xl border border-slate-200 p-5 mb-5">
              <h2 className="text-sm font-semibold text-slate-900 mb-4">Articles by category</h2>
              <div className="space-y-3">
                {Object.entries(typeCounts).sort((a, b) => b[1] - a[1]).map(([type, count]) => {
                  const colors = TYPE_COLORS[type] || { bar: "bg-slate-400" };
                  return (
                    <div key={type} className="flex items-center gap-3">
                      <span className="text-xs text-slate-500 w-36 flex-shrink-0 truncate">
                        {TYPE_LABELS[type] || type}
                      </span>
                      <div className="flex-1 bg-slate-100 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-500 ${colors.bar}`}
                          style={{ width: `${Math.round((count / maxCount) * 100)}%` }}
                        />
                      </div>
                      <span className="text-xs font-semibold text-slate-700 w-4 text-right">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Subtitle */}
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm text-slate-500">
              AI-generated knowledge articles from processed raw inputs.
            </p>
            {!loading && (
              <span className="text-xs text-slate-400">
                {filtered.length} article{filtered.length !== 1 ? "s" : ""}
                {filterType !== "all" && ` · ${TYPE_LABELS[filterType] || filterType}`}
              </span>
            )}
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700 mb-4">{error}</div>
          )}

          {loading && (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-white rounded-xl border border-slate-200 p-5 animate-pulse">
                  <div className="flex gap-3 mb-3">
                    <div className="h-4 bg-slate-100 rounded w-1/3" />
                    <div className="h-4 bg-slate-100 rounded w-16" />
                  </div>
                  <div className="space-y-2">
                    <div className="h-3 bg-slate-100 rounded w-full" />
                    <div className="h-3 bg-slate-100 rounded w-5/6" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {!loading && filtered.length === 0 && !error && (
            <div className="bg-white rounded-xl border border-slate-200 px-6 py-16 text-center">
              <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <p className="text-sm font-medium text-slate-600">
                {search ? `No articles match "${search}"` : "No completed articles yet"}
              </p>
              <p className="text-xs text-slate-400 mt-1">
                {search ? "Try deep search (press Enter) or clear the filter." : "Upload a raw input and let UiPath process it."}
              </p>
            </div>
          )}

          {/* Article cards */}
          {!loading && filtered.length > 0 && (
            <div className="space-y-3">
              {filtered.map((article) => {
                const isExpanded = expanded[article.id];
                const colors = TYPE_COLORS[article.document_type] || { badge: "bg-slate-100 text-slate-600" };

                return (
                  <div key={article.id} className="bg-white rounded-xl border border-slate-200 hover:border-slate-300 hover:shadow-sm transition-all duration-150 overflow-hidden">
                    <button
                      onClick={() => toggleExpand(article.id)}
                      className="w-full text-left px-5 py-4 flex items-center justify-between gap-4"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-8 h-8 bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center flex-shrink-0">
                          <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                          </svg>
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-slate-900 truncate">
                            {highlight(article.file_name?.replace(/\.[^/.]+$/, "") || "Untitled Article", search)}
                          </p>
                          <p className="text-xs text-slate-400 mt-0.5">
                            {article.file_name || "Pasted text"} · {timeAgo(article.created_at)}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${colors.badge}`}>
                          {TYPE_LABELS[article.document_type] || article.document_type}
                        </span>
                        <svg
                          className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`}
                          fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}
                        >
                          <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="border-t border-slate-100 px-5 py-5 bg-slate-50">
                        <div className="bg-white border border-slate-200 rounded-xl px-6 py-5">
                          <div className="grid grid-cols-3 gap-3 mb-5 pb-4 border-b border-slate-100">
                            <div>
                              <p className="text-xs text-slate-400">Category</p>
                              <p className="text-xs font-medium text-slate-700 mt-0.5">{article.document_type}</p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-400">Source file</p>
                              <p className="text-xs font-medium text-slate-700 mt-0.5 truncate">
                                {article.file_name || "Pasted text"}
                              </p>
                            </div>
                            <div>
                              <p className="text-xs text-slate-400">Processed</p>
                              <p className="text-xs font-medium text-slate-700 mt-0.5">
                                {new Date(article.created_at + "Z").toLocaleString("en-GB", {
  timeZone: "Asia/Kuala_Lumpur",
})}
                              </p>
                            </div>
                          </div>
                          <ArticleRenderer content={article.generated_article} />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

        </div>
      </main>
    </div>
  );
}