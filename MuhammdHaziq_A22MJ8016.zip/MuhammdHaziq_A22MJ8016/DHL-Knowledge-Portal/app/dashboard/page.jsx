"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { supabase } from "../../lib/supabase";
import { useSettings } from "../context/SettingsContext";
import { useRouter } from "next/navigation";


function timeAgo(dateStr) {
  const localDate = new Date(dateStr + "Z");
const diff = (Date.now() - localDate.getTime()) / 1000;
  if (diff < 3600)  return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export default function Dashboard() {
  const [stats, setStats] = useState({
    totalInputs:    0,
    pendingReview:  0,
    articlesGenerated: 0,
    completed:      0,
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const [loading, setLoading] = useState(true);
  const { settings } = useSettings();
  const router = useRouter();

 useEffect(() => {
  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      router.replace("/login");
      return;
    }

    fetchDashboardData();
  };

  checkAuth();
}, []);

useEffect(() => {
  if (!settings.autoRefresh) return;

  const interval = setInterval(() => {
    fetchDashboardData();
  }, 5000);

  return () => clearInterval(interval);
}, [settings.autoRefresh]);
  const fetchDashboardData = async () => {
    setLoading(true);

    // Run all queries in parallel
    const [
      { count: totalInputs },
      { count: pendingCount },
      { count: completedCount },
      { count: articlesCount },
      { data: recentInputs },
    ] = await Promise.all([
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }),
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }).eq("status", "completed"),
      supabase
  .from("raw_inputs")
  .select("*", { count: "exact", head: true })
  .not("generated_article", "is", null),
      supabase.from("raw_inputs").select("id, file_name, document_type, status, input_type, created_at").order("created_at", { ascending: false }).limit(5),
    ]);

    setStats({
      totalInputs:       totalInputs    || 0,
      pendingReview:     pendingCount   || 0,
      articlesGenerated: articlesCount  || 0,
      completed:         completedCount || 0,
    });

    setRecentActivity(recentInputs || []);
    setLoading(false);
  };

  const statCards = [
    {
      label: "Raw inputs",
      value: stats.totalInputs,
      color: "blue",
      icon: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z",
    },
    {
      label: "Articles generated",
      value: stats.articlesGenerated,
      color: "green",
      icon: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z",
    },
    {
      label: "Pending review",
      value: stats.pendingReview,
      color: "amber",
      icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
    },
  ];

  const colorMap = {
    blue:  { bg: "bg-blue-50",  text: "text-blue-600"  },
    green: { bg: "bg-green-50", text: "text-green-600" },
    amber: { bg: "bg-amber-50", text: "text-amber-600" },
  };

  const statusColor = {
    pending:    "bg-amber-50 text-amber-700",
    processing: "bg-blue-50 text-blue-700",
    completed:  "bg-green-50 text-green-700",
    error:      "bg-red-50 text-red-700",
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />

      <main className="flex-1 overflow-y-auto">

        {/* Topbar */}
        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <h1 className="text-base font-semibold text-slate-900">Dashboard</h1>
          <button
            onClick={fetchDashboardData}
            className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1.5 transition-colors"
          >
            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
            Refresh
          </button>
        </div>

        <div className="px-6 py-6 max-w-5xl mx-auto">

          {/* Header */}
          <div className="mb-6">
            <p className="text-slate-500 text-sm">
              DHL Logistics Knowledge Automation System
            </p>
          </div>

          {/* Stat cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {statCards.map(({ label, value, color, icon }) => (
              <div key={label} className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-500">{label}</p>
                    <p className="text-3xl font-bold text-slate-900 mt-1">
                      {loading ? (
                        <span className="inline-block w-10 h-8 bg-slate-100 rounded animate-pulse" />
                      ) : value}
                    </p>
                  </div>
                  <div className={`w-11 h-11 ${colorMap[color].bg} rounded-full flex items-center justify-center`}>
                    <svg className={`w-5 h-5 ${colorMap[color].text}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d={icon} />
                    </svg>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Progress bar — completed vs total */}
          {!loading && stats.totalInputs > 0 && (
            <div className="bg-white rounded-xl border border-slate-200 p-5 mb-6">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-slate-700">Processing progress</p>
                <p className="text-sm text-slate-500">
                  {stats.completed} of {stats.totalInputs} completed
                </p>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${Math.round((stats.completed / stats.totalInputs) * 100)}%` }}
                />
              </div>
              <p className="text-xs text-slate-400 mt-1.5">
                {Math.round((stats.completed / stats.totalInputs) * 100)}% of inputs processed
              </p>
            </div>
          )}

          {/* Recent activity */}
          <div className="bg-white rounded-xl shadow-sm border border-slate-200">
            <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900">Recent activity</h2>
              <span className="text-xs text-slate-400">{recentActivity.length} recent uploads</span>
            </div>

            <div className="divide-y divide-slate-100">
              {loading ? (
                [1, 2, 3].map((i) => (
                  <div key={i} className="px-5 py-4 flex items-center gap-4">
                    <div className="w-2 h-2 rounded-full bg-slate-200 animate-pulse" />
                    <div className="flex-1 space-y-1.5">
                      <div className="h-3 bg-slate-100 rounded animate-pulse w-2/3" />
                      <div className="h-2.5 bg-slate-100 rounded animate-pulse w-1/4" />
                    </div>
                  </div>
                ))
              ) : recentActivity.length === 0 ? (
                <div className="px-5 py-8 text-center text-sm text-slate-400">
                  No activity yet. Upload your first file to get started.
                </div>
              ) : (
                recentActivity.map((item) => (
                  <div key={item.id} className="px-5 py-4 flex items-center gap-4">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                      item.status === "completed"  ? "bg-green-500" :
                      item.status === "processing" ? "bg-blue-500"  :
                      item.status === "error"      ? "bg-red-500"   :
                                                     "bg-amber-400"
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-700 truncate">
                        {item.file_name
                          ? `${item.file_name} uploaded`
                          : `${item.document_type} pasted as text`}
                      </p>
                      <p className="text-xs text-slate-400 mt-0.5">{timeAgo(item.created_at)}</p>
                    </div>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize flex-shrink-0 ${statusColor[item.status] || "bg-slate-100 text-slate-600"}`}>
                      {item.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}