"use client";

import { createContext, useContext, useEffect, useState } from "react";

const SettingsContext = createContext({});

const DEFAULTS = {
  darkMode:       false,
  fontSize:       "normal",   // small | normal | large
  density:        "comfortable", // compact | comfortable
  autoRefresh:    false,
  defaultDocType: "SOP Draft",
};

export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState(DEFAULTS);
  const [mounted, setMounted] = useState(false);

  // Load from localStorage on first mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("dhl-settings");
      if (saved) setSettings({ ...DEFAULTS, ...JSON.parse(saved) });
    } catch {}
    setMounted(true);
  }, []);

  // Apply to DOM whenever settings change
  useEffect(() => {
    if (!mounted) return;
    try {
      localStorage.setItem("dhl-settings", JSON.stringify(settings));
    } catch {}

    const html = document.documentElement;

    // Dark mode — toggle class on <html>
    settings.darkMode
      ? html.classList.add("dark")
      : html.classList.remove("dark");

    // Font size — set on <html> so rem units cascade
    const sizes = { small: "12px", normal: "14px", large: "16px" };
    html.style.fontSize = sizes[settings.fontSize] || "14px";

    // Density — data attribute for CSS targeting
    html.setAttribute("data-density", settings.density);

  }, [settings, mounted]);

  const update = (key, val) =>
    setSettings((prev) => ({ ...prev, [key]: val }));

  const reset = () => setSettings(DEFAULTS);

  return (
    <SettingsContext.Provider value={{ settings, update, reset }}>
      {children}
    </SettingsContext.Provider>
  );
}

export const useSettings = () => useContext(SettingsContext);