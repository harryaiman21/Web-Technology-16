"use client";

import { useEffect, useState } from "react";
import Sidebar from "../components/Sidebar";
import { supabase } from "../../lib/supabase";
import { useRouter } from "next/navigation";

function timeAgo(dateStr) {
  const localDate = new Date(dateStr + "Z");
const diff = (Date.now() - localDate.getTime()) / 1000;
  if (diff < 3600)  return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

export default function RpaPage() {
  const [stats, setStats] = useState({ total: 0, pending: 0, completed: 0, error: 0 });
  const [recent, setRecent] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isActive, setIsActive] = useState(false);
  const router = useRouter();

 useEffect(() => {
  const checkAuth = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (!session) {
      router.replace("/login");
      return;
    }

    fetchData();
  };

  checkAuth();
}, []);

useEffect(() => {
  const interval = setInterval(() => {
    fetchData();
  }, 5000);

  return () => clearInterval(interval);
}, []);

  const fetchData = async () => {
    setLoading(true);
    const [
      { count: total },
      { count: pending },
      { count: completed },
      { count: error },
      { data: recentData },
    ] = await Promise.all([
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }),
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }).eq("status", "completed"),
      supabase.from("raw_inputs").select("*", { count: "exact", head: true }).eq("status", "error"),
      supabase.from("raw_inputs").select("id, file_name, document_type, status, created_at").order("created_at", { ascending: false }).limit(10),
    ]);
    setStats({ total: total || 0, pending: pending || 0, completed: completed || 0, error: error || 0 });
    setRecent(recentData || []);
   setIsActive(true);
    setLoading(false);
  };

  const successRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;

  const STATUS_STYLES = {
    pending:    { dot: "bg-amber-400", badge: "bg-amber-50 text-amber-700" },
    processing: { dot: "bg-blue-400",  badge: "bg-blue-50 text-blue-700"  },
    completed:  { dot: "bg-green-500", badge: "bg-green-50 text-green-700" },
    error:      { dot: "bg-red-500",   badge: "bg-red-50 text-red-700"    },
  };

  return (
    <div className="flex h-screen bg-slate-50">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">

        <div className="sticky top-0 z-10 bg-white border-b border-slate-200 px-6 py-3 flex items-center justify-between">
          <h1 className="text-base font-semibold text-slate-900">RPA Status</h1>
          <button onClick={fetchData} className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={1.75}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
        </div>

        <div className="px-6 py-6 max-w-4xl mx-auto">
          <p className="text-sm text-slate-500 mb-5">
            UiPath automation pipeline status and processing history.
          </p>

          {/* UiPath status indicator */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 mb-5 flex items-center justify-between">
            <div className="flex items-center gap-3">
             <div
  className={`w-2.5 h-2.5 rounded-full ${
    isActive
      ? "bg-green-500 animate-pulse"
      : "bg-red-500"
  }`}
/>
              <div>
               <p className="text-sm font-semibold text-slate-900">
  {isActive
    ? "UiPath automation connected"
    : "UiPath automation inactive"}
</p>
                <p className="text-xs text-slate-400 mt-0.5">Polling raw_inputs table for pending rows</p>
              </div>
            </div>
            <span
  className={`text-xs font-medium px-3 py-1 rounded-full ${
    isActive
      ? "bg-green-50 text-green-700"
      : "bg-red-50 text-red-700"
  }`}
>
  {isActive ? "Active" : "Inactive"}
</span>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-3 mb-5">
            {[
              { label: "Total processed", value: stats.total, color: "text-slate-900" },
              { label: "Pending",         value: stats.pending,   color: "text-amber-600" },
              { label: "Completed",       value: stats.completed, color: "text-green-600" },
              { label: "Errors",          value: stats.error,     color: "text-red-600"   },
            ].map(({ label, value, color }) => (
              <div key={label} className="bg-white rounded-xl border border-slate-200 px-4 py-3">
                <p className="text-xs text-slate-500">{label}</p>
                <p className={`text-2xl font-bold mt-0.5 ${color}`}>
                  {loading ? <span className="inline-block w-8 h-7 bg-slate-100 rounded animate-pulse" /> : value}
                </p>
              </div>
            ))}
          </div>

          {/* Success rate bar */}
          {!loading && stats.total > 0 && (
            <div className="bg-white rounded-xl border border-slate-200 p-5 mb-5">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium text-slate-700">Success rate</p>
                <p className="text-sm font-bold text-slate-900">{successRate}%</p>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5">
                <div
                  className="h-2.5 rounded-full bg-green-500 transition-all duration-700"
                  style={{ width: `${successRate}%` }}
                />
              </div>
              <p className="text-xs text-slate-400 mt-1.5">
                {stats.completed} of {stats.total} inputs successfully processed into KB articles
              </p>
            </div>
          )}

          {/* Recent processing log */}
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-100 bg-slate-50">
              <h2 className="text-sm font-semibold text-slate-900">Processing log</h2>
            </div>
            {loading ? (
              <div className="px-5 py-8 text-center text-sm text-slate-400">Loading...</div>
            ) : recent.length === 0 ? (
              <div className="px-5 py-8 text-center text-sm text-slate-400">No processing history yet.</div>
            ) : (
              recent.map((r) => {
                const s = STATUS_STYLES[r.status] || { dot: "bg-slate-400", badge: "bg-slate-100 text-slate-600" };
                return (
                  <div key={r.id} className="px-5 py-3.5 border-b border-slate-100 last:border-0 flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${s.dot}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-slate-800 truncate font-medium">
                        {r.file_name || "Pasted text"}
                      </p>
                      <p className="text-xs text-slate-400 mt-0.5">{r.document_type} · {timeAgo(r.created_at)}</p>
                    </div>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full capitalize flex-shrink-0 ${s.badge}`}>
                      {r.status}
                    </span>
                  </div>
                );
              })
            )}
          </div>

        </div>
      </main>
    </div>
  );
}