"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabase";


export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

useEffect(() => {
  const checkUser = async () => {
    const {
      data: { session },
    } = await supabase.auth.getSession();

    if (session) {
      router.replace("/dashboard");
    }
  };

  checkUser();
}, []);

  const handleLogin = async (e) => {
    e.preventDefault();

    setLoading(true);
    setError("");

    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    router.push("/dashboard");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f172a] via-[#1e3a8a] to-[#0f766e] flex items-center justify-center font-sans">
      <div className="w-[430px] border border-gray-400 shadow-2xl rounded-lg overflow-hidden bg-[#d4d0c8]/95 backdrop-blur-sm">
        <div className="bg-gradient-to-r from-[#1e40af] to-[#2563eb] text-white px-4 py-3 flex justify-between items-center">
          <span className="font-bold text-sm">
            DHL Knowledge Automation Portal - Login
          </span>

          <div className="flex gap-1">
            
          </div>
        </div>

        <div className="p-6">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-black">
              Welcome Back
            </h1>

            <p className="text-sm text-gray-700 mt-1">
              Please login to continue
            </p>
          </div>

          <form className="space-y-4" onSubmit={handleLogin}>
            <div>
              <label className="block text-sm font-bold mb-1">
                Email Address
              </label>

              <input
                type="email"
                placeholder="user@dhl.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border border-gray-500 px-3 py-2 bg-white text-black placeholder-gray-500 outline-none rounded-sm shadow-inner focus:border-blue-700"
              />
            </div>

            <div>
              <label className="block text-sm font-bold mb-1">
                Password
              </label>

              <input
                type="password"
                placeholder="********"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-gray-500 px-3 py-2 bg-white text-black placeholder-gray-500 outline-none rounded-sm shadow-inner focus:border-blue-700"
              />
            </div>

            <div className="flex justify-between items-center pt-2">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" />
                Remember me
              </label>

              <a href="#" className="text-sm text-blue-800 underline">
                Forgot Password?
              </a>
            </div>

            {error && (
              <div className="border border-red-700 bg-red-100 text-red-900 text-sm px-3 py-2 rounded-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-4 border border-gray-700 bg-gradient-to-b from-gray-100 to-gray-300 hover:from-white hover:to-gray-200 py-2 font-bold shadow-md rounded-sm"
            >
              {loading ? "LOGGING IN..." : "LOGIN"}
            </button>
          </form>
        </div>

        
      </div>
    </div>
  );
}
